package server;

import server.ui.ServerPanel;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) throws IOException {
        // 初始化服务器Socket
        int port= Integer.parseInt(DataBuffer.configProp.getProperty("port"));
        DataBuffer.serverSocket = new ServerSocket(port);

        // 建立Server线程
        Thread serverThread = new Thread(() -> {
            while (true) {
                // 监听Client连接
                Socket socket = null;
                try {
                    socket = DataBuffer.serverSocket.accept();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("A client from address " + socket.getInetAddress().getHostAddress() +
                        ":" + socket.getPort() + "is waiting in line.");
                new Thread(new RqstProcessor(socket)).start();   // 对每个连接到的Client单独分出一个线程用于响应其请求
            }
        });
        serverThread.start();   // 运行Server线程

        // 启动Server控制面板
        new ServerPanel();
        System.out.println("Server Start Running.");
    }
}

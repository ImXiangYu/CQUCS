#include "Fc.h"
int main()
{
    while (1)
    {
        system("cls");
        Run();
    }
}
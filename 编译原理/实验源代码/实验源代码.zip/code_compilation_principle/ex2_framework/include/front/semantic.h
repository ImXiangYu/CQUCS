/**
 * @file semantic.h
 * @author Yuntao Dai (d1581209858@live.com)
 * @brief
 * @version 0.1
 * @date 2023-01-06
 *
 * a Analyzer should
 * @copyright Copyright (c) 2023
 *
 */

#ifndef SEMANTIC_H
#define SEMANTIC_H

#include "ir/ir.h"
#include "front/abstract_syntax_tree.h"

#include <map>
#include <string>
#include <vector>
#include <iostream>
using std::map;
using std::string;
using std::vector;

namespace frontend
{

    // definition of symbol table entry
    struct STE
    {
        ir::Operand operand;
        vector<int> dimension;
        //STE();
        //STE(ir::Operand operand, vector<int> dimension) : operand(operand), dimension(dimension) {}
    };

    using map_str_ste = map<string, STE>;
    // definition of scope infomation
    struct ScopeInfo
    {
        int cnt;
        string name;
        map_str_ste table;
        // The init Constructor
        ScopeInfo(int cnt, string name, map_str_ste table) : cnt(cnt), name(name), table(table) {}
    };

    // surpport lib functions
    map<std::string, ir::Function *> *get_lib_funcs();

    // definition of symbol table
    struct SymbolTable
    {
        vector<ScopeInfo> scope_stack;
        map<std::string, ir::Function *> functions;

        /**
         * @brief enter a new scope, record the infomation in scope stacks
         * @param name: the name of the new scope
         */
        void add_scope(std::string);

        /**
         * @brief exit a scope, pop out infomations
         */
        void exit_scope();

        /**
         * @brief get curr scopeName
         */
        string get_curr_scope();
        /**
         * @brief Get the scoped name, to deal the same name in different scopes, we change origin id to a new one with scope infomation,
         * for example, we have these code:
         * "
         * int a;
         * {
         *      int a; ....
         * }
         * "
         * in this case, we have two variable both name 'a', after change they will be 'a' and 'a_block'
         * @param id: origin id
         * @return string: new name with scope infomations
         */
        string get_scoped_name(string id) const;

        /**
         * @brief get the right operand with the input name
         * @param id identifier name
         * @return Operand
         */
        ir::Operand get_operand(string id) const;

        /**
         * @brief get the right ste with the input name
         * @param id identifier name
         * @return STE
         */
        STE get_ste(string id) const;

        /**
         * 向最近的scope中增加entry
         */
        void add_scope_entry(string var_name, STE ste);

    };

    // singleton class
    struct Analyzer
    {
        int tmp_cnt;                           //临时变量编号
        vector<ir::Instruction *> g_init_inst; //初始化指令
        SymbolTable symbol_table;
        ir::Type latestType = ir::Type::null;
        ir::Type ReturnType = ir::Type::null;
        /**
         * @brief constructor
         */
        Analyzer();

        // analysis functions
        ir::Program get_ir_program(CompUnit*);
        void get_global_vars(ir::Program&);
        void get_functions(ir::Program&);
        std::string get_tmp_var();
        // reject copy & assignment
        Analyzer(const Analyzer &) = delete;
        Analyzer &operator=(const Analyzer &) = delete;

        // analysis functions
        void analysisCompUnit(CompUnit*, ir::Program&);

        void analysisDecl(Decl *, vector<ir::Instruction *> &);
        ir::Type analysisBType(BType *);

        void analysisConstDecl(ConstDecl *, vector<ir::Instruction *> &);
        void analysisConstDef(ConstDef *, vector<ir::Instruction *> &, ir::Type);
        void analysisConstExp(ConstExp *, vector<ir::Instruction *> &);
        void analysisConstInitVal(ConstInitVal *, vector<ir::Instruction *> &);

        void analysisVarDecl(VarDecl *, vector<ir::Instruction *> &);

        void analysisAddExp(AddExp *, vector<ir::Instruction *> &);
        void analysisMulExp(MulExp *, vector<ir::Instruction *> &);
        void analysisUnaryExp(UnaryExp *, vector<ir::Instruction *> &);
        TokenType analysisUnaryOp(UnaryOp *, vector<ir::Instruction *> &);
        void analysisFuncRParams(FuncRParams *, vector<ir::Operand> &, vector<ir::Instruction *> &);

        void analysisPrimaryExp(PrimaryExp *, vector<ir::Instruction *> &);

        void analysisExp(Exp *, vector<ir::Instruction *> &);
        void analysisLVal(LVal *, vector<ir::Instruction *> &, bool);
        void analysisNumber(Number *, vector<ir::Instruction *> &);

        void analysisVarDef(VarDef *, vector<ir::Instruction *> &, ir::Type);
        void analysisInitVal(InitVal *, vector<ir::Instruction *> &);
        //以下是函数定义
        void analysisFuncDef(FuncDef *);
        ir::Type analysisFuncType(FuncType *);
        void analysisFuncFParams(FuncFParams *, vector<ir::Operand> &);
        void analysisFuncFParam(FuncFParam *, vector<ir::Operand> &); // TODO

        void analysisBlock(Block *, vector<ir::Instruction *> &);
        void analysisBlockItem(BlockItem *, vector<ir::Instruction *> &);
        void analysisStmt(Stmt*, vector<ir::Instruction *>&);
        
        void doifStmt(Stmt*, vector<ir::Instruction *>&);
        void dowhileStmt(Stmt*, vector<ir::Instruction *>&);

        void analysisCond(Cond *, vector<ir::Instruction *> &);
        void analysisLOrExp(LOrExp *, vector<ir::Instruction *> &);
        void analysisLAndExp(LAndExp *, vector<ir::Instruction *> &);
        void analysisEqExp(EqExp *, vector<ir::Instruction *> &);
        void analysisRelExp(RelExp *, vector<ir::Instruction *> &);

        
        // void doArithmeticOperations(T1* root, T2* child, frontend::Term* term, std::string tmpVar, 
        //                             std::vector<ir::Instruction*>& insts);
    };

    template<typename T1, typename T2>
    void doArithmeticOperations(T1* root, T2* child, frontend::Term* term, std::string tmpVar, 
                            std::vector<ir::Instruction*>& insts);

    template<typename T> 
    std::string constLiteralComp(frontend::TokenType tk, Type type, T a, T b);
} // namespace frontend

#endif
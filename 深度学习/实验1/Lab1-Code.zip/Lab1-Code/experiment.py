# experiment.py
import torch
from lightning import LightningModule, Trainer
from lightning.pytorch.loggers import TensorBoardLogger
import torch.nn as nn
from data import get_dataloaders
from model import AlexNet
from plot import plot_lr_results, visualize_conv1
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# 模型检查
# 使用model.summary()验证参数规模
# 验证模型向前计算的正确性
# 验证模型反向传播的正确性

def run_model_checks():
    print("\n模型结构 + Forward + Backward 检查")

    model = AlexNet()

    # model.summary()
    print("\n验证参数规模")
    print("\n参数规模 ", sum(p.numel() for p in model.parameters()))

    # Forward 验证
    print("\nForward 检查")
    x = torch.randn(1, 1, 224, 224)
    out = model(x)
    print("\nForward 输出维度:", out.shape)
    print("\nForward 正常")

    # Backward 验证
    print("\nBackward 检查")
    criterion = nn.CrossEntropyLoss()
    loss = criterion(out, torch.tensor([1]))
    loss.backward()
    print("\nBackward 正常")

    print("\n模型检查全部通过")


# LightningModule
class AlexNetLightning(LightningModule):
    def __init__(self, lr):
        super().__init__()
        self.save_hyperparameters()
        self.model = AlexNet()
        self.loss_fn = nn.CrossEntropyLoss()

    def forward(self, x):
        return self.model(x)

    def configure_optimizers(self):
        return torch.optim.SGD(self.parameters(), lr=self.hparams.lr, momentum=0.9)

    def training_step(self, batch, batch_idx):
        x, y = batch
        pred = self(x)
        loss = self.loss_fn(pred, y)
        acc = (pred.argmax(1) == y).float().mean()
        self.log("train_loss", loss, prog_bar=True)
        self.log("train_acc", acc, prog_bar=True)
        return loss

    def validation_step(self, batch, batch_idx):
        x, y = batch
        pred = self(x)
        loss = self.loss_fn(pred, y)
        acc = (pred.argmax(1) == y).float().mean()
        self.log("val_loss", loss, prog_bar=True)
        self.log("val_acc", acc, prog_bar=True)

    def test_step(self, batch, batch_idx):
        x, y = batch
        pred = self(x)
        acc = (pred.argmax(1) == y).float().mean()
        self.log("test_acc", acc, prog_bar=True)

# 多学习率对比
def run_experiment():
    run_model_checks()
    train_loader, val_loader, test_loader = get_dataloaders()

    learning_rates = [0.01, 0.001]
    val_results = []
    test_results = []

    for lr in learning_rates:
        print(f"\n==============================")
        print(f"   Training with lr = {lr}")
        print(f"==============================")

        model = AlexNetLightning(lr=lr)
        trainer = Trainer(
            max_epochs=5,
            accelerator="auto",
            logger=TensorBoardLogger("logs", name=f"alexnet_lr_{lr}")
        )

        trainer.fit(model, train_loader, val_loader)

        validate_output = trainer.validate(model, val_loader, verbose=False)
        test_output = trainer.test(model, test_loader, verbose=False)

        val_acc = validate_output[0]["val_acc"]
        test_acc = test_output[0]["test_acc"]

        val_results.append(val_acc)
        test_results.append(test_acc)

        print(f"LR={lr}: Val Acc={val_acc:.4f}, Test Acc={test_acc:.4f}")

    # 对比图
    plot_lr_results(learning_rates, val_results, test_results)

    # 训练最佳模型用于后续分析
    best_lr = learning_rates[val_results.index(max(val_results))]
    print(f"\nBest LR: {best_lr}")

    # 混淆矩阵 & 卷积核可视化
    best_model = AlexNetLightning(lr=best_lr)
    trainer = Trainer(max_epochs=5, accelerator="auto")
    trainer.fit(best_model, train_loader, val_loader)

    # 混淆矩阵
    all_preds, all_labels = [], []
    best_model.eval()
    with torch.no_grad():
        for x, y in test_loader:
            preds = best_model(x.to(best_model.device)).argmax(1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(y.numpy())

    cm = confusion_matrix(all_labels, all_preds)
    disp = ConfusionMatrixDisplay(cm, display_labels=list(range(10)))
    disp.plot(cmap="Blues", values_format="d")
    plt.show()

    # 卷积核可视化
    visualize_conv1(best_model)


if __name__ == "__main__":
    run_experiment()

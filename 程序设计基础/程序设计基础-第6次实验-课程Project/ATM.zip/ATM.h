#include<bits/stdc++.h>
using namespace std;

class User {
  public:
    string accountNumber;
    string name;
    string id;
    string password;
    double balance = 0;
    double limit = 0;

    User() = default;
    void saveData(const string& filename) const;
    void loadData(const string& filename);
};

void welcomeMessage();
void displayMenu();
void performOperation(const string& accountNumber);
void balanceInquiry(const string& accountNumber);

bool isNumber(const string &str);
bool isAccountExist(string accountNumber);
bool checkPassword(const string& accountNumber, const string& password);

void withdrawal(const string& accountNumber);
void transfer(const string& accountNumber);
void changePassword(const string& accountNumber);

#include "ATM.h"

bool isNumber(const string &str) {
    for (char const &c : str) {
        if (isdigit(c) == 0) return false;
    }
    return true;
}

bool isAccountExist(string accountNumber) {
    if (!isNumber(accountNumber) || accountNumber.length() != 19) return false;
    accountNumber = accountNumber + ".txt";
    ifstream File((char *) accountNumber.c_str(), ios_base::in);
    if (!File) return false;
    File.close();
    return true;
}

bool checkPassword(const string& accountNumber, const string& password) {
    if (!isNumber(password) || password.length() != 6) return false;
    User tmpUser;
    tmpUser.loadData(accountNumber + ".txt");
    return tmpUser.password == password;
}

void User::saveData(const string &filename) const {
    try {
        ofstream out(filename);
        if (!out) {
            throw runtime_error("Unable to open the output file.");
        }
        // д������
        out << accountNumber << endl << name << endl << id << endl << password << endl << balance << endl << limit
            << endl;
    } catch (const exception &e) {
        cerr << "Error: " << e.what() << endl;
    }
}

void User::loadData(const string &filename) {
    try {
        ifstream in(filename);
        if (!in) {
            throw runtime_error("Unable to open the input file.");
        }
        // ��ȡ����
        in >> accountNumber >> name >> id >> password >> balance >> limit;
    } catch (const exception &e) {
        cerr << "Error: " << e.what() << endl;
    }
}


package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


public class ClientIOCache {
    private ObjectInputStream ois; // Client输入流
    private ObjectOutputStream oos; // Client对象输出流

    public ClientIOCache(Socket ClientSocket) throws IOException {
        ois = new ObjectInputStream(ClientSocket.getInputStream());
        oos = new ObjectOutputStream(ClientSocket.getOutputStream());
        this.ois = ois;
        this.oos = oos;
    }

    public ObjectOutputStream getOos() {
        return oos;
    }

    public ObjectInputStream getOis() {
        return ois;
    }

}

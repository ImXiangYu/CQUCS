#ifndef GENERARATOR_H
#define GENERARATOR_H

#include "ir/ir.h"
#include "backend/rv_def.h"
#include "backend/rv_inst_impl.h"

#include<map>
#include<string>
#include<vector>
#include<fstream>
#include<set>

namespace backend {
// it is a map bewteen variable and its mem addr, the mem addr of a local variable can be identified by ($sp + off)
struct stackVarMap {
    std::map<ir::Operand, int> stack_table;

    /**
     * @brief find the addr of a ir::Operand
     * @return the offset
    */
    int find_operand(ir::Operand);
    int currentStackOffset = -8 - 10*4;
    /**
     * @brief add a ir::Operand into current map, alloc space for this variable in memory 
     * @param[in] size: the space needed(in byte)
     * @return the offset
    */
    int add_operand(ir::Operand, uint32_t);
};
using rv::rvREG;
struct RegStatus
{
    rvREG reg;
    bool used = false;
};
using rv::rvREG;
using rv::rvFREG;
struct Generator {
    Generator(ir::Program&, std::ofstream&);
    const ir::Program& program;         // the program to gen
    std::ofstream& fout;                 // output file

    //记录当前的所在栈
    stackVarMap currStack;
    std::set<std::string>allGlobals;            //记录全局变量, 使用set
    std::map<std::string, int>currParamLists;  //当前函数的参数列表
    int currLabel = 0;                           //记录当前label编号
    std::map<int, std::string> labelMap;         //记录Go_to语句的标签
    bool hasFuncCall = false;                  //判断是否存在函数调用, 在getFrameSize中就可判断
    
    //保存寄存器s1-s11
    backend::RegStatus saveREGS[11] = {{rvREG::X9, false}, {rvREG::X18,false}, {rvREG::X19,false}, {rvREG::X20,false}, {rvREG::X21,false},
                              {rvREG::X22,false}, {rvREG::X23,false}, {rvREG::X24,false}, {rvREG::X25,false}, {rvREG::X26,false}, {rvREG::X27, false}};    
    //暂时以a7-a3及t0-t5作为临时变量, 暂不考虑过多参数的问题
    rv::rvREG provideRegs[10] = {rvREG::X16, rvREG::X15, rvREG::X14,
                                rvREG::X5, rvREG::X6, rvREG::X7, rvREG::X28, rvREG::X29,
                                rvREG::X30, rvREG::X31};
    //函数参数寄存器现在只考虑只有三个参数的情况a0, a1, a2 =>
    rv::rvREG paramsRegs[8] = {rvREG::X10, rvREG::X11, rvREG::X12, rvREG::X13, rvREG::X14, rvREG::X15, 
                               rvREG::X16, rvREG::X17};
    //统计临时变量引用次数
    std::map<std::string, int>citeCnt;
    //从临时变量到寄存器的映射
    std::map<std::string, rv::rvREG>tmpToReg;
    //检测当前寄存器是否被分配
    std::map<std::string, bool>isAllocated;
    //从寄存器到操作数的映射, 是否为了做函数调用规范, 又踩坑了
    std::map<rv::rvREG, ir::Operand>regToTmp;
    rv::rvREG getRd(ir::Operand);
    rv::rvREG getRs1(ir::Operand);
    rv::rvREG getRs2(ir::Operand);
    void freeReg(std::string);  //释放寄存器的分配
    void callerSave();
    void calleeRestore(rvREG);

    //加浮点数了
    //fa7用作辅助寄存器F17, fa0-fa1分配给参数不动他, fa2-fa6 + ft0-ft7
    rv::rvFREG FprovideRegs[13] = {
        rvFREG::F12, rvFREG::F13, rvFREG::F14, rvFREG::F15, rvFREG::F16,
        rvFREG::F0, rvFREG::F1, rvFREG::F2, rvFREG::F3, rvFREG::F4,
        rvFREG::F5, rvFREG::F6, rvFREG::F7
    };
    //fa0和fa1作为参数寄存器
    rv::rvFREG FparamRegs[2] = {
        rvFREG::F10, rvFREG::F11
    };
    //从临时变量到寄存器的映射
    std::map<std::string, rv::rvFREG>tmpToFReg;
    //检测当前寄存器是否被分配
    std::map<std::string, bool>FisAllocated;
    //从寄存器到操作数的映射, 是否为了做函数调用规范, 又踩坑了
    std::map<rv::rvFREG, ir::Operand>FregToTmp;
    rv::rvFREG fgetRd(ir::Operand);
    rv::rvFREG fgetRs1(ir::Operand);
    rv::rvFREG fgetRs2(ir::Operand);
    void freeFReg(std::string);
    void callerFSave();
    void calleeFRestore(rvFREG);
    // generate wrapper function
    void gen();
    void gen_global(const ir::GlobalVal&, const std::vector<ir::Instruction*>&);   //处理全局变量
    void gen_func(const ir::Function&);   //处理函数
    void gen_instr(ir::Instruction&, int, int, bool);  //处理指令
    void gen_label(const std::vector<ir::Instruction *>&);  //处理L标签
    
    //处理分配栈大小并处理参数
    int getFrameSize(const std::vector<ir::Instruction*>&, const std::vector<ir::Operand>&);
    //判断是否为全局变量
    bool isGlobalVar(std::string);
    bool isFuncParam(std::string);
    //重置栈和相关参数
    void resetStack();
    //为函数生成头栈分配指令
    void gen_func_head(int);
    //为函数生成尾指令
    void gen_func_tail(int);
    void gen_def_inst(ir::Operand, ir::Operand);
    void gen_add_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_sub_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_mul_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_div_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_mod_inst(ir::Operand, ir::Operand, ir::Operand);
    //包含了对IR中subi的处理
    void gen_addi_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_call_inst(ir::Instruction&);
    void gen_return_inst(ir::Operand, bool, int);
    //goto指令
    void gen_goto_inst(ir::Operand, ir::Operand, int);
    void gen_eq_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_orand_inst(ir::Operator, ir::Operand, ir::Operand, ir::Operand);
    void gen_lss_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_gtr_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_leq_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_neq_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_geq_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_not_inst(ir::Operand, ir::Operand);
    //alloc, load, store指令, 难死我了
    void gen_alloc_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_load_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_store_inst(ir::Operand, ir::Operand, ir::Operand);
    //以下是针对浮点数的
    void gen_fdef_inst(ir::Operand, ir::Operand);
    void gen_fmul_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_fdiv_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_fadd_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_fsub_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_flss_inst(ir::Operand, ir::Operand, ir::Operand);
    void gen_i2f_inst(ir::Operand, ir::Operand);
    void gen_f2i_inst(ir::Operand, ir::Operand);
};

//定义一个数据结构保存全局变量
struct GlobalVar
{
    //变量名, 类型, 大小(单位: 字节)
    std::string var_name;
    ir::Type var_type;
    int var_size;
    //初始化值域, 这里是为了后续方便对浮点数进行处理
    std::vector<int>var_initVal;
    GlobalVar() {};
    GlobalVar(std::string name, ir::Type type, int size, std::vector<int>init) {
        var_name = name;
        var_type = type;
        var_size = size;
        var_initVal = init;
    }
    GlobalVar(const GlobalVar&);
    //将用于输出变量定义
    void draw(std::ofstream&);
};
} // namespace backend


#endif
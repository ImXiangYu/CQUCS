#include"front/lexical.h"

#include<map>
#include<cassert>
#include<string>

#define TODO assert(0 && "todo")

// #define DEBUG_DFA
// #define DEBUG_SCANNER

std::string frontend::toString(State s) {
    switch (s) {
    case State::Empty: return "Empty";
    case State::Ident: return "Ident";
    case State::IntLiteral: return "IntLiteral";
    case State::FloatLiteral: return "FloatLiteral";
    case State::op: return "op";
    default:
        assert(0 && "invalid State");
    }
    return "";
}

std::set<std::string> frontend::keywords= {
    "const", "int", "float", "if", "else", "while", "continue", "break", "return", "void"
};

frontend::DFA::DFA(): cur_state(frontend::State::Empty), cur_str() {}

frontend::DFA::~DFA() {}

frontend::TokenType frontend::DFA::get_op_type(std::string s) {
    if(s.length() == 1){
        switch (s[0])
        {
        case '+':   return frontend::TokenType::PLUS;
        case '-':   return frontend::TokenType::MINU;
        case '*':   return frontend::TokenType::MULT;
        case '/':   return frontend::TokenType::DIV;
        case '%':   return frontend::TokenType::MOD;
        case '<':   return frontend::TokenType::LSS;
        case '>':   return frontend::TokenType::GTR;
        case ':':   return frontend::TokenType::COLON;
        case '=':   return frontend::TokenType::ASSIGN;
        case ';':   return frontend::TokenType::SEMICN;
        case ',':   return frontend::TokenType::COMMA;
        case '(':   return frontend::TokenType::LPARENT;
        case ')':   return frontend::TokenType::RPARENT;
        case '[':   return frontend::TokenType::LBRACK;
        case ']':   return frontend::TokenType::RBRACK;
        case '{':   return frontend::TokenType::LBRACE;
        case '}':   return frontend::TokenType::RBRACE;
        case '!':   return frontend::TokenType::NOT;
        default:    assert(0 && "invalid op type"); //assert(0 && "invalid op type");
        }
    }
    else if(s.length() == 2){
        if(s == "<=")       return frontend::TokenType::LEQ;
        else if(s == ">=")  return frontend::TokenType::GEQ;
        else if(s == "==")  return frontend::TokenType::EQL;
        else if(s == "!=")  return frontend::TokenType::NEQ;
        else if(s == "&&")  return frontend::TokenType::AND;
        else if(s == "||")  return frontend::TokenType::OR;
        else                assert(0 && "invalid op type");
    }
    return frontend::TokenType::PLUS;
}

bool frontend::DFA::is_operator(char c)
{
    std::string s = "+-*/%<>,:=;()[]{}!&|";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s[i]) return true;
    }
    return false;
}

bool frontend::DFA::ispossible_compound_op(char c)
{
    std::string s = "<>=!&|";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s[i]) return true;
    }
    return false;
}

bool frontend::DFA::is_single_op(std::string c)
{
    std::string s = "+-*/%<>,:=;()[]{}";
    for(size_t i = 0; i < s.size(); i++){
        if(c == s.substr(0,1)) return true;
    }
    return false;
}

bool frontend::DFA::is_compound_op(std::string c)
{
    return (c == "<=") || (c == ">=") || (c == "==") ||
           (c == "!=") || (c == "&&") || (c == "||");
}

bool frontend::DFA::is_number(char c)
{
    return (c >= '0' && c <= '9');
}

bool frontend::DFA::is_compound_ident(char c)
{
    return isalpha(c) || c == '_';
}

bool frontend::DFA::is_null_char(char c){
    return (c == ' '  || c == '\n' || 
            c == '\t' || c == '\r');
}

frontend::TokenType frontend::DFA::get_keyword_type(std::string s){
    if(s == "const")        return frontend::TokenType::CONSTTK;
    else if(s == "void")    return frontend::TokenType::VOIDTK;
    else if(s == "int")     return frontend::TokenType::INTTK;
    else if(s == "float")   return frontend::TokenType::FLOATTK;
    else if(s == "if")      return frontend::TokenType::IFTK;
    else if(s == "else")    return frontend::TokenType::ELSETK;
    else if(s == "while")   return frontend::TokenType::WHILETK;
    else if(s == "continue")return frontend::TokenType::CONTINUETK;
    else if(s == "break")   return frontend::TokenType::BREAKTK;
    else if(s == "return")  return frontend::TokenType::RETURNTK;
    else                    return frontend::TokenType::IDENFR;    
}

bool frontend::DFA::next(char input, Token& buf) {
    switch(cur_state) {
    case State::Empty:
        if(!is_null_char(input))            cur_str += input;               //不为空串时累加
        if(is_operator(input))              cur_state = State::op;          //操作符
        else if(is_number(input))           cur_state = State::IntLiteral;  //整型变量
        else if(is_compound_ident(input))   cur_state = State::Ident;       //标识符
        else if(input == '.')               cur_state = State::FloatLiteral; //浮点数
        return false;
    case State::IntLiteral:
        //继续增加数字
        if(is_number(input) || isalpha(input)) {
            cur_str += input;
            return false;
        }
        //转化为浮点数
        else if(input == '.'){
            cur_str += input;
            cur_state = State::FloatLiteral;
            return false;
        }
        else {
            //本状态结束, 输出对应整数
            buf.value = cur_str;
            buf.type = TokenType::INTLTR;
        }
        //输入空格, eg: 22 ....
        if(is_null_char(input)) reset();
        //下一步输入操作符, eg: 22+
        else if(is_operator(input)){
            cur_state = State::op;
            cur_str = input;
        }
        //else assert(0 && "invalid char after intNumber!");  //不合规, s22A这种情况
        return true;
    case State::FloatLiteral:
        //继续输入数字
        if(is_number(input)) {
            cur_str += input;
            return false;
        }
        else {
            //其他均输出浮点数
            buf.value = cur_str;
            buf.type = TokenType::FLOATLTR;
        }
        if(is_null_char(input)) reset();
        else if(is_operator(input)) {
            cur_state = State::op;
            cur_str = input;
        }
        else assert(0 && "invalid char after float number");  //不合规
        return true;
    case State::Ident:
        //a, _, 2数字之类
        if(is_compound_ident(input) || is_number(input)) {
            cur_str += input;
            return false;
        }
        else {
            buf.value = cur_str;
            buf.type = get_keyword_type(cur_str);
        }
        if(is_null_char(input)) reset();
        else if(is_operator(input)){
            cur_state = State::op;
            cur_str = input;
        }
        return true;
    //输入+-...等op
    case State::op:
        //判断是否为两个字符的操作符
        if(is_compound_op(cur_str + input)){
            buf.value = cur_str + input;
            buf.type = get_op_type(cur_str + input);
            reset();
            return true;
        }
        else {
            buf.value = cur_str;
            buf.type = get_op_type(cur_str);
            cur_str = input;
        }
        //输入空格
        if(is_null_char(input)) reset();
        //_a标识符
        else if(is_compound_ident(input))   cur_state = State::Ident;
        //数字
        else if(is_number(input))           cur_state = State::IntLiteral;
        else if(input == '.')               cur_state = State::FloatLiteral;
        else if(is_operator(input))         cur_state = State::op;
        return true;
    default: assert(0 && "invalid  state");
    }
    return false;
}

void frontend::DFA::reset() {
    cur_state = State::Empty;
    cur_str = "";
}

frontend::Scanner::Scanner(std::string filename): fin(filename) {
    if(!fin.is_open()) {
        assert(0 && "in Scanner constructor, input file cannot open");
    }
}

frontend::Scanner::~Scanner() {
    fin.close();
}

std::string frontend::Scanner::preproccess(std::ifstream &fin) {
    std::string line;
    std::string newString = "";
    bool is_comment = false;
    while(std::getline(fin, line)) {
        line += "\n";
        line.erase(0, line.find_first_not_of(" "));
        for(size_t i = 0; i < line.size(); i++) {
            if(i < line.size()-1 && line[i] == '/' && line[i+1] == '/') break;
            if(i < line.size()-1 && line[i] == '/' && line[i+1] == '*') {
                is_comment = true;
                i += 2;
            }
            if(i < line.size()-1 && line[i] == '*' && line[i+1] == '/') {
                is_comment = false;
                i += 2;
            }
            if(!is_comment) newString += line[i];
        }
    }
    return newString;
}

std::vector<frontend::Token> frontend::Scanner::run() {
    std::vector<frontend::Token> ret;
    frontend::Token tk;
    frontend::DFA dfa;
    std::string lines = preproccess(fin);
    for(auto c: lines){
        if(dfa.next(c, tk)){
            ret.push_back(tk);
        }
    }
    return ret;
#ifdef DEBUG_SCANNER
#include<iostream>
            std::cout << "token: " << toString(tk.type) << "\t" << tk.value << std::endl;
#endif
}
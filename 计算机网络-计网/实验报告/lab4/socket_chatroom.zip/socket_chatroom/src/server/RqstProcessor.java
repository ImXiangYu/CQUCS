package server;

import common.model.entity.*;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.CopyOnWriteArrayList;


public class RqstProcessor implements Runnable {
    /**
     * 继承runnable实现线程
     */
    private Socket currentClientSocket;  // 当前的ClientSocket
 ;
    public RqstProcessor(Socket currentClientSocket) {
        this.currentClientSocket = currentClientSocket;
    }

    public void run() {
        boolean flag = true;    // 控制持续监听
        try {
            // 生成当前Client的IO流缓存
            ClientIOCache currentClientIOCache = new ClientIOCache(currentClientSocket);
            while (flag) {
                /**
                 * 保持连接，基于TCP的socket实现
                 */
                Request request = (Request) currentClientIOCache.getOis().readObject();
                System.out.println("Receive Request: " + request.getAction() + " From " + currentClientSocket.getInetAddress().getHostAddress() + ":" + currentClientSocket.getPort());

                // 获取请求，并根据请求类型作出响应
                String actionName = request.getAction();
                switch (actionName) {
                    case "userRegiste":  // 注册
                        register(currentClientIOCache, request);
                        break;
                    case "userLogin":     // 登录
                        login(currentClientIOCache, request);
                        break;
                    case "exit":  // 断开连接
                        flag = logout(currentClientIOCache, request);
                        break;
                    case "chat":  // 发送消息
                        chat(request);
                        break;
                    case "shake":     // 振动
                        shake(request);
                        break;
                    case "toSendFile":    // 准备发送文件
                        toSendFile(request);
                        break;
                    case "agreeReceiveFile":  // 同意接收文件
                        agreeReceiveFile(request);
                        break;
                    case "refuseReceiveFile":     // 拒绝接收文件
                        refuseReceiveFile(request);
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void refuseReceiveFile(Request request) throws IOException {
        FileInfo sendFile = (FileInfo) request.getAttribute("sendFile");
        Response response = new Response();
        response.setType(ResponseType.REFUSERECEIVEFILE);
        response.setData("sendFile", sendFile);
        response.setStatus(ResponseStatus.OK);
        ClientIOCache ocic = DataBuffer.onlineUserIOCacheMap.get(sendFile.getFromUser().getId());
        this.sendResponse(ocic, response);
    }

    private void agreeReceiveFile(Request request) throws IOException {
        FileInfo sendFile = (FileInfo) request.getAttribute("sendFile");

        // 响应发送方
        Response response = new Response();
        response.setType(ResponseType.AGREERECEIVEFILE);
        response.setData("sendFile", sendFile);
        response.setStatus(ResponseStatus.OK);
        ClientIOCache sendIO = DataBuffer.onlineUserIOCacheMap.get(sendFile.getFromUser().getId());
        this.sendResponse(sendIO, response);

        // 向接收方发出接收文件的响应
        Response receiverResponse = new Response();
        receiverResponse.setType(ResponseType.RECEIVEFILE);
        receiverResponse.setData("sendFile", sendFile);
        receiverResponse.setStatus(ResponseStatus.OK);
        ClientIOCache receiveIO = DataBuffer.onlineUserIOCacheMap.get(sendFile.getToUser().getId());
        this.sendResponse(receiveIO, receiverResponse);
    }

    public boolean logout(ClientIOCache oio, Request request) throws IOException {
        System.out.println(currentClientSocket.getInetAddress().getHostAddress() + ":" + currentClientSocket.getPort() + " Has Quit The Chatroom.");

        User user = (User) request.getAttribute("user");
        // 更新IO表
        DataBuffer.onlineUserIOCacheMap.remove(user.getId());
        // 更新在线用户表
        DataBuffer.onlineUsersMap.remove(user.getId());

        Response response = new Response();
        response.setType(ResponseType.LOGOUT);
        response.setData("logoutUser", user);
        oio.getOos().writeObject(response);
        oio.getOos().flush();
        currentClientSocket.close();

        // 更新在线用户TableModel
        DataBuffer.onlineUserTableModel.remove(user.getId());
        // 向所有客户端响应
        iteratorResponse(response);

        return false;  // 断开监听
    }

    public void register(ClientIOCache oio, Request request) throws IOException {
        User user = (User) request.getAttribute("user");
        UserService userService = new UserService();
        userService.addUser(user);

        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setData("user", user);

        oio.getOos().writeObject(response);
        oio.getOos().flush();

        // 更新注册用户TableModel
        DataBuffer.registedUserTableModel.add(new String[]{
                String.valueOf(user.getId()),
                user.getPassword(),
                user.getNickname(),
                String.valueOf(user.getSex())
        });
    }

    public void login(ClientIOCache currentClientIO, Request request) throws IOException {
        String idStr = (String) request.getAttribute("id");
        String password = (String) request.getAttribute("password");
        UserService userService = new UserService();
        User user = userService.login(Long.parseLong(idStr), password);

        Response response = new Response();
        if (null != user) {
            if (DataBuffer.onlineUsersMap.containsKey(user.getId())) {
                response.setStatus(ResponseStatus.OK);
                response.setData("msg", "The User Has Already Login Somewhere Else!");
                currentClientIO.getOos().writeObject(response);
                currentClientIO.getOos().flush();
            } else {
                DataBuffer.onlineUsersMap.put(user.getId(), user); // 更新在线用户

                // 设置在线用户
                response.setData("onlineUsers",
                        new CopyOnWriteArrayList<User>(DataBuffer.onlineUsersMap.values()));

                response.setStatus(ResponseStatus.OK);
                response.setData("user", user);
                currentClientIO.getOos().writeObject(response);
                currentClientIO.getOos().flush();

                // 向所有客户端响应
                Response allResponse = new Response();
                allResponse.setType(ResponseType.LOGIN);
                allResponse.setData("loginUser", user);
                iteratorResponse(allResponse);

                // 更新IOMap
                DataBuffer.onlineUserIOCacheMap.put(user.getId(), currentClientIO);

                // 更新在线用户TableModel
                DataBuffer.onlineUserTableModel.add(
                        new String[]{String.valueOf(user.getId()),
                                user.getNickname(),
                                String.valueOf(user.getSex())});
            }
        } else {
            // 登录失败
            response.setStatus(ResponseStatus.OK);
            response.setData("msg", "UID or PWD Incorrect!");
            currentClientIO.getOos().writeObject(response);
            currentClientIO.getOos().flush();
        }
    }

    public void chat(Request request) throws IOException {

        Message msg = (Message) request.getAttribute("msg");
        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.CHAT);
        response.setData("txtMsg", msg);

        if (msg.getToUser() != null) {
            // 私聊
            ClientIOCache io = DataBuffer.onlineUserIOCacheMap.get(msg.getToUser().getId());
            sendResponse(io, response);
        } else {
            // 组通信
            for (Long id : DataBuffer.onlineUserIOCacheMap.keySet()) {
                if (msg.getFromUser().getId() == id) {
                    continue;
                }
                sendResponse(DataBuffer.onlineUserIOCacheMap.get(id), response);
            }
        }
    }
    
    public static void cast(String str) throws IOException {
        User user = new User(1, "admin");
        Message msg = new Message();
        msg.setFromUser(user);
        msg.setSendTime(new Date());

        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        StringBuffer sb = new StringBuffer();
        sb.append(" ").append(df.format(msg.getSendTime())).append(" ");
        sb.append("服务器\n  " + str + "\n");
        msg.setMessage(sb.toString());

        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.BOARD);
        response.setData("txtMsg", msg);

        for (Long id : DataBuffer.onlineUserIOCacheMap.keySet()) {
            sendResponse_sys(DataBuffer.onlineUserIOCacheMap.get(id), response);
        }
    }

    public static void remove(User user_) throws IOException {
        User user = new User(1, "admin");
        Message msg = new Message();
        msg.setFromUser(user);
        msg.setSendTime(new Date());
        msg.setToUser(user_);

        StringBuffer sb = new StringBuffer();
        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        sb.append(" ").append(df.format(msg.getSendTime())).append(" ");
        sb.append("You Have Been Removed From the Chatroom" + "\n");
        msg.setMessage(sb.toString());

        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.REMOVE);
        response.setData("txtMsg", msg);

        ClientIOCache io = DataBuffer.onlineUserIOCacheMap.get(msg.getToUser().getId());
        sendResponse_sys(io, response);
    }

    public static void chat_sys(String str, User user_) throws IOException {
        User user = new User(1, "admin");
        Message msg = new Message();
        msg.setFromUser(user);
        msg.setSendTime(new Date());
        msg.setToUser(user_);

        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        StringBuffer sb = new StringBuffer();
        sb.append(" ").append(df.format(msg.getSendTime())).append(" ");
        sb.append("服务器[私聊]\n  " + str + "\n");
        msg.setMessage(sb.toString());

        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.CHAT);
        response.setData("txtMsg", msg);

        ClientIOCache io = DataBuffer.onlineUserIOCacheMap.get(msg.getToUser().getId());
        sendResponse_sys(io, response);
    }

    public void shake(Request request) throws IOException {
        Message msg = (Message) request.getAttribute("msg");

        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        StringBuffer sb = new StringBuffer();
        sb.append(" ").append(msg.getFromUser().getNickname())
                .append("(").append(msg.getFromUser().getId()).append(") ")
                .append(df.format(msg.getSendTime())).append("\n  发送了一个窗口抖动给你!\n");
        msg.setMessage(sb.toString());

        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.SHAKE);
        response.setData("ShakeMsg", msg);

        ClientIOCache io = DataBuffer.onlineUserIOCacheMap.get(msg.getToUser().getId());
        sendResponse(io, response);
    }

    public void toSendFile(Request request) throws IOException {
        Response response = new Response();
        response.setStatus(ResponseStatus.OK);
        response.setType(ResponseType.TOSENDFILE);
        FileInfo sendFile = (FileInfo) request.getAttribute("file");
        response.setData("sendFile", sendFile);
        // 给文件接收方转发文件发送方的请求
        ClientIOCache ioCache = DataBuffer.onlineUserIOCacheMap.get(sendFile.getToUser().getId());
        sendResponse(ioCache, response);
    }

    private void iteratorResponse(Response response) throws IOException {
        for (ClientIOCache onlineUserIO : DataBuffer.onlineUserIOCacheMap.values()) {
            ObjectOutputStream oos = onlineUserIO.getOos();
            oos.writeObject(response);
            oos.flush();
        }
    }

    private void sendResponse(ClientIOCache onlineUserIO, Response response) throws IOException {
        ObjectOutputStream oos = onlineUserIO.getOos();
        oos.writeObject(response);
        oos.flush();
    }

    private static void sendResponse_sys(ClientIOCache onlineUserIO, Response response) throws IOException {
        ObjectOutputStream oos = onlineUserIO.getOos();
        oos.writeObject(response);
        oos.flush();
    }
}

#include <iostream>
#include <vector>
using namespace std;
class Fraction
{
    friend Fraction operator+(const Fraction &frac1, const Fraction &frac2); //重载+运算符
    friend Fraction operator-(const Fraction &frac1, const Fraction &frac2); //重载-运算符
    friend Fraction operator*(const Fraction &frac1, const Fraction &frac2); //重载*运算符
    friend Fraction operator/(const Fraction &frac1, const Fraction &frac2); //重载/运算符
    friend bool operator==(Fraction frac1, Fraction frac2);                  //重载==运算符
    friend bool operator>(const Fraction &frac1, const Fraction &frac2);     //重载>运算符
    friend bool operator<(const Fraction &frac1, const Fraction &frac2);     //重载<运算符
    friend ostream &operator<<(ostream &out, const Fraction &frac);          //重载<<运算符
    friend istream &operator>>(istream &in, Fraction &frac);                 //重载>>运算符
    friend void sortFraction(vector<Fraction> &vec, char sign);              //对分数数组排序

public:
    Fraction();                     //无参构造函数
    Fraction(int n, int d);         //带参构造函数
    Fraction(const Fraction &f);    //复制构造函数
    void setFraction(int n, int d); //设置分数的分子和分母
    int getNumer();                 //获取分数的分子
    int getDeno();                  //获取分数的分母
    void RdcFrc();                  //当前分数约分
    void judge();                   //判断分母是否为0
private:
    int numer; //分子
    int deno;  //分母
};
void Run();                   //启动计算器
void Fc_show();               //显示分数计算页面
void sortshow();              //显示分数排列页面
void Fc_calculation();        //进行计算
void sort();                  //进行排序
void wrong();                 //计算页面输入错误提示
void sortwrong();             //排序页面输入错误提示
int gcd(int numer, int deno); //辗转相除法求最大公因数
package server.ui;

import common.model.entity.User;
import server.DataBuffer;
import server.RqstProcessor;
import server.UserService;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ServerPanel extends JFrame {
    private JTextField cast_msg;
    private JTable onlineTable;
    private JTable userTable;
    private JTextArea msgListArea;
    private JLabel stateInfo;
    int width = 800;
    int height = 500;
    int x;
    int y;

    public ServerPanel() {
        init();
        setVisible(true);
    }

    public void init() {
        this.setTitle("服务器控制面板");
        // 设置窗口尺寸并居中显示
        this.x = (DataBuffer.screenSize.width - this.width) / 2;
        this.y = (DataBuffer.screenSize.height - this.height) / 2;
        this.setBounds(x, y, this.width, this.height);
        this.setLayout(new BorderLayout());

        // 设置服务器广播部分
        JPanel castPanel = new JPanel();
        Color highlight = new Color(20, 238, 213);
        Color shadow = new Color(158, 79, 238);
        Border border = BorderFactory.createEtchedBorder(EtchedBorder.RAISED, highlight, shadow);
        castPanel.setBorder(BorderFactory.createTitledBorder(border, "向所有用户广播"));
        cast_msg = new JTextField(40);
        JButton cast_button = new JButton("发送");
        ActionListener castMsgListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    castMsg();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        };
        cast_button.addActionListener(castMsgListener);
        castPanel.add(cast_msg);
        castPanel.add(cast_button);
        this.add(castPanel, BorderLayout.SOUTH);

        // 设置用户列表部分
        userTable = new JTable(DataBuffer.registedUserTableModel);
        onlineTable = new JTable(DataBuffer.onlineUserTableModel);
        JTabbedPane tablePane = new JTabbedPane();
        JScrollPane onlineScroll = new JScrollPane(onlineTable);
        JScrollPane userScroll = new JScrollPane(userTable);
        tablePane.addTab("在线用户", onlineScroll);
        tablePane.addTab("已注册用户", userScroll);
        this.add(tablePane, BorderLayout.WEST);
        this.loadData();

        // 设置弹出菜单部分
        JPopupMenu popupMenu1 = getOnlineTablePop();
        onlineTable.setComponentPopupMenu(popupMenu1);
        JPopupMenu popupMenu2 = getUserTablePop();
        userTable.setComponentPopupMenu(popupMenu2);

        // 关闭窗口
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                shutDown();
            }
        });
    }

    private JPopupMenu getOnlineTablePop() {
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem send = new JMenuItem("发送系统消息");
        JMenuItem remove = new JMenuItem("移出聊天室");
        send.setActionCommand("send");
        remove.setActionCommand("remove");
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cmd = e.getActionCommand();
                onlinePopMenuAction(cmd);
            }
        };
        send.addActionListener(actionListener);
        remove.addActionListener(actionListener);
        popupMenu.add(send);
        popupMenu.add(remove);
        return popupMenu;
    }

    private JPopupMenu getUserTablePop() {
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem remove = new JMenuItem("移除用户");
        remove.setActionCommand("remove");
        ActionListener actionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cmd = e.getActionCommand();
                userPopMenuAction(cmd);
            }
        };
        remove.addActionListener(actionListener);
        popupMenu.add(remove);
        return popupMenu;
    }

    private void userPopMenuAction(String cmd) {
        final int selectIndex = userTable.getSelectedRow();
        String usr_id = (String) userTable.getValueAt(selectIndex, 0);
        String nickname = (String) userTable.getValueAt(selectIndex, 0);
        System.out.println(usr_id);
        if (selectIndex == -1) {
            JOptionPane.showMessageDialog(this, "选择不能为空!");
            return;
        }
        if (cmd.equals("remove")) {
            int select = JOptionPane.showConfirmDialog(this,
                    "确认永久删除该用户吗?\n相关线程也会终止!",
                    "再次确认",
                    JOptionPane.YES_NO_OPTION);
            if (select == JOptionPane.YES_OPTION) {
                UserService.removeUser(Long.valueOf(usr_id));
                DataBuffer.registedUserTableModel.remove(usr_id);
            } else {
                setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "未知命令:" + cmd);
        }
        //this.loadData();
        this.updateTable();
    }

    private void onlinePopMenuAction(String cmd) {
        final int selectIndex = onlineTable.getSelectedRow();
        String usr_id = (String) onlineTable.getValueAt(selectIndex, 0);
        String nickname = (String) onlineTable.getValueAt(selectIndex, 0);
        System.out.println(usr_id);
        if (selectIndex == -1) {
            JOptionPane.showMessageDialog(this, "选择不能为空!");
            return;
        }
        if (cmd.equals("remove")) {
            try {
                RqstProcessor.remove(DataBuffer.onlineUsersMap.get(Long.valueOf(usr_id)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (cmd.equals("send")) {
            this.send(nickname, usr_id);
        } else {
            JOptionPane.showMessageDialog(this, "未知命令:" + cmd);
        }
        this.updateTable();
    }

    private void send(String nickname, String usr_id) {
        final JDialog jd = new JDialog(this, true);
        jd.setLayout(new FlowLayout());
        jd.setTitle("发送给 " + nickname);
        jd.setBounds(this.x, this.y, 300, 100);
        final JTextField sys_msg = new JTextField(30);
        JButton jb = new JButton("发送");
        jd.add(sys_msg);
        jd.add(jb);
        jb.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("发送一条来自控制面板的消息");
                String msg = sys_msg.getText();
                try {
                    RqstProcessor.chat_sys(msg, DataBuffer.onlineUsersMap.get(Long.valueOf(usr_id)));
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                sys_msg.setText("");
                jd.dispose();
            }
        });
        jd.setVisible(true);
    }

    private void castMsg() throws IOException {
        RqstProcessor.cast(cast_msg.getText());
        cast_msg.setText("");
    }

    private void loadData() {
        List<User> userList = new UserService().loadAllUser();
        for (User user : userList) {
            DataBuffer.registedUserTableModel.add(new String[]{
                    String.valueOf(user.getId()),
                    user.getPassword(),
                    user.getNickname(),
                    String.valueOf(user.getSex())
            });
        }
    }

    private void updateTable() {
        SwingUtilities.updateComponentTreeUI(onlineTable);
        SwingUtilities.updateComponentTreeUI(userTable);
    }

    private void shutDown() {
        int select = JOptionPane.showConfirmDialog(this,
                "确认关闭服务器面板吗?\n相关线程也会终止!",
                "再次确认",
                JOptionPane.YES_NO_OPTION);
        if (select == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else {
            setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        }
    }

    public static void main(String[] args) {
        new ServerPanel();
    }
}
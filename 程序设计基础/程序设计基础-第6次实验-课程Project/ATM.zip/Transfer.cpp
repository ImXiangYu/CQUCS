#include "ATM.h"

void transfer(const string& accountNumber) {
    User tmpUser;
    tmpUser.loadData(accountNumber + ".txt");

    string destinationAccountNumber;
    double amount;

    cout << "Enter destination account number:";
    cin >> destinationAccountNumber;

    if (!isAccountExist(destinationAccountNumber)) {
        cout << "Account numbers do not match. Transfer canceled." << endl;
        transfer(accountNumber);
    }

    cout << "Confirm destination account number:";
    string confirmAccount;
    cin >> confirmAccount;

    User destinationUser;
    destinationUser.loadData(destinationAccountNumber + ".txt");

    if (destinationAccountNumber != confirmAccount) {
        cout << "Account numbers do not match. Transfer canceled." << endl;
        transfer(accountNumber);
    }

    cout << "Enter transfer amount: ";
    cin >> amount;

    if (amount <= 0 || amount > tmpUser.balance) {
        cout << "Invalid amount or insufficient funds. Transfer canceled." << endl;
        transfer(accountNumber);
    } else {
        tmpUser.balance -= amount;
        destinationUser.balance += amount;
        cout << "Transfer successful. Remaining balance:" << tmpUser.balance << endl;
        tmpUser.saveData(accountNumber + ".txt");
        destinationUser.saveData(destinationAccountNumber + ".txt");
        displayMenu();
        performOperation(accountNumber);
    }
}

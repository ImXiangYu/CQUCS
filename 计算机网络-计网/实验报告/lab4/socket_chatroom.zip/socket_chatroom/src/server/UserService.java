package server;

import common.model.entity.User;
import common.util.IOUtil;
import server.DataBuffer;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class UserService {

    // 获取一个不重复的新id
    public int getNewId(){
        int newID = 1;
        List<User> users = loadAllUser();
        HashMap<Integer, Integer> tag = new HashMap<Integer, Integer>();
        for(int i = 1;i <= 100; i++){
            tag.put(i,0);
        }
        for (User user : users) {
            tag.replace((int) user.getId(),1);
        }
        Iterator<Map.Entry<Integer, Integer>> iterator = tag.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry<Integer,Integer> entry = iterator.next();
            if(entry.getValue().equals(0)){
                newID = entry.getKey();
                break;
            }
        }
        return newID;
    }
    // 添加用户（注册用）
    public void addUser(User user) {
        user.setId(getNewId());
        List<User> users = loadAllUser();
        users.add(user);
        saveAllUser(users);
    }

    // 移除用户
    public static void removeUser(long id) {
        List<User> users = loadAllUser();
        for (User user : users) {
            if (id == user.getId()) {
                users.remove(user);
                break;
            }
        }
        saveAllUser(users);
    }

    // 登录模块
    public User login(long id, String password) {
        User result = null;
        List<User> users = loadAllUser();
        for (User user : users) {
            if (id == user.getId() && password.equals(user.getPassword())) {
                result = user;
                break;
            }
        }
        return result;
    }

    // 加载用户
    public User loadUser(long id) {
        User result = null;
        List<User> users = loadAllUser();
        for (User user : users) {
            if (id == user.getId()) {
                result = user;
                break;
            }
        }
        return result;
    }

    // 载入用户列表
    @SuppressWarnings("unchecked")
    public static List<User> loadAllUser() {
        List<User> list = null;
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(
                    new FileInputStream(
                            DataBuffer.configProp.getProperty("dbpath")));

            list = (List<User>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtil.close(ois);
        }
        return list;
    }

    // 保存用户列表
    private static void saveAllUser(List<User> users) {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(DataBuffer.configProp.getProperty("dbpath")));
            //写回用户信息
            oos.writeObject(users);
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            IOUtil.close(oos);
        }
    }
}

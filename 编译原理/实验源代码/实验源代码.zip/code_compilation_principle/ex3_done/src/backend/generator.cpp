#include"backend/generator.h"
#include<iostream>
#include<assert.h>
#include<set>
#include<bitset>
#include<sstream>
using ir::Type;
using ir::Operand;
using ir::Operator;
using ir::Function;
using ir::Instruction;
using rv::rvREG;
using rv::rvOPCODE;
using rv::rv_inst;
using rv::rvREG;
using rv::rvFREG;

#define TODO assert(0 && "todo")

//常量定义
#define byte4 4
#define DATA ".data"
#define TEXT ".text"
#define GLOBL ".globl"
#define ALIGN ".align"
#define TYPE ".type"
#define SIZE ".size"
#define WORD ".word"
#define ZERO ".zero"
#define COMM ".comm"
#define LABEL ".L"
#define OBJECT "@object"
#define FUNCTION "@function"
#define endl "\n"
#define SCOPE_GLOBAL "GlobalScope"
#define Function_GLOBAL "_GlobalFunction"

//制表符输出定义
#define put(name, val) fout << "\t" << name << "\t" << val << endl
#define put2(name) fout << "\t" << name << endl

#define ISLiteral(type) (type == ir::Type::IntLiteral || type == ir::Type::FloatLiteral)
#define CompareEq(a, b, c, d) (a == b) ? c : d
#define num2str(a) std::to_string(a)
#define str2int(a) std::stoi(a)
#define str2flt(a) std::stof(a)
static std::string CurrScope = "main";

/**
 * 生成指令, 使用一系列宏定义缩小代码框架
*/
#define AUXIREG rv::rvREG::X17
#define FAUXIREG rv::rvFREG::F17
#define LI_INST(rd, imm) rv_inst(rvOPCODE::LI, rd, {}, {}, imm, {})
#define SW_INST(rs2, offset) rv_inst(rvOPCODE::SW,{}, rvREG::X8, rs2, offset,{})
#define LW_INST(des, offset) rv_inst(rvOPCODE::LW, des, rvREG::X8, {}, offset, {})
#define HI_GLOBL(des, name) fout << "\tlui\t" << toString(des) << ",\%hi(" << name << ")\n"
#define LO_GLOBL(des, name, op) fout << "\tlw\t"  << toString(des) << ",\%lo(" << name << ")(" << toString(op) << ")\n"
#define FSW_INST(rs1, offset) fout << "\tfsw\t" << toString(rs1) << "," << offset << "(s0)\n"
#define FLW_INST(rs1, offset) fout << "\tflw\t" << toString(rs1) << "," << offset << "(s0)\n"
#define FLI_INST(des, imm) fout << "\tli\t" << toString(des) << "," << imm << "\n"
// 将IEEE 754格式的二进制字符串转换为对应的无符号整数字符串形式
std::string binaryToUnsignedIntString(std::string binary) {
    std::bitset<32> bits(binary);
    unsigned int unsignedInt = bits.to_ulong();
    return std::to_string(unsignedInt);
}
// 将浮点数转换为IEEE 754格式的二进制字符串
std::string floatToLong(float num) {
    std::stringstream ss;
    union {
        float input;
        int output;
    } data;
    data.input = num;
    std::bitset<sizeof(float) * 8> bits(data.output);
    ss << bits;
    return binaryToUnsignedIntString(ss.str());
}
std::string bit_extend(float a) {
    uint32_t bits;
    // 使用联合体来查看浮点数的位模式
    union {
        float f;
        uint32_t u;
    } float_union;

    float_union.f = a;
    bits = float_union.u;
    char octalStr[9];
    snprintf(octalStr, sizeof(octalStr), "%08X", float_union.u);
    char finalStr[13]; // "0x" + 8位16进制字符串 + 终止符
    snprintf(finalStr, sizeof(finalStr), "0x%s", octalStr);
    return finalStr;
}
/**
* @brief find the addr of a ir::Operand
* @return the offset
*/
int backend::stackVarMap::find_operand(Operand target) {
    return stack_table[target];
}
/**
 * @brief add a ir::Operand into current map, alloc space for this variable in memory 
 * @param[in] size: the space needed(in byte)
 * @return the offset
*/
int backend::stackVarMap::add_operand(Operand save, uint32_t size) {
    if(stack_table.find(save) != stack_table.end()) {
        //assert(0 && "[stackVarMap::add_operand]: var already in stack!");
    }
    currentStackOffset -= size;
    stack_table[save] = currentStackOffset;
    return currentStackOffset;
}

/**
 * @brief 判断是否为全局变量
*/
bool backend::Generator::isGlobalVar(std::string name) {
    return allGlobals.count(name);
}

/**
 * @brief 重置栈和相关参数
*/
void backend::Generator::resetStack() {
    currStack.stack_table.clear();
    currParamLists.clear();  //参数列表清空
    currStack.currentStackOffset = -8 - 10*byte4;
    //isAllocated.clear();
    tmpToReg.clear();
    tmpToFReg.clear();
    regToTmp.clear();
    FregToTmp.clear();
    citeCnt.clear();
    hasFuncCall = false;
}

backend::Generator::Generator(ir::Program& p, std::ofstream& f): program(p), fout(f) {}

/**
 * @brief 判断是否为局部变量
*/
bool isLocalVars(const std::string& str) {
    if(str.size() < CurrScope.size()) return false;
    for(size_t i = 0; i < CurrScope.size(); i++){
        if(str[i] != CurrScope[i]) return false;
    }
    return true;
}
/**
 * @brief 判断是否为参数列表
*/
bool backend::Generator::isFuncParam(std::string str) {
    return currParamLists.find(str) != currParamLists.end();
}
// 拷贝构造函数
void backend::GlobalVar::draw(std::ofstream & fout) {
    put(GLOBL, var_name);
    if(!var_initVal[0] && var_type == Type::Int) {
        fout << "\t.section\t.sbss,\"aw\",@nobits\n";
    }
    else if(var_type == Type::Int) {
        fout << "\t.section\t.sdata\n";
    }
    put(ALIGN, 2);
    put(TYPE, var_name + ", " + OBJECT);
    put(SIZE, var_name + ", " + std::to_string(var_size));
    fout << var_name << ":" << endl;
    if(var_type == Type::IntPtr) {
        for(auto& init: var_initVal){
            put(WORD, num2str(init));
        }
    }
    else if(var_type == Type::Int) {
        if(var_initVal[0]) put(WORD, var_initVal[0]);
        else put(ZERO, var_size);
    }
    else {
        //assert(0 && "TODO in backend::GlobalVar::draw()!");
    }
}
void backend::Generator::gen_global(const ir::GlobalVal& var, const std::vector<ir::Instruction*>&insts) {
    //记录全局变量的属性
    //变量名, 类型, 大小(单位: 字节)
    std::string var_name = var.val.name;
    ir::Type var_type = var.val.type;
    int var_size = byte4;
    std::vector<int>var_initVal;
    backend::GlobalVar globalVar = GlobalVar(var_name, var_type, var_size, {});
    //记录全局变量名称
    allGlobals.insert(var_name);
    if(var_type == Type::Int) {
        /**
         * int a;  int a = 1;  不会出现const int a = 5;的情况, 被过滤了
         * 不考虑重复赋值的情况
        */
       if(insts.size() == 1) {  //说明只有return null指令没有初始化
            put(COMM, var_name + ",4,4"); 
            return;
       }
       else {
            var_initVal.push_back(0);
            for(auto i = 0; i < insts.size(); i++){
                if(insts[i]->op == Operator::def && insts[i]->des.name == var_name) {
                    var_initVal[0] = str2int(insts[i]->op1.name);
                }
            }
            globalVar.var_initVal = var_initVal;
            globalVar.draw(fout);
       }
    }
    //如果是数组
    else if(var_type == Type::IntPtr) {
        globalVar.var_size = var.maxlen * byte4;
        for(auto i = 0; i < insts.size(); i++) {
            if(insts[i]->op == Operator::store && insts[i]->op1.name == var_name) {
                var_initVal.push_back(str2int(insts[i]->des.name));
            }
        }
        //说明没有初始化
        if(var_initVal.empty()) {
            put(COMM, var_name + "," + num2str(globalVar.var_size) + "," + num2str(byte4));
            return;
        }
        globalVar.var_initVal = var_initVal;
        globalVar.draw(fout);
    }
    else {
        assert(0 && "TODO in backend::Generator::gen_global!");
    }
}

bool isCompareOperator(Operator op) {
    //没考虑完全
    switch (op)
    {
    case Operator::eq:
    case Operator::_or:
    case Operator::lss:
    case Operator::gtr:
    case Operator::leq:
    case Operator::neq:
    case Operator::_and:
    case Operator::geq:
    case Operator::_not:
         return true;
    default:
        return false;
        break;
    }
    return false;
}
/**
 * 获取分配的栈的空间的大小, 找局部变量数目
 * 这里简化一下, 首先给最大的参数32数目, 暂时不考虑计算的问题
*/
int backend::Generator::getFrameSize(const std::vector<ir::Instruction*>&insts, const std::vector<ir::Operand>&params) {
    int totalSize = 0;           //记录总的frameSize
    std::set<std::string>localVars;
    for(auto inst: insts) {
        //过滤掉main函数中调用全局函数
        if(inst->op == Operator::call && inst->des.name != "$t0") {
            hasFuncCall = true;   //存在参数调用
            citeCnt[inst->des.name] = 0;
            //获取里面的参数
            auto callInst = dynamic_cast<const ir::CallInst *>(inst);
            auto params = callInst->argumentList;
            if(params.size()) {
                for(auto param: params) {
                    if(param.type != Type::Int && param.type != Type::Float) continue;
                    if(!isLocalVars(param.name) && !isGlobalVar(param.name)) {
                        citeCnt[param.name]++;
                    }
                }
            }
        }
        //下面是在做引用计数, 可把我计惨了
        if(inst->op == Operator::fdef || inst->op == Operator::fmov) {
            if(citeCnt.find(inst->des.name) == citeCnt.end() && !isLocalVars(inst->des.name)) {
                citeCnt[inst->des.name] = 0;
            }
            if(!isLocalVars(inst->op1.name) && !isGlobalVar(inst->op1.name)) {
                citeCnt[inst->op1.name]++;
            }
        }
        if(inst->op == Operator::cvt_f2i || inst->op == Operator::cvt_i2f){
            citeCnt[inst->des.name] = 0;
            citeCnt[inst->op1.name]++;
        }
        if(inst->op == Operator::mov && inst->op1.type != Type::IntLiteral) {
            if(citeCnt.find(inst->des.name) == citeCnt.end() && !isLocalVars(inst->des.name)) {
                citeCnt[inst->des.name] = 0;
            }
            if(!isLocalVars(inst->op1.name) && !isGlobalVar(inst->op1.name)) {
                citeCnt[inst->op1.name]++;
            }
        }
        else if(inst->op2.type != Type::null && inst->op1.type != Type::null) {
            //这里可能会有bug！！！！！！！！！！
            if(inst->op1.type != Type::IntLiteral) citeCnt[inst->op1.name]++;
            if(inst->op2.type != Type::IntLiteral) citeCnt[inst->op2.name]++;
        }
        if(inst->op == Operator::_return && inst->des.type != Type::null && inst->des.type != Type::IntLiteral) {
            citeCnt[inst->des.name]++;
        }
        if(isCompareOperator(inst->op) && citeCnt.find(inst->des.name) == citeCnt.end()) {
            citeCnt[inst->des.name] = 0;
        }
        else if(inst->op == Operator::_goto && inst->op1.type == Type::Int) {
            citeCnt[inst->op1.name]++;
        }
        if(inst->op == Operator::load) {
            if(inst->des.type != Type::IntLiteral) citeCnt[inst->des.name] = 0;
        }
        else if(inst->op == Operator::store) {
            if(inst->des.type != Type::IntLiteral) {
                citeCnt[inst->des.name]++;
            }
        }
        if(inst->op == Operator::_not) {
            citeCnt[inst->op1.name]++;
        }
        if(inst->op == Operator::def && !isLocalVars(inst->des.name) && !isGlobalVar(inst->des.name)) {
            citeCnt[inst->des.name] = 0;
        }
        if(localVars.count(inst->des.name)) 
            continue;
        //数组定义
        if(inst->op == Operator::alloc) {
            totalSize += std::stoi(inst->op1.name) * byte4;
            localVars.insert(inst->des.name);
            currStack.add_operand(inst->des, str2int(inst->op1.name) * byte4);
        }
        else {
            totalSize += byte4;
            localVars.insert(inst->des.name);
            currStack.add_operand(inst->des, byte4);
        }
    }
    //遍历参数列表
    for(auto &param: params) {
        //注意,这里没有考虑参数为多维数组的情况, 测试用例中似乎没有
        if(localVars.count(param.name)) continue;
        localVars.insert(param.name);
        totalSize += byte4;
        currStack.add_operand(param, byte4);
    }
    //初始化栈
    for(auto& reg: provideRegs) {
        isAllocated[toString(reg)] = false;
    }
    for(auto& reg: FprovideRegs) {
        FisAllocated[toString(reg)] = false;
    }
    //for ra返回指针, 以及避免出现bug
    return totalSize + byte4*6;
}
/**
 * 
*/
void backend::Generator::gen_label(const std::vector<ir::Instruction *>& insts) {
    //清空当前label, 解决形如goto [pc, addr]的问题
    //labelMap属于<int, string>的映射
    //通过当前指令在函数中的位置的映射
    int pos = 0;  //当前指令所在位置, 第几条
    labelMap.clear();
    for(auto& inst: insts) {
        if(inst->op == Operator::_goto) {
            labelMap[pos + str2int(inst->des.name)] = LABEL + num2str(currLabel);
            currLabel++;
        }
        pos++;//进入下一条指令
    }
}
/**
 * @brief 生成函数栈分配指令
*/
void backend::Generator::gen_func_head(int offset) {
    rv_inst sp_inst = rv_inst(rvOPCODE::ADDI, rvREG::X2, rvREG::X2,{},-offset, {});
    fout << sp_inst.draw();
    if(hasFuncCall) {
        rv_inst sw_inst = rv_inst(rvOPCODE::SW,{},rvREG::X2, rvREG::X1, offset-byte4, {});
        rv_inst sws0_inst = rv_inst(rvOPCODE::SW,{},rvREG::X2, rvREG::X8, offset-byte4*2, {});
        rv_inst addi_s0 = rv_inst(rvOPCODE::ADDI, rvREG::X8, rvREG::X2, {}, offset, {});
        fout << sw_inst.draw() << sws0_inst.draw() << addi_s0.draw();
    }
    else {
        rv_inst sws0_inst = rv_inst(rvOPCODE::SW,{},rvREG::X2, rvREG::X8, offset-byte4, {});
        rv_inst addi_s0 = rv_inst(rvOPCODE::ADDI, rvREG::X8, rvREG::X2, {}, offset, {});
        fout << sws0_inst.draw() << addi_s0.draw();
    }
}

/**
 *@brief 为函数生成尾指令
*/
void backend::Generator::gen_func_tail(int offset) {
    //05 回收栈                 addi sp, sp, offset
    if(hasFuncCall) {
        rv_inst lw_inst = rv_inst(rvOPCODE::LW, rvREG::X1,rvREG::X2,{},offset-byte4, {});
        //保留s0帧指针fp
        rv_inst lws0_inst = rv_inst(rvOPCODE::LW, rvREG::X8, rvREG::X2,{},offset-byte4*2, {});
        fout << lw_inst.draw() << lws0_inst.draw();
    }
    else {
        //保留s0帧指针fp
        rv_inst lws0_inst = rv_inst(rvOPCODE::LW, rvREG::X8, rvREG::X2,{},offset-byte4, {});
        fout << lws0_inst.draw();
    }
    // fout << "\taddi\tsp,sp,16\n";
    // fout << "\tjr	ra\n";
    rv_inst sp_inst = rv_inst(rvOPCODE::ADDI, rvREG::X2, rvREG::X2,{}, offset, {});
    rv_inst jr_inst = rv_inst(rvOPCODE::JR, {}, {}, {}, {}, {});
    fout << sp_inst.draw() << jr_inst.draw();
}
/**
 * 生成函数
*/
void backend::Generator::gen_func(const Function& func) {
    //01 生成函数信息
    put(ALIGN, 1);
    put(GLOBL, func.name);
    put(TYPE, func.name + ", " + FUNCTION);
    fout << func.name << ":" << endl;
    CurrScope = func.name;
    //1.1 栈顶清空
    resetStack();
    //02-1 被调用者保存寄存器calleeRegisterSave(): 将参数存储到函数能够访问到的位置 TODO;
    //03 计算偏移量
    int spOffset = getFrameSize(func.InstVec, func.ParameterList);
    //04 获取L标签信息
    gen_label(func.InstVec);
    //05 分配栈
    gen_func_head(spOffset);
    // 06 获取函数参数: 这里你就必须考虑了哦, 注意我还是只考虑只有三个参数的情况
    if(func.ParameterList.size()) {
        int pos = 0;
        for(auto& param: func.ParameterList) {
            currParamLists[param.name] = pos;
            if(pos > 7){
                pos++;
                continue;
            } 
            if(param.type == Type::Int || param.type == Type::IntPtr) {
                rv_inst inst_sw = SW_INST(paramsRegs[pos], currStack.find_operand(param));
                fout << inst_sw.draw();
            }
            else if(param.type == Type::Float || param.type == Type::FloatPtr) {
                FSW_INST(FparamRegs[pos], currStack.find_operand(param));
            }
            pos++;
        }
    }
    // 07 生成指令
    int pos = 0;
    for(auto& inst: func.InstVec) {
        //不需要处理全局调用了, 因为已经处理过了
        if(inst->des.name != "$t0") {
            bool end = (pos == func.InstVec.size() - 1);
            gen_instr(*inst, pos, spOffset, end);
        }
        pos++;
    }
    while(labelMap.count(pos)) fout << labelMap[pos++] + ":\n";
    //08 回收栈, 退出函数
    gen_func_tail(spOffset);
    //09 生成脚注
    put(SIZE, func.name + ", .-" + func.name);
}

/**
 * 寄存器保存
*/
void backend::Generator::callerSave() {
    for(size_t i = 0; i < 9; i++) {
        //确实被分配了, 那么你就需要保存了哦
        if(isAllocated[toString(provideRegs[i])]) {
            //fout << "# callerSave(): \n";
            fout << SW_INST(provideRegs[i], -8 - i*byte4).draw();
        }
    }
}

/**
 * 寄存器恢复
*/
void backend::Generator::calleeRestore(rvREG curr) {
    for(size_t i = 0; i < 9; i++) {
        //确实被分配了, 那么你就需要恢复了哦
        if(curr==rvREG::X27){
            if(isAllocated[toString(provideRegs[i])]){
                fout << LW_INST(provideRegs[i], -8 - i*byte4).draw();
            }
        }
        else {
            if(isAllocated[toString(provideRegs[i])] && toString(provideRegs[i]) != toString(curr)) {
                //fout << "# calleeRestore(): \n";
                fout << LW_INST(provideRegs[i], -8 - i*byte4).draw();
            }
        }
        
    }
}
/**
* 目标寄存器分配
*/
rv::rvREG backend::Generator::getRd(Operand rd) {
   if(tmpToReg.find(rd.name) == tmpToReg.end()) {
        for(int pos = 0; pos < 10; pos++) {
            //fout << "#status: " << (toString(provideRegs[pos])) << isAllocated[toString(provideRegs[pos])] << "\n";
            //如果没有被分配
            if(!isAllocated[toString(provideRegs[pos])]) {
                tmpToReg[rd.name] = provideRegs[pos];
                isAllocated[toString(provideRegs[pos])] = true;
                //做寄存器的映射, 方便寄存器恢复
                regToTmp[provideRegs[pos]] = rd.name;
                return provideRegs[pos];
            }
        }
        //fout << "# Inadequate Reg Allocate: Need to Allocate T regs! \n";
        //assert(0 && "Inadequate Reg Allocate: Need to Allocate T regs!");
   }
   return tmpToReg[rd.name];
}
rv::rvREG backend::Generator::getRs1(Operand rs1) {
    rv::rvREG rs;
    if(tmpToReg.find(rs1.name) != tmpToReg.end()) {
        rs = tmpToReg[rs1.name];
        if(citeCnt.find(rs1.name) == citeCnt.end()) {
            freeReg(rs1.name);
            return rs;
        }
        citeCnt[rs1.name]--;
        if(citeCnt[rs1.name] <= 0) {
            freeReg(rs1.name);
        }
        return rs;
    }
    return rs;
}
rvREG backend::Generator::getRs2(Operand rs2) {
    rv::rvREG rs;
    if(tmpToReg.find(rs2.name) != tmpToReg.end()) {
        rs = tmpToReg[rs2.name];
        if(citeCnt.find(rs2.name) == citeCnt.end()) {
            freeReg(rs2.name);
            return rs;
        }
        citeCnt[rs2.name]--;
        if(citeCnt[rs2.name] <= 0) {
            freeReg(rs2.name);
        }
        return rs;
    }
    return rs;
}
/**
 * 释放寄存器的分配
*/
void backend::Generator::freeReg(std::string var) {
    if(tmpToReg.find(var) == tmpToReg.end()) return;
    // fout << "#release: " << var << "\n";
    // fout << "#init:?" << isAllocated[toString(tmpToReg[var])] << "\n";
    isAllocated[toString(tmpToReg[var])] = false;
    // fout << "#reg:?" << toString(tmpToReg[var]) << "\n";
    // fout << "#status:?" << isAllocated[toString(tmpToReg[var])] << "\n";
    tmpToReg.erase(var);
    return;
}
//-------------------------以下是针对浮点数的---------------------------------------
/**
* 目标寄存器分配
*/
rvFREG backend::Generator::fgetRd(Operand frd) { 
   if(tmpToFReg.find(frd.name) == tmpToFReg.end()) {
        for(int pos = 0; pos < 10; pos++) {
            //fout << "#status: " << (toString(provideRegs[pos])) << isAllocated[toString(provideRegs[pos])] << "\n";
            //如果没有被分配
            if(!FisAllocated[toString(FprovideRegs[pos])]) {
                tmpToFReg[frd.name] = FprovideRegs[pos];
                FisAllocated[toString(FprovideRegs[pos])] = true;
                //做寄存器的映射, 方便寄存器恢复
                FregToTmp[FprovideRegs[pos]] = frd.name;
                return FprovideRegs[pos];
            }
        }
        //fout << "# Inadequate Reg Allocate: Need to Allocate T regs! \n";
        //assert(0 && "Inadequate Reg Allocate: Need to Allocate T regs!");
   }
   return tmpToFReg[frd.name];
}
rvFREG backend::Generator::fgetRs1(Operand frs1) {
    rv::rvFREG frs;
    if(tmpToFReg.find(frs1.name) != tmpToFReg.end()) {
        frs = tmpToFReg[frs1.name];
        if(citeCnt.find(frs1.name) == citeCnt.end()) {
            freeFReg(frs1.name);
            return frs;
        }
        citeCnt[frs1.name]--;
        if(citeCnt[frs1.name] <= 0) {
            freeFReg(frs1.name);
        }
        return frs;
    }
    return frs;
}
rvFREG backend::Generator::fgetRs2(Operand frs2) {
    rv::rvFREG frs;
    if(tmpToFReg.find(frs2.name) != tmpToFReg.end()) {
        frs = tmpToFReg[frs2.name];
        if(citeCnt.find(frs2.name) == citeCnt.end()) {
            freeFReg(frs2.name);
            return frs;
        }
        citeCnt[frs2.name]--;
        if(citeCnt[frs2.name] <= 0) {
            freeFReg(frs2.name);
        }
        return frs;
    }
    return frs;
}
void backend::Generator::freeFReg(std::string var) {
    if(tmpToFReg.find(var) == tmpToFReg.end()) return;
    //fout << "#release: " << var << "\n";
    //fout << "#init:?" << isAllocated[toString(tmpToReg[var])] << "\n";
    FisAllocated[toString(tmpToFReg[var])] = false;
    //fout << "#reg:?" << toString(tmpToReg[var]) << "\n";
    //fout << "#status:?" << isAllocated[toString(tmpToReg[var])] << "\n";
    tmpToFReg.erase(var);
    return;
}
/**
 * 寄存器保存
*/
void backend::Generator::callerFSave() {
    for(size_t i = 0; i < 10; i++) {
        //确实被分配了, 那么你就需要保存了哦
        if(FisAllocated[toString(FprovideRegs[i])]) {
            //fout << "# callerSave(): \n";
            fout << "\tfsw\t" << toString(FprovideRegs[i]) << "," << 8 + i*byte4 << "(s0)\n";
        }
    }
}

/**
 * 寄存器恢复
*/
void backend::Generator::calleeFRestore(rvFREG curr) {
    for(size_t i = 0; i < 9; i++) {
        //确实被分配了, 那么你就需要恢复了哦
        if(curr==rvFREG::F27){
            if(FisAllocated[toString(FprovideRegs[i])]){
                 //fout << "# callerRestore(): \n";
                 fout << "\tflw\t" << toString(FprovideRegs[i]) << "," << 8 + i*byte4 << "(s0)\n";
            }
        }
        else {
            if(FisAllocated[toString(FprovideRegs[i])] && toString(FprovideRegs[i]) != toString(curr)) {
                //fout << "# callerRestore(): \n";
                fout << "\tflw\t" << toString(FprovideRegs[i]) << "," << 8 + i*byte4 << "(s0)\n";
            }
        }
    }
}

void backend::Generator::gen_instr(Instruction& inst, int pos, int spOffset, bool end) {
    if(labelMap.count(pos)) fout << labelMap[pos] + ":\n";
    auto &op = inst.op;
    auto &des = inst.des;
    auto &op1 = inst.op1;
    auto &op2 = inst.op2;
    switch (op) {
        case Operator::def:
        case Operator::mov:
            //def/mov  main_a, 1
            if(des.name == "tmp0") return;  //这个是生成数组前做的, 没有实际含义
            else gen_def_inst(des, op1);
            break;
        case Operator::add:     gen_add_inst(des, op1, op2); break;
        case Operator::mul:     gen_mul_inst(des, op1, op2); break;
        case Operator::div:     gen_div_inst(des, op1, op2); break;
        case Operator::sub:     gen_sub_inst(des, op1, op2); break;
        case Operator::mod:     gen_mod_inst(des, op1, op2); break;
        case Operator::addi:
        case Operator::subi:
            if(op == Operator::subi) op2.name = num2str(-str2int(op2.name));   //subi立即数取反
            gen_addi_inst(des, op1, op2);
            break;
        case Operator::call:    gen_call_inst(inst);                    break;
        case Operator::_return: gen_return_inst(op1, end, spOffset);    break;
        case Operator::_goto:   gen_goto_inst(des, op1, pos);           break;
        case Operator::eq:      gen_eq_inst(des, op1, op2);             break;
        case Operator::_and:
        case Operator::_or:
            gen_orand_inst(op, des, op1, op2);
            break;
        case Operator::lss:
            gen_lss_inst(des, op1, op2);
            break;
        case Operator::gtr:
            gen_gtr_inst(des, op1, op2);
            break;
        case Operator::leq:
            gen_leq_inst(des, op1, op2);
            break;
        case Operator::geq:
            gen_geq_inst(des, op1, op2);
            break;
        case Operator::neq:
            gen_neq_inst(des, op1, op2);
            break;
        case Operator::_not:
            gen_not_inst(des, op1);
            break;
        case Operator::load:
            gen_load_inst(des, op1, op2);
            break;
        case Operator::store:
            gen_store_inst(des, op1, op2);
            break;
        case Operator::alloc:
            gen_alloc_inst(des, op1, op2);
            break;
        //以下是浮点数的！！！！！！！！！！！！！！！！！！！
        case Operator::fdef:
        case Operator::fmov:
            if(des.name == "tmp0") return;
            gen_fdef_inst(des, op1);
            break;
        case Operator::fmul:
            gen_fmul_inst(des, op1, op2);
            break;
        case Operator::fdiv:
            gen_fdiv_inst(des, op1, op2);
            break;
        case Operator::fadd:
            gen_fadd_inst(des, op1, op2);
            break;
        case Operator::fsub:
            gen_fsub_inst(des, op1, op2);
            break;
        case Operator::cvt_i2f:
            gen_i2f_inst(des, op1);
            break;
        case Operator::cvt_f2i:
            gen_f2i_inst(des, op1);
            break;
        case Operator::flss:
            gen_flss_inst(des, op1, op2);
            break;
        default:
            break;
    }
}

void backend::Generator::gen_not_inst(ir::Operand des, ir::Operand op1) {
    //第一个操作数为立即数的情况
    if(op1.type == Type::IntLiteral) {
        if(op1.name == "0") fout << LI_INST(getRd(des), 1).draw();
        else if(op1.name == "1") fout << LI_INST(getRd(des), 0).draw();
        else {
            assert(0 && "In Generator::gen_not_inst");
        }
    }
    else {
        fout << "\tseqz\t" << toString(getRd(des)) << ", " << toString(getRs1(op1)) << "\n";
    }
}
void backend::Generator::gen_lss_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    rv_inst inst;
    //暂时只考虑第二个为操作数的情况
    //这里要考虑65535越界的情况
    if(op2.type == Type::IntLiteral) {
        if(str2int(op2.name) >= 2047) {
            fout << LI_INST(AUXIREG, str2int(op2.name)).draw();
            inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs1(op1), AUXIREG, {}, {});
        }
        else {
            inst = rv_inst(rvOPCODE::SLTI, getRd(des), getRs1(op1), {}, str2int(op2.name), {});
        }
    }
    else if(op2.type == Type::Int) {
        inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs1(op1), getRs2(op2),{},{});
    }
    else assert(0 && "In gen_lss_inst");
    fout << inst.draw();
}
void backend::Generator::gen_gtr_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    rv_inst inst;
    //暂时只考虑第二个为操作数的情况
    if(op2.type == Type::IntLiteral) {
        rv_inst li_inst = LI_INST(AUXIREG, str2int(op2.name));
        fout << li_inst.draw();
        inst = rv_inst(rvOPCODE::SLT, getRd(des), AUXIREG, getRs1(op1), {}, {});
    }
    else {
        inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs2(op2), getRs1(op1), {}, {});
    }
    fout << inst.draw();
}
// a <= b   <=> b < a
void backend::Generator::gen_leq_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //第五十个测试点有的 leq  des, op1,  100
    if(op2.type == Type::IntLiteral) {
        fout << LI_INST(AUXIREG, str2int(op2.name)).draw();
        fout << rv_inst(rvOPCODE::SLT, getRd(des), AUXIREG, getRs1(op1), {}, {}).draw();
    }
    else {
        rv_inst inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs2(op2), getRs1(op1), {}, {});
        fout << inst.draw();
    }
    fout << "\tseqz\t" << toString(getRd(des)) << "," <<toString(getRd(des)) << "\n";
}
// a >= b   <=> a < b
void backend::Generator::gen_geq_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
     //暂时不考虑立即数的情况, 要考虑了
     rv_inst inst;
     if(op2.type == Type::IntLiteral) {
        fout << LI_INST(AUXIREG, str2int(op2.name)).draw();
        inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs2(op1), AUXIREG, {}, {});
     }
     else {
        inst = rv_inst(rvOPCODE::SLT, getRd(des), getRs2(op1), getRs1(op2), {}, {});
     }
    fout << inst.draw();
    fout << "\tseqz\t" << toString(getRd(des)) << "," <<toString(getRd(des)) << "\n";
}
// a != b
void backend::Generator::gen_neq_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    rv_inst inst;
    if(op2.type == Type::IntLiteral) {
        inst = rv_inst(rvOPCODE::XORI, getRd(des), getRs1(op1), {}, str2int(op2.name), {});
    }
    else {
        inst = rv_inst(rvOPCODE::XOR, getRd(des), getRs1(op1), getRs2(op2), {}, {});
    }
    fout << inst.draw();
}
// or   and
void backend::Generator::gen_orand_inst(ir::Operator op, ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //暂时不考虑立即数的情况
    //考虑短路问题：比如 3 && 4 = 0离谱
    //那么就对操作数强制转化为0或1, 使用snez
    fout << "\tsnez\t" << toString(getRd(op1)) << "," << toString(getRd(op1)) << "\n";
    fout << "\tsnez\t" << toString(getRd(op2)) << "," << toString(getRd(op2)) << "\n";
    rv_inst inst;
    inst.op = CompareEq(op, Operator::_and, rvOPCODE::AND, rvOPCODE::OR);
    inst.rd = getRd(des);
    inst.rs1 = getRs1(op1);
    inst.rs2 = getRs2(op2);
    fout << inst.draw();
    return;
}

void backend::Generator::gen_eq_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //现在只考虑第二操作数为立即数的情况, 如果两个操作数都是立即数那就是你前端很low
    if(op2.type == Type::IntLiteral) {
        rv_inst li_inst = LI_INST(AUXIREG, str2int(op2.name));
        rv_inst xor_inst = rv_inst(rvOPCODE::XOR, getRd(des), getRs1(op1), AUXIREG, {}, {});
        fout << li_inst.draw() << xor_inst.draw();
    }
    else if(op1.type == Type::IntLiteral) {
        rv_inst li_inst = LI_INST(AUXIREG, str2int(op1.name));
        rv_inst xor_inst = rv_inst(rvOPCODE::XOR, getRd(des), AUXIREG,getRs1(op2) , {}, {});
        fout << li_inst.draw() << xor_inst.draw();
    }
    else {
        rv_inst xor_inst = rv_inst(rvOPCODE::XOR, getRd(des), getRs1(op1),getRs2(op2), {}, {});
        fout << xor_inst.draw();
    }
    fout << "\tseqz\t" << toString(getRd(des)) << "," << toString(getRd(des)) << "\n";
}
void backend::Generator::gen_def_inst(Operand des, Operand op1) {
    rv_inst inst;
    if(op1.type == Type::IntLiteral) {
        if(op1.name == "0") {
            //全局变量
            if (isGlobalVar(des.name)) {
                HI_GLOBL(AUXIREG, des.name);
                fout << "\tsw\t" << toString(rvREG::X0) << ",\%lo(" << des.name << ")(" << toString(AUXIREG) << ")\n";
            }
            else if(isLocalVars(des.name)){
                //sw zero, offset(s0)
                inst =  SW_INST(rvREG::X0, currStack.find_operand(des));
                fout << inst.draw();
            }
            else {
                if(citeCnt[des.name] != 0) {
                    fout << "\tmv\t" << toString(getRd(des)) << ",zero\n"; 
                }
            }
        }
        //mov global_a, 5 处理全局变量的情况
        else if(isGlobalVar(des.name)) {
            //lui a7, %hi(global_a)  这里借用一下a7寄存器
            HI_GLOBL(AUXIREG, des.name);
            Operand tmp = Operand("$tmp", Type::null);
            rv_inst inst_li =  LI_INST(getRd(tmp), str2int(op1.name));
            fout << inst_li.draw();
            fout << "\tsw\t" << toString(getRd(tmp)) << ",\%lo(" << des.name << ")(" << toString(AUXIREG) << ")\n";
            //这里需要释放寄存器的分配, 因他只是简单的存储操作, 不需要长期保留
            freeReg(tmp.name);
        }
        else {
            inst = LI_INST(AUXIREG, str2int(op1.name));
            rv_inst inst2 = SW_INST(AUXIREG, currStack.find_operand(des));
            fout << inst.draw() << inst2.draw();
            return;
        }
    }
    else {
        //处理全局变量的情况op1为全局变量
        if(isGlobalVar(op1.name)) {
            //取高位: 使用a7作辅助寄存器!!!!!!!!!!!!!!
            HI_GLOBL(AUXIREG, op1.name);
            //取低位
            LO_GLOBL(getRd(des), op1.name, AUXIREG);
        }
        else if(isLocalVars(des.name)){
            //des为局部变量
            inst = SW_INST(getRs1(op1), currStack.find_operand(des));
            fout << inst.draw();
        }
        else if(isGlobalVar(des.name)) {
            HI_GLOBL(AUXIREG, des.name);
            fout << "\tsw\t" << toString(getRs1(op1)) << ",\%lo(" << des.name << ")(" << toString(AUXIREG) << ")\n";
        }
        else {
            //如果是函数参数
            if(isFuncParam(op1.name)) {
                //寻找次序, 超过8个参数上限
                int pos = currParamLists[op1.name];
                if(pos > 7) {
                    inst = LW_INST(getRd(des), (pos - 8)*byte4);
                    fout << inst.draw();
                    return;
                }
            }
            inst = LW_INST(getRd(des), currStack.find_operand(op1));
            fout << inst.draw();
        }
    }
}
// add a, b, c
void backend::Generator::gen_add_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //fout << "#In add inst:\n";
    rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRs1(op1), getRs2(op2), {}, {});
    fout << add_inst.draw();
}
bool isInteger(std::string& str) {  
    try {  
        std::stoi(str);  
        return true;  
    } catch (const std::invalid_argument&) {  
        return false;  
    } catch (const std::out_of_range&) {  
        return false;  
    }  
}  
//sub 0 b;
void backend::Generator::gen_sub_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //fout << "#In sub inst:\n";
    rv_inst sub_inst;
    //存在第一个操作数为0的情况,震惊我了！
    if(op1.type == Type::IntLiteral) {
        //存在两个字面量, 无语了.....  test51
        if(isInteger(op2.name)) {
            sub_inst = LI_INST(getRd(des), str2int(op1.name) - str2int(op2.name));
        }
        else {
            rv_inst li_inst  = LI_INST(AUXIREG, str2int(op1.name));
            fout << li_inst.draw();
            sub_inst = rv_inst(rvOPCODE::SUB, getRd(des), AUXIREG, getRs2(op2), {}, {});
        }
    }
    else {
        sub_inst = rv_inst(rvOPCODE::SUB, getRd(des), getRs1(op1), getRs2(op2), {}, {});
    }
    fout << sub_inst.draw();
}

void backend::Generator::gen_mul_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //第二个操作数为立即数的时候可以优化的, 但是这里先不考虑
    rv_inst mul_inst;
    if(op2.type == Type::IntLiteral) {
        //两个字面量真服了
        if(op1.type == Type::IntLiteral) {
            rv_inst li_inst = LI_INST(getRd(des), str2int(op1.name) * str2int(op2.name));
            fout << li_inst.draw();
            return;
        }
        rv_inst li_inst  = LI_INST(AUXIREG, str2int(op2.name));
        fout << li_inst.draw();
        mul_inst = rv_inst(rvOPCODE::MUL, getRd(des), getRs1(op1), AUXIREG, {}, {});
    }
    else {
        mul_inst = rv_inst(rvOPCODE::MUL, getRd(des), getRs1(op1), getRs2(op2), {}, {});
    }
    fout << mul_inst.draw();
}
void backend::Generator::gen_div_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //第二个操作数为立即数的时候可以优化的, 但是这里先不考虑
    rv_inst div_inst;
    if(op2.type == Type::IntLiteral) {
        rv_inst li_inst  = LI_INST(AUXIREG, str2int(op2.name));
        fout << li_inst.draw();
        div_inst = rv_inst(rvOPCODE::DIV, getRd(des), getRs1(op1), AUXIREG, {}, {});
    }
    else {
        div_inst = rv_inst(rvOPCODE::DIV, getRd(des), getRs1(op1), getRs2(op2), {}, {});
    }
    fout << div_inst.draw();
}
void backend::Generator::gen_mod_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //先只考虑第二个操作数为立即数的情况
    if(op2.type == Type::IntLiteral) {
        rv_inst li_inst =  LI_INST(AUXIREG, str2int(op2.name));
        rv_inst rem_inst = rv_inst(rvOPCODE::REM, getRd(des), getRs1(op1), AUXIREG, {}, {});
        fout << li_inst.draw() << rem_inst.draw();
    }
    else {
        rv_inst rem_inst = rv_inst(rvOPCODE::REM, getRd(des), getRs1(op1), getRs2(op2), {}, {});
        fout << rem_inst.draw();
    }
}
//addi a, b, 2  //subi
void backend::Generator::gen_addi_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //fout << "#In addi inst: \n";
    rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, getRd(des), getRs1(op1),{}, str2int(op2.name), {});
    fout << addi_inst.draw();
}

void backend::Generator::gen_call_inst(ir::Instruction& inst) {
    //强制转换, 获取函数的参数
    auto callInst = dynamic_cast<const ir::CallInst *>(&inst);
    auto params = callInst->argumentList;
    if(callInst->op1.name != "putint" && callInst->op1.name != "putch" && 
        callInst->op1.name != "getint" && callInst->op1.name != CurrScope){
            callerSave();
            callerFSave();
        }
    //先处理有参数的情况
    if(params.size()) {
        if(params.size() > 4) {
            //参数不多于8的情况, 使用
            rvREG tmpreg = rvREG::X31;
            size_t i;
            for(i = 0; i < 8; i++) {
                if(isGlobalVar(params[i].name)) {
                    //如果是全局变量
                    HI_GLOBL(tmpreg, params[i].name);
                    LO_GLOBL(tmpreg, params[i].name, tmpreg);
                    fout << "\tmv\t" << toString(paramsRegs[i]) << "," << toString(tmpreg) <<"\n";
                }
                else TODO;
            }
            //参数大于8, 就需要使用栈了, top栈的使用
            int topOffset = 0;
            for(size_t j = i; j < params.size(); j++) {
                if(isGlobalVar(params[j].name)) {
                    //如果是全局变量
                    HI_GLOBL(tmpreg, params[j].name);
                    LO_GLOBL(tmpreg, params[j].name, tmpreg);
                    fout << "\tsw\t" << toString(tmpreg) << "," << topOffset << "(sp)\n";
                    topOffset += byte4;
                }
                else TODO;
            }
        }
        else {
            int paramPos = 0;  //逐个分配参数寄存器
            for(auto &param: callInst->argumentList){
                //考虑全局变量的情况, 使用a7寄存器临时存放
                if(isGlobalVar(param.name)) {
                    //要考虑指针
                    if(param.type == Type::IntPtr) {
                        HI_GLOBL(AUXIREG, param.name);
                        fout << "\taddi\t" + toString(paramsRegs[paramPos]) + "," + toString(AUXIREG) + ",\%lo(" + param.name + ")\n";
                    }
                    else {
                        HI_GLOBL(AUXIREG, param.name);
                        LO_GLOBL(AUXIREG, param.name, AUXIREG);
                        fout << "\tmv\t" << toString(paramsRegs[paramPos]) << "," << toString(AUXIREG) <<"\n";
                    }
                }
                else if(param.type == Type::IntLiteral) {
                    //立即数的情况
                    fout << LI_INST(paramsRegs[paramPos], str2int(param.name)).draw();
                }
                //浮点立即数型
                else if(param.type == Type::FloatLiteral) {
                    FLI_INST(AUXIREG, bit_extend(str2flt(param.name)));
                    fout << "\tfmv.w.x\t" << toString(FAUXIREG) << "," << toString(AUXIREG) << "\n";
                    fout << "\tfmv.s\t" << toString(FparamRegs[paramPos]) << "," << toString(FAUXIREG) << "\n";
                }
                else if(isLocalVars(param.name)) {
                    //没考虑到局部指针.....新增bug
                    if(param.type == Type::Int) {
                        rv_inst inst_lw = LW_INST(paramsRegs[paramPos], currStack.find_operand(param));
                        fout << inst_lw.draw();
                    }
                    else if(param.type == Type::Float) {
                        //fout << "\tfcvt.d.s\t" << toString(fgetRd(param)) << ", " << toString(fgetRd(param)) << "\n";
                        fout << "\tfmv.s\t" << toString(FparamRegs[paramPos]) << "," << toString(fgetRs1(param)) << "\n";
                    }
                    //指针的情况
                    else if((param.type == Type::IntPtr || param.type == Type::FloatPtr) && !isFuncParam(param.name)) {
                        //addi a7, s0, -offset
                        rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, AUXIREG, rvREG::X8,{}, currStack.find_operand(param), {});
                        fout << addi_inst.draw();
                        fout << "\tmv\t" << toString(paramsRegs[paramPos]) << "," << toString(AUXIREG) <<"\n";
                    }
                    //函数里面调用即可
                    else if(param.type == Type::IntPtr && isFuncParam(param.name)) {
                        rv_inst inst_lw = LW_INST(paramsRegs[paramPos], currStack.find_operand(param));
                        fout << inst_lw.draw();
                    }
                    else assert(0 && "[gen_call_inst] Need to pay attention!");
                    
                }
                else {
                    if(param.type == Type::Int) {
                        // if(param.name == "$tmp_84") fout << "#cnt: " << citeCnt[param.name] << "\n";
                        fout << "\tmv\t" << toString(paramsRegs[paramPos]) << "," << toString(getRs1(param)) <<"\n";
                        // if(param.name == "$tmp_84") fout << "#cnt: " << citeCnt[param.name] << "\n";
                    }
                    else {
                        fout << "\tfmv.s\t" << toString(FparamRegs[paramPos]) << ", " << toString(fgetRs1(param)) <<"\n";
                    }
                }
                paramPos++;
            } 
        }
    }
    fout << "\tcall\t" << callInst->op1.name << "\n";
    //参数返回
    if(callInst->des.type != Type::null) {
        if(callInst->des.type == Type::Int) {
            fout << "\tmv\t"   << toString(getRd(callInst->des)) << ",a0\n";
            if(callInst->op1.name != "putint" && callInst->op1.name != "putch" && 
            callInst->op1.name != "getint" && callInst->op1.name != CurrScope){
                calleeRestore(getRd(callInst->des));
        }
        }
        else {
            fout << "\tfmv.s\t"   << toString(fgetRd(callInst->des)) << ",fa0\n";
            calleeFRestore(fgetRd(callInst->des));
        }
    }
    else {
        if(callInst->op1.name != "putint" && callInst->op1.name != "putch" && 
        callInst->op1.name != "getint" && callInst->op1.name != CurrScope){
            calleeRestore(rvREG::X27);
        }
    }
    if(citeCnt[callInst->des.name] < 0) {
        freeReg(callInst->des.name);//没有用就及时释放!!!!!
    }    
}

/**
 * @brief return语句
*/
void backend::Generator::gen_return_inst(Operand op1, bool end, int spOffset) {
    //return 0
    if(op1.type == Type::IntLiteral) {
        rv_inst li_inst = LI_INST(rvREG::X10, str2int(op1.name));
        fout << li_inst.draw();
        if(!end) gen_func_tail(spOffset);
    }
    else if(op1.type == Type::Float) {
        fout << "\tfmv.s\tfa0," << toString(fgetRs1(op1)) << "\n";
        if(!end) gen_func_tail(spOffset);
    }
    else if(op1.type!=Type::null) {
        rv_inst mv_inst = rv_inst(rvOPCODE::MOV, rvREG::X10, getRs1(op1), {}, {}, {});
        fout << mv_inst.draw();
    }
}

/**
 * @brief goto des : if op1 goto des
*/
void backend::Generator::gen_goto_inst(Operand des, Operand op1, int pos) {
    //fout << "#In goto:\n";
    //goto des:   J label
    rv_inst j_inst;
    if(op1.type == Type::null) {
        j_inst = rv_inst(rvOPCODE::J, {}, {}, {}, {}, labelMap[pos + str2int(des.name)]);
        fout << j_inst.draw();
    }
    else if(op1.name == "1") {
        j_inst = rv_inst(rvOPCODE::J, {}, {}, {}, {}, labelMap[pos + str2int(des.name)]);
        fout << j_inst.draw();
        return;
    }
    else if(op1.name == "0") {
        return;
    }
    else if(op1.type == Type::Int){
        fout << "\tbnez\t" << toString(getRs1(op1)) << ", " << labelMap[pos + str2int(des.name)] << "\n";
    }
    else {
        fout << "\tbnez\t" << toString(getRs1(op1)) << ", " << labelMap[pos + str2int(des.name)] << "\n";
    }
}

void backend::Generator::gen_alloc_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {

}
void backend::Generator::gen_load_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    /**
     * load des, arr, offset
     *      des  op1   op2
     * 首先应该将des做引用计数, offset做引用计数++, 这个在预处理就得做
     * 
    */
   //处理局部变量
    if(isLocalVars(op1.name)) {
        //load des, arr, 0/1
        if(op2.type == Type::IntLiteral){
            //计算偏移量
            int offset = currStack.find_operand(op1) + byte4*str2int(op2.name);
            fout << LW_INST(getRd(des), offset).draw();
            //局部参数的情况, 要根据指针来
            if(isFuncParam(op1.name)) {
                fout << "\tlw\t" << toString(getRd(des)) << ",0(" << toString(getRd(des)) << ")\n";
            }
        }
        //load des, arr, tmp
        else {
            if(!isFuncParam(op1.name)) {
                if(op1.type == Type::IntPtr) {
                    rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                    //addi   a5, s0, -52
                    rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, getRd(des), rvREG::X8, {}, currStack.find_operand(op1), {});
                    rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRd(des), getRs2(op2), {},{});
                    fout << slli_inst.draw() << addi_inst.draw() << add_inst.draw();
                    fout << "\tlw\t" << toString(getRd(des)) << ",0(" << toString(getRd(des)) << ")\n";
                }
                else if(op1.type == Type::FloatPtr) {
                    rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                    rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, getRd(des), rvREG::X8, {}, currStack.find_operand(op1), {});
                    rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRd(des), getRs2(op2), {},{});
                    fout << slli_inst.draw() << addi_inst.draw() << add_inst.draw();
                    fout << "\tflw\t" << toString(fgetRd(des)) << ",0(" << toString(getRs1(des)) << ")\n"; 
                }
                else {
                    fout << "# Todo!\n";
                }
            }
            else {
                rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                rv_inst lw_inst = LW_INST(getRd(des), currStack.find_operand(op1));
                rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRd(des), getRs2(op2), {},{});
                fout << slli_inst.draw() << lw_inst.draw() << add_inst.draw();
                fout << "\tlw\t" << toString(getRd(des)) << ",0(" << toString(getRd(des)) << ")\n";
            }
            
        }
    }
    //处理全局变量的情况
    else if(isGlobalVar(op1.name)) {
        if(op2.type == Type::IntLiteral) {
            //操作数2是立即数
            HI_GLOBL(AUXIREG, op1.name);
            fout << "\taddi\t" << toString(AUXIREG) << "," << toString(AUXIREG) << ",\%lo(" << op1.name <<")\n";
            fout << "\tlw\t" << toString(getRd(des)) << "," << str2int(op2.name)*byte4 <<"(" << toString(AUXIREG) << ")\n";
        }
        else {
            rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
            fout << slli_inst.draw();
            HI_GLOBL(AUXIREG, op1.name);
            fout << "\taddi\t" << toString(getRd(des)) << "," << toString(AUXIREG) << ",\%lo(" << op1.name <<")\n";
            rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRd(des), getRd(op2), {},{});
            fout << add_inst.draw();
            fout << "\tlw\t" << toString(getRd(des)) << ",0(" << toString(getRd(des)) << ")\n";
            //给op2复原
            rv_inst srli_inst = rv_inst(rvOPCODE::SRLI, getRs1(op2), getRd(op2), {}, 2, {});
            fout << srli_inst.draw();
        }
    }
    else {
        assert(0 && "No array Name Found in gen_load_inst");
    }
}
void backend::Generator::gen_store_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //处理局部变量的情况
    if(isLocalVars(op1.name)) {
        //下标已知
        if(op2.type == Type::IntLiteral){
            if(des.type == Type::IntLiteral || des.type == Type::FloatLiteral) {
                if(!isFuncParam(op1.name)) {
                    if(des.name == "0" || des.name == "0.0") fout << SW_INST(rvREG::X0, currStack.find_operand(op1)+ byte4*str2int(op2.name)).draw();
                    else 
                    {
                        if(des.type == Type::IntLiteral) {
                            fout << LI_INST(AUXIREG, str2int(des.name)).draw();
                            fout << SW_INST(AUXIREG, currStack.find_operand(op1)+ byte4*str2int(op2.name)).draw();
                        }
                        else {
                            //li a7, 长整型
                            FLI_INST(AUXIREG, bit_extend(str2flt(des.name)));
                            //fmv.w.x   fa7, a7
                            fout << "\tfmv.w.x\t" << toString(FAUXIREG) << "," << toString(AUXIREG) << "\n";
                            FSW_INST(FAUXIREG, currStack.find_operand(op1)+ byte4*str2int(op2.name));
                        }
                    }
                }
                //局部函数参数
                else {
                    fout << LW_INST(getRd(op1), currStack.find_operand(op1)+ byte4*str2int(op2.name)).draw();
                    if(des.name == "0") {
                        fout << "\tsw\t" << toString(rvREG::X0) << ",0(" << toString(getRd(op1)) << ")\n";
                    }
                    else {
                        fout << LI_INST(AUXIREG, str2int(des.name)).draw();
                        fout << "\tsw\t" << toString(AUXIREG) << ",0(" << toString(getRd(op1)) << ")\n";
                    }
                    freeReg(op1.name); //注意释放寄存器!!!
                }
                
            }
            else {
                if(!isFuncParam(op1.name)) {
                    fout << "\tsw\t" << toString(getRs1(des)) << "," << currStack.find_operand(op1) + byte4*str2int(op2.name) << "(s0)\n"; 
                }
                else {
                    fout << LW_INST(getRd(op1), currStack.find_operand(op1)+ byte4*str2int(op2.name)).draw();
                    fout << "\tsw\t" << toString(getRs1(des)) << ",0(" << toString(getRd(op1)) << ")\n";
                    freeReg(op1.name); //注意释放寄存器!!!
                }
            }
        }
        else {
            //这是当前函数的数组
             if(!isFuncParam(op1.name)) {
                if(op1.type == Type::IntPtr) {
                    rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                    //addi   a7, s0, -52
                    rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, AUXIREG, rvREG::X8, {}, currStack.find_operand(op1), {});
                    rv_inst add_inst = rv_inst(rvOPCODE::ADD, AUXIREG, AUXIREG, getRs2(op2), {},{});
                    fout << slli_inst.draw() << addi_inst.draw() << add_inst.draw();
                    fout << "\tsw\t" << toString(getRd(des)) << ",0(" << toString(AUXIREG) << ")\n";
                }
                else if(op1.type == Type::FloatPtr) {
                    rv_inst slli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                    rv_inst addi_inst = rv_inst(rvOPCODE::ADDI, getRd(des), rvREG::X8, {}, currStack.find_operand(op1), {});
                    rv_inst add_inst = rv_inst(rvOPCODE::ADD, getRd(des), getRd(des), getRs2(op2), {},{});
                    fout << slli_inst.draw() << addi_inst.draw() << add_inst.draw();
                    fout << "\tfsw\t" << toString(fgetRs1(des)) << ",0(" << toString(getRs1(des)) << ")\n"; 
                }  
                else fout << "# ToDO\n";
            }
            else {  //这是传参进来的
                //我们假定它一定出现过
                rv_inst ssli_inst = rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {});
                fout << ssli_inst.draw();
                fout << LW_INST(AUXIREG, currStack.find_operand(op1)).draw();
                fout << rv_inst(rvOPCODE::ADD, AUXIREG, AUXIREG, getRs2(op2), {}, {}).draw();
                fout << "\tsw\t" << toString(getRs1(des)) << ",0(" << toString(AUXIREG) << ")\n";
            }
            
        }
    }
    else if(isGlobalVar(op1.name)) {
        //全局变量没处理啊?????????
        if(op2.type == Type::Int && des.type == Type::Int) {
            //des: a5
            //先对op2进行左移处理 slli  a4, a4, 2
            fout << rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {}).draw();
            //取全局数组: lui	a7,%hi(array)
            HI_GLOBL(AUXIREG, op1.name);
            //addi	a7,a7,%lo(array)
            fout << "\taddi\t" << toString(AUXIREG) << "," << toString(AUXIREG) << ",\%lo(" << op1.name << ")\n";
            //add   a4, a4, a7
            fout << rv_inst(rvOPCODE::ADD, getRd(op2), getRd(op2), AUXIREG, {}, {}).draw();
            //sw    a5,0(a4) //并释放
            fout << "\tsw\t"  << toString(getRd(des)) << ",0(" << toString(getRd(op2)) << ")\n";
            freeReg(des.name);
            freeReg(op2.name);
        }
        //store 5, arr, 0
        else if(op2.type == Type::IntLiteral && des.type == Type::IntLiteral) {
            //取全局数组: lui	a7,%hi(array)
            HI_GLOBL(AUXIREG, op1.name);
            //addi	a7,a7,%lo(array)
            fout << "\taddi\t" << toString(AUXIREG) << "," << toString(AUXIREG) << ",\%lo(" << op1.name << ")\n";
            if(des.name == "0") {
                fout << "\tsw\t" << toString(rvREG::X0) << "," << str2int(op2.name) * byte4 << "(" << toString(AUXIREG) << ")\n";
            }
            else {
                fout << LI_INST(getRd(op1), str2int(des.name)).draw();
                //保证寄存器释放
                fout << "\tsw\t" << toString(getRs1(op1)) << "," << str2int(op2.name) * byte4 << "(" << toString(AUXIREG) << ")\n";
            }
        }
        else if(op2.type == Type::Int && des.type == Type::IntLiteral) {
             //op1: a5
            //先对op2进行左移处理 slli  a4, a4, 2
            fout << rv_inst(rvOPCODE::SLLI, getRd(op2), getRd(op2), {}, 2, {}).draw();
            //取全局数组: lui	a7,%hi(array)
            HI_GLOBL(AUXIREG, op1.name);
            //addi	a7,a7,%lo(array)
            fout << "\taddi\t" << toString(AUXIREG) << "," << toString(AUXIREG) << ",\%lo(" << op1.name << ")\n";
            //add   a4, a4, a7
            fout << rv_inst(rvOPCODE::ADD, getRd(op2), getRd(op2), AUXIREG, {}, {}).draw();
            //sw    zero,0(a4) //并释放
            if(des.name == "0") {
                fout << "\tsw\t"  << toString(rvREG::X0) << ",0(" << toString(getRs2(op2)) << ")\n";
            }
            else {
                //li
                fout << LI_INST(getRd(op1),str2int(des.name)).draw();
                fout << "\tsw\t"  << toString(getRs1(op1)) << ",0(" << toString(getRs2(op2)) << ")\n";
            }
        }
    }
    else assert(0 && "Unknown Error in gen_store_inst!");
}



void backend::Generator::gen() {
    //先处理全局变量, 将全局变量的函数也就是所有函数的一个指令一同传入
    put2(TEXT);   //提示进入代码区
    for(const auto& var: program.globalVal) {
        //如果类型是立即数, 那么不需要做任何事, 因为会在源代码中进行全部替换
        if(ISLiteral(var.val.type)) continue;
        gen_global(var, program.functions.front().InstVec);
    }
    put2(TEXT);   //提示进入代码区
    //然后处理所有函数, 不处理全局函数了, 因为已经在全局变量的时候进行初始化过了
    for(auto& func: program.functions) {
        if(func.name != Function_GLOBAL){
            gen_func(func);
        }
    }
}

//以下是针对浮点数:  好像没有全局调用的情况, 那么我就不客气了
void backend::Generator::gen_fdef_inst(ir::Operand des, ir::Operand op1) {
    //浮点型
    if(op1.type == Type::FloatLiteral) {
        //初始化
        if(op1.name == "0.0") {
            // sw  zero, offset(s0)
            fout << SW_INST(rvREG::X0, currStack.find_operand(des)).draw();
        }
        //立即数常量应该经过转换
        else if(isLocalVars(des.name)){
            FLI_INST(AUXIREG, bit_extend(str2flt(op1.name)));
            fout << "\tfmv.w.x\t" << toString(FAUXIREG) << "," << toString(AUXIREG) << "\n";
            FSW_INST(FAUXIREG, currStack.find_operand(des));
        }
        else {
            FLI_INST(AUXIREG, bit_extend(str2flt(op1.name)));
            fout << "\tfmv.w.x\t" << toString(fgetRd(des)) << "," << toString(AUXIREG) << "\n";
        }
    }
    //取数
    else if(isLocalVars(op1.name)) {
        FLW_INST(fgetRd(des), currStack.find_operand(op1)); 
    }
    //存数
    else if(isLocalVars(des.name)) {
        //说明是整型过来的
        if(tmpToReg.find(op1.name) != tmpToReg.end()) {
            fout << "\tfcvt.s.w\t" << toString(fgetRd(des)) << "," << toString(getRs1(op1)) << "\n";
            FSW_INST(fgetRs1(des), currStack.find_operand(des));
        }
        else {
            FSW_INST(fgetRd(op1), currStack.find_operand(des));
        }
    }
}
void backend::Generator::gen_fmul_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //保证全部都是浮点数
    fout << "\tfmul.s\t" + toString(fgetRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(fgetRs2(op2)) + "\n";
}
void backend::Generator::gen_fdiv_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    fout << "\tfdiv.s\t" + toString(fgetRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(fgetRs2(op2)) + "\n";
}
void backend::Generator::gen_fadd_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    if(isLocalVars(op2.name)) {
        FLW_INST(FAUXIREG, currStack.find_operand(op2));
        fout << "\tfadd.s\t" + toString(fgetRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(FAUXIREG) + "\n";
    }
    else {
        fout << "\tfadd.s\t" + toString(fgetRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(fgetRs2(op2)) + "\n";
    }
    
}
void backend::Generator::gen_fsub_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    if(op1.name == "0.0") {
        fout << "\tfmv.s.x\t" + toString(FAUXIREG) + "," + toString(rvREG::X0) + "\n";
        fout << "\tfsub.s\t" + toString(fgetRd(des)) + "," + toString(FAUXIREG) + "," + toString(fgetRs2(op2)) + "\n";
    }
    else {
        fout << "\tfsub.s\t" + toString(fgetRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(fgetRs2(op2)) + "\n";
    }
}
void backend::Generator::gen_flss_inst(ir::Operand des, ir::Operand op1, ir::Operand op2) {
    //这里op2一定为立即数, 这里多多少少有不严谨的地方
    if(op2.name == "0.000001") {
        fout << "\tli\ta7," << bit_extend(0.000001) << "\n";
        fout << "\tfmv.s.x\t" + toString(FAUXIREG) + "," + toString(AUXIREG) + "\n";
        fout << "\tflt.s\t" + toString(getRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(FAUXIREG) + "\n";
    }
    else {
        fout << "\tfmv.s.x\t" + toString(FAUXIREG) + "," + toString(rvREG::X0) + "\n";
        fout << "\tflt.s\t" + toString(getRd(des)) + "," + toString(fgetRs1(op1)) + "," + toString(FAUXIREG) + "\n";
    }
    
}
void backend::Generator::gen_i2f_inst(ir::Operand des, ir::Operand op1) {
    fout << "\tfcvt.s.w\t" + toString(fgetRd(des)) + "," + toString(getRs1(op1)) + "\n";
}
void backend::Generator::gen_f2i_inst(ir::Operand des, ir::Operand op1) {
    //向零舍入
    fout << "\tfcvt.w.s\t" + toString(getRd(des)) + "," + toString(fgetRs1(op1)) + ",rtz\n";
}

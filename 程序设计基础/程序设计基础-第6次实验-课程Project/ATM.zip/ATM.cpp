#include "ATM.h"

void welcomeMessage() {
    cout << "Welcome to the ATM!" << endl;
    cout << "Please enter your account number:";
    string accountNumber;
    cin >> accountNumber;

    while (!isAccountExist(accountNumber)) {
        cout << "The account does not exist. Try again." << endl;
        cin >> accountNumber;
    }

    cout << "Please enter your name:";
    string name;
    cin >> name;

    cout << "Please enter your id:";
    string id;
    cin >> id;

    cout << "Please enter your password:";
    string password;
    cin >> password;

    int errorAttempts = 2;
    while (!checkPassword(accountNumber, password)) {
        if (errorAttempts == 0) {
            cout << "Your account has been frozen" << endl;
            cout << "Please contact the administrator" << endl;
            welcomeMessage();
        }
        cout << "Wrong password. Try again." << endl;
        errorAttempts--;
        cin >> password;
    }

    displayMenu();
    performOperation(accountNumber);
}

void displayMenu() {
    cout << "Main Menu:" << endl;
    cout << "   1 - View my balance" << endl;
    cout << "   2 - Withdraw cash" << endl;
    cout << "   3 - Deposit Funds" << endl;
    cout << "   4 - Change Password" << endl;
    cout << "   5 - Exit" << endl;
}

void performOperation(const string& accountNumber) {
    int choice;
    do {
        cout << "Enter your choice:";
        cin >> choice;

        switch (choice) {
            case 1:balanceInquiry(accountNumber);
                break;
            case 2:withdrawal(accountNumber);
                break;
            case 3:transfer(accountNumber);
                break;
            case 4:changePassword(accountNumber);
                break;
            case 5:welcomeMessage();
            default:cout << "Invalid choice. Try again." << endl;
        }
    } while (true);
}

void balanceInquiry(const string& accountNumber) {
    User tmpUser;
    tmpUser.loadData(accountNumber + ".txt");
    cout << "Balance: " << tmpUser.balance << endl;
}

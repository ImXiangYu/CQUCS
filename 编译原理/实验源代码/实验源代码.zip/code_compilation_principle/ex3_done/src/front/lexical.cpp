#include"front/lexical.h"
#include"front/lexical_func.h"
#include<map>
#include<cassert>
#include<string>

#define TODO assert(0 && "todo")

// #define DEBUG_DFA
// #define DEBUG_SCANNER

std::string frontend::toString(State s) {
    switch (s) {
    case State::Empty:          return "Empty";
    case State::Ident:          return "Ident";
    case State::IntLiteral:     return "IntLiteral";
    case State::FloatLiteral:   return "FloatLiteral";
    case State::op:             return "op";
    default:                    assert(0 && "invalid State");
    }
    return "";
}
std::set<std::string> frontend::keywords= {
    "const", "int", "float", "if", "else", "while", "continue", "break", "return", "void"
};
frontend::DFA::DFA(): cur_state(frontend::State::Empty), cur_str() {}
frontend::DFA::~DFA() {}
void frontend::DFA::reset() {
    cur_state = State::Empty;
    cur_str = "";
}
bool frontend::DFA::next(char input, Token& buf) {
    switch(cur_state) {
    case State::Empty:
        if(!is_null_char(input))            cur_str += input;               //不为空串时累加
        if(is_operator(input))              cur_state = State::op;          //操作符
        else if(is_number(input))           cur_state = State::IntLiteral;  //整型变量
        else if(is_compound_ident(input))   cur_state = State::Ident;       //标识符
        else if(input == '.')               cur_state = State::FloatLiteral; //浮点数
        return false;
    case State::IntLiteral:
        //继续增加数字
        if(is_number(input) || isalpha(input)) {
            cur_str += input;
            return false;
        }
        //转化为浮点数
        else if(input == '.'){
            cur_str += input;
            cur_state = State::FloatLiteral;
            return false;
        }
        else {
            //本状态结束, 输出对应整数
            buf.value = cur_str;
            buf.type = TokenType::INTLTR;
        }
        //输入空格, eg: 22 ....
        if(is_null_char(input)) reset();
        //下一步输入操作符, eg: 22+
        else if(is_operator(input)){
            cur_state = State::op;
            cur_str = input;
        }
        //else assert(0 && "invalid char after intNumber!");  //不合规, s22A这种情况
        return true;
    case State::FloatLiteral:
        //继续输入数字
        if(is_number(input)) {
            cur_str += input;
            return false;
        }
        else {
            //其他均输出浮点数
            buf.value = cur_str;
            buf.type = TokenType::FLOATLTR;
        }
        if(is_null_char(input)) reset();
        else if(is_operator(input)) {
            cur_state = State::op;
            cur_str = input;
        }
        else assert(0 && "invalid char after float number");  //不合规
        return true;
    case State::Ident:
        //a, _, 2数字之类
        if(is_compound_ident(input) || is_number(input)) {
            cur_str += input;
            return false;
        }
        else {
            buf.value = cur_str;
            buf.type = get_keyword_type(cur_str);
        }
        if(is_null_char(input)) reset();
        else if(is_operator(input)){
            cur_state = State::op;
            cur_str = input;
        }
        return true;
    //输入+-...等op
    case State::op:
        //判断是否为两个字符的操作符
        if(is_compound_op(cur_str + input)){
            buf.value = cur_str + input;
            buf.type = get_op_type(cur_str + input);
            reset();
            return true;
        }
        else {
            buf.value = cur_str;
            buf.type = get_op_type(cur_str);
            cur_str = input;
        }
        //输入空格
        if(is_null_char(input)) reset();
        //_a标识符
        else if(is_compound_ident(input))   cur_state = State::Ident;
        //数字
        else if(is_number(input))           cur_state = State::IntLiteral;
        else if(input == '.')               cur_state = State::FloatLiteral;
        else if(is_operator(input))         cur_state = State::op;
        return true;
    default: assert(0 && "invalid  state");
    }
    return false;
}


frontend::Scanner::Scanner(std::string filename): fin(filename) {
    if(!fin.is_open()) { assert(0 && "in Scanner constructor, input file cannot open");}
}
frontend::Scanner::~Scanner() { fin.close();}

std::vector<frontend::Token> frontend::Scanner::run() {
    //存储Token串
    std::vector<frontend::Token>ret;
    //存放单个tk
    frontend::Token tk;
    //构造DFA
    frontend::DFA dfa;
    //处理文件
    std::string lines = preproccess(fin);
    for(auto c: lines){
        if(dfa.next(c, tk)){
            ret.push_back(tk);
        }
    }
    return ret;
}
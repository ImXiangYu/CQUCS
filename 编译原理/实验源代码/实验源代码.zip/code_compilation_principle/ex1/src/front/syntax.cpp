#include"front/syntax.h"

#include<iostream>
#include<cassert>

using frontend::Parser;

// #define DEBUG_PARSER
#define TODO assert(0 && "todo")
#define CUR_TOKEN_IS(tk_type) (token_stream[index].type == TokenType::tk_type)
#define PARSE_TOKEN(tk_type) root->children.push_back(parseTerm(root, TokenType::tk_type))
#define PARSE(name, type) { auto name = new type(root); assert(parse##type(name)); root->children.push_back(name); }


Parser::Parser(const std::vector<frontend::Token>& tokens): index(0), token_stream(tokens) {}

Parser::~Parser() {}

using frontend::CompUnit;
CompUnit *Parser::get_abstract_syntax_tree(){
    CompUnit *root = new CompUnit();
    parseCompUnit(root);
    return root;
}

using frontend::Term;
Term *Parser::parseTerm(AstNode* parent, TokenType expected){
    if(token_stream[index].type == expected){
        return new Term(token_stream[index++], parent);
    }
    return NULL;
}

/**
 *  CompUnit → ( Decl | FuncDef ) [ CompUnit ]
 * 
 *  Decl -> Const | int | float
 *  FuncDef -> void
 * 
 */
using frontend::CompUnit;
bool Parser::parseCompUnit(CompUnit* root){
    // const ....
    if(CUR_TOKEN_IS(CONSTTK)) PARSE(decl, Decl)
    // int/float main ()
    else if(CUR_TOKEN_IS(INTTK) || CUR_TOKEN_IS(FLOATTK)){
        if(index + 2 < token_stream.size() && token_stream[index + 2].type == TokenType::LPARENT)
           PARSE(funcDef, FuncDef)
        else PARSE(decl, Decl)
    }
    // void ....
    else if(CUR_TOKEN_IS(VOIDTK)) PARSE(funcDef, FuncDef)
    if(CUR_TOKEN_IS(CONSTTK) || CUR_TOKEN_IS(INTTK) || CUR_TOKEN_IS(FLOATTK) || CUR_TOKEN_IS(VOIDTK))
        PARSE(compUnit, CompUnit)
    return true;
}

/**
 * Decl -> ConstDecl | VarDecl
 * ConstDecl: const
 * VarDecl:  int, float
*/
using frontend::Decl;
bool Parser::parseDecl(Decl* root){
    if(CUR_TOKEN_IS(CONSTTK))                             PARSE(const_Decl, ConstDecl)
    else if(CUR_TOKEN_IS(INTTK) || CUR_TOKEN_IS(FLOATTK)) PARSE(varDecl, VarDecl)
    else    return false;
    return true;
}

/**
 * ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
*/
using frontend::ConstDecl;
bool Parser::parseConstDecl(ConstDecl* root){
    // 'const'
    PARSE_TOKEN(CONSTTK);
    PARSE(btype, BType);
    PARSE(constDef, ConstDef);
    // loop: { ',' ConstDef }
    while(CUR_TOKEN_IS(COMMA)) {
        PARSE_TOKEN(COMMA);
        PARSE(constDef, ConstDef);
    }
    PARSE_TOKEN(SEMICN);
    return true;
}


/**
 * BType -> 'int' | 'float'
*/
using frontend::BType;
bool Parser::parseBType(BType* root){
    if(CUR_TOKEN_IS(INTTK))         PARSE_TOKEN(INTTK);
    else if(CUR_TOKEN_IS(FLOATTK))  PARSE_TOKEN(FLOATTK);
    return true;
}

/**
 * ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal
 * 
*/
using frontend::ConstDef;
bool Parser::parseConstDef(ConstDef* root){
    PARSE_TOKEN(IDENFR);
    while(CUR_TOKEN_IS(LBRACK)){
        PARSE_TOKEN(LBRACK);
        PARSE(constExp, ConstExp);
        PARSE_TOKEN(RBRACK);
    }
    PARSE_TOKEN(ASSIGN);
    PARSE(constInitval, ConstInitVal);
    return true;
}

/**
 * ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
*/
using frontend::ConstInitVal;
bool Parser::parseConstInitVal(ConstInitVal* root){
    if(CUR_TOKEN_IS(LBRACE)){
        PARSE_TOKEN(LBRACE);
        if(!CUR_TOKEN_IS(RBRACE)){
            PARSE(constInitVal, ConstInitVal);
            while(CUR_TOKEN_IS(COMMA)){
                PARSE_TOKEN(COMMA);
                PARSE(constInitVal, ConstInitVal);
            }
        }
        PARSE_TOKEN(RBRACE);
    }
    else PARSE(constExp, ConstExp);
    return true;
}


/**
 * VarDecl -> BType VarDef { ',' VarDef } ';'
*/
using frontend::VarDecl;
bool Parser::parseVarDecl(VarDecl* root){
    PARSE(btype, BType);
    PARSE(vardef, VarDef);
    while(CUR_TOKEN_IS(COMMA)){
        PARSE_TOKEN(COMMA);
        PARSE(vardef, VarDef);
    }
    PARSE_TOKEN(SEMICN);
    return true;
}

/**
 * VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]
*/
using frontend::VarDef;
bool Parser::parseVarDef(VarDef* root){
    PARSE_TOKEN(IDENFR);
    while(CUR_TOKEN_IS(LBRACK)){
        PARSE_TOKEN(LBRACK);
        PARSE(constexp, ConstExp);
        PARSE_TOKEN(RBRACK);
    }
    if(CUR_TOKEN_IS(ASSIGN)){
        PARSE_TOKEN(ASSIGN);
        PARSE(initval, InitVal);
    }
    return true;

}

/**
 * InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'
*/
using frontend::InitVal;
bool Parser::parseInitVal(InitVal* root){
    if(CUR_TOKEN_IS(LBRACE)){
        PARSE_TOKEN(LBRACE);
        if(!CUR_TOKEN_IS(RBRACE)){
            PARSE(initval, InitVal);
            while(CUR_TOKEN_IS(COMMA)){
                PARSE_TOKEN(COMMA);
                PARSE(initval, InitVal);
            }
        }
        PARSE_TOKEN(RBRACE);
    }
    else PARSE(exp, Exp)
    return true;
}

/**
 * FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
*/
using frontend::FuncDef;
bool Parser::parseFuncDef(FuncDef* root){
    PARSE(functype, FuncType);
    PARSE_TOKEN(IDENFR);
    PARSE_TOKEN(LPARENT);
    if(!CUR_TOKEN_IS(RPARENT))  PARSE(funcfparams, FuncFParams);
    PARSE_TOKEN(RPARENT);
    PARSE(block, Block);
    return true;
}

/**
 * FuncType -> 'void' | 'int' | 'float'
*/
using frontend::FuncType;
bool Parser::parseFuncType(FuncType* root){
    if(CUR_TOKEN_IS(VOIDTK))        PARSE_TOKEN(VOIDTK);
    else if(CUR_TOKEN_IS(INTTK))    PARSE_TOKEN(INTTK);
    else if(CUR_TOKEN_IS(FLOATTK))  PARSE_TOKEN(FLOATTK);
    return true;
}

/**
 * FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]
*/
using frontend::FuncFParam;
bool Parser::parseFuncFParam(FuncFParam* root){
    PARSE(btype, BType);
    PARSE_TOKEN(IDENFR);
    if(CUR_TOKEN_IS(LBRACK)){
        PARSE_TOKEN(LBRACK);
        PARSE_TOKEN(RBRACK);
        while(CUR_TOKEN_IS(LBRACK)){
            PARSE_TOKEN(LBRACK);
            PARSE(exp, Exp);
            PARSE_TOKEN(RBRACK);
        }
    }
    return true;
}

/**
 * FuncFParams -> FuncFParam { ',' FuncFParam }
*/
using frontend::FuncFParams;
bool Parser::parseFuncFParams(FuncFParams* root){
    PARSE(funcfparam, FuncFParam);
    while(CUR_TOKEN_IS(COMMA)){
        PARSE_TOKEN(COMMA);
        PARSE(funcfparam, FuncFParam);
    }
    return true;
}

/**
 * Block -> '{' { BlockItem } '}'
*/
using frontend::Block;
bool Parser::parseBlock(Block* root){
    PARSE_TOKEN(LBRACE);
    while(!CUR_TOKEN_IS(RBRACE)){
        PARSE(blockitem, BlockItem);
    }
    PARSE_TOKEN(RBRACE);
    return true;
}

/**
 * BlockItem -> Decl | Stmt
 *  *   Decl -> ConstDecl | VarDecl
 *          ConstDecl: const
 *          VarDecl:  int, float
*/
using frontend::BlockItem;
bool Parser::parseBlockItem(BlockItem* root){
    if(CUR_TOKEN_IS(CONSTTK) || CUR_TOKEN_IS(INTTK) || CUR_TOKEN_IS(FLOATTK)) 
         PARSE(decl, Decl)
    else PARSE(stmt, Stmt);
    return true;
}

/**
 * Stmt -> LVal '=' Exp ';' | Block | 'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 'while' '(' Cond ')' Stmt | 
 *              'break' ';' | 'continue'';' | 'return' [Exp] ';' | [Exp] ';'
 * 
 * 1. LVal -> Ident {'[' Exp ']'} = Exp ';'
 * 2. Block -> '{' { BlockItem } '}'
 * 3. if √
 * 4. while √
 * 5. break √
 * 6. continue √
 * 7. return √
 * 8. exp ->  AddExp -> MulExp { ('+' | '-') MulExp }
 *        -> UnaryExp { ('*' | '/' | '%') UnaryExp } { ('+' | '-') MulExp }
 *        -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp { ('*' | '/' | '%') UnaryExp } { ('+' | '-') MulExp }
 *        ->  '(' Exp ')' | LVal | Number  .......
 * 注意
*/
using frontend::Stmt;

bool Parser::parseStmt(Stmt* root){
    if(CUR_TOKEN_IS(IFTK)){
        PARSE_TOKEN(IFTK);
        PARSE_TOKEN(LPARENT);
        PARSE(cond, Cond);
        PARSE_TOKEN(RPARENT);
        PARSE(stmt, Stmt);
        if(CUR_TOKEN_IS(ELSETK)){
            PARSE_TOKEN(ELSETK);
            PARSE(stmt, Stmt);
        }
    }
    else if(CUR_TOKEN_IS(WHILETK)){
        PARSE_TOKEN(WHILETK);
        PARSE_TOKEN(LPARENT);
        PARSE(cond, Cond);
        PARSE_TOKEN(RPARENT);
        PARSE(stmt, Stmt);
    }
    else if(CUR_TOKEN_IS(BREAKTK)){
        PARSE_TOKEN(BREAKTK);
        PARSE_TOKEN(SEMICN);
    }
    else if(CUR_TOKEN_IS(CONTINUETK)){
        PARSE_TOKEN(CONTINUETK);
        PARSE_TOKEN(SEMICN);
    }
    else if(CUR_TOKEN_IS(RETURNTK)){
        PARSE_TOKEN(RETURNTK);
        if(!CUR_TOKEN_IS(SEMICN))   PARSE(exp, Exp);
        PARSE_TOKEN(SEMICN);
    }
    else if(CUR_TOKEN_IS(LBRACE))   PARSE(block, Block)
    else if (CUR_TOKEN_IS(SEMICN))  PARSE_TOKEN(SEMICN);
    // Stmt -> Exp ';'
    else if (CUR_TOKEN_IS(LPARENT) || CUR_TOKEN_IS(INTTK) || CUR_TOKEN_IS(FLOATTK) 
             || CUR_TOKEN_IS(PLUS) || CUR_TOKEN_IS(MINU) || CUR_TOKEN_IS(NOT)){
        PARSE(exp, Exp);
        PARSE_TOKEN(SEMICN);
    }
    // Stmt -> LVal '=' Exp ';' | Exp ';'
    else if (CUR_TOKEN_IS(IDENFR))
    {
        // Stmt -> Exp ';'  -> Ident '(' [FuncRParams] ')' ';'
        if (index+1 < token_stream.size() && token_stream[index + 1].type == TokenType::LPARENT){
            PARSE(exp, Exp);
            PARSE_TOKEN(SEMICN);
        }
        // Stmt -> LVal '=' Exp ';'  ->  -> Ident {'[' Exp ']'} '=' Exp ';'  
        else if ((index+1 < token_stream.size() && (token_stream[index + 1].type == TokenType::LBRACK)) || 
                (token_stream[index + 1].type == TokenType::ASSIGN)){
            PARSE(lval, LVal);
            PARSE_TOKEN(ASSIGN);
            PARSE(exp, Exp);
            PARSE_TOKEN(SEMICN);
        }
    }
    return true;
}

/**
 * Exp -> AddExp
*/
using frontend::Exp;
bool Parser::parseExp(Exp* root){
    PARSE(addexp, AddExp);
    return true;
}

/**
 * Cond -> LOrExp
*/
using frontend::Cond;
bool Parser::parseCond(Cond* root){
    PARSE(lorexp, LOrExp);
    return true;
}

/**
 * LVal -> Ident {'[' Exp ']'}
*/
using frontend::LVal;
bool Parser::parseLVal(LVal* root){
    PARSE_TOKEN(IDENFR);
    while(CUR_TOKEN_IS(LBRACK)){
        PARSE_TOKEN(LBRACK);
        PARSE(exp, Exp);
        PARSE_TOKEN(RBRACK);
    }
    return true;
}

/**
 * Number -> IntConst | floatConst
*/
using frontend::Number;
bool Parser::parseNumber(Number* root){
    if(CUR_TOKEN_IS(INTLTR))        PARSE_TOKEN(INTLTR);
    else if(CUR_TOKEN_IS(FLOATLTR)) PARSE_TOKEN(FLOATLTR);
    return true;
}

/**
 * PrimaryExp -> '(' Exp ')' | LVal | Number
 * 注意: LVal -> Ident {'[' Exp ']'}
*/
using frontend::PrimaryExp;
bool Parser::parsePrimaryExp(PrimaryExp* root){
    if(CUR_TOKEN_IS(LPARENT)){
        PARSE_TOKEN(LPARENT);
        PARSE(exp, Exp);
        PARSE_TOKEN(RPARENT);
    }
    else if(CUR_TOKEN_IS(INTLTR) || CUR_TOKEN_IS(FLOATLTR)){
        PARSE(number, Number);
    }
    else PARSE(lval, LVal);
    return true;
}

/**
 * UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
 * 注意: PrimaryExp -> '(' Exp ')' | LVal | Number  -> '(' Exp ')'  | Ident {'[' Exp ']'} | Number
*/
using frontend::UnaryExp;
bool Parser::parseUnaryExp(UnaryExp* root){
    if(CUR_TOKEN_IS(IDENFR)){
        if (index+1 < token_stream.size() && token_stream[index + 1].type == TokenType::LPARENT)
        {
            PARSE_TOKEN(IDENFR);
            PARSE_TOKEN(LPARENT);
            if (!CUR_TOKEN_IS(RPARENT)) PARSE(func_r_params, FuncRParams);
            PARSE_TOKEN(RPARENT);
        }
        else PARSE(primaryexp, PrimaryExp);
    }
    else if(CUR_TOKEN_IS(PLUS) || CUR_TOKEN_IS(MINU) || CUR_TOKEN_IS(NOT)){
        PARSE(unaryop, UnaryOp);
        PARSE(unaryexp, UnaryExp);
    }
    else PARSE(primaryexp, PrimaryExp);
    return true;
}

/**
 * UnaryOp -> '+' | '-' | '!'
*/
using frontend::UnaryOp;
bool Parser::parseUnaryOp(UnaryOp* root){
    if(CUR_TOKEN_IS(PLUS))      PARSE_TOKEN(PLUS);
    else if(CUR_TOKEN_IS(MINU)) PARSE_TOKEN(MINU);
    else if(CUR_TOKEN_IS(NOT))  PARSE_TOKEN(NOT);
    return true;
}

/**
 * FuncRParams -> Exp { ',' Exp }
*/
using frontend::FuncRParams;
bool Parser::parseFuncRParams(FuncRParams* root){
    PARSE(exp, Exp);
     while(CUR_TOKEN_IS(COMMA)){
        PARSE_TOKEN(COMMA);
        PARSE(exp, Exp);
    }
    return true;
}

/**
 * MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }
*/
using frontend::MulExp;
bool Parser::parseMulExp(MulExp* root){
    PARSE(unaryexp, UnaryExp);
     while(CUR_TOKEN_IS(MULT) || CUR_TOKEN_IS(DIV) || CUR_TOKEN_IS(MOD)){
        if(CUR_TOKEN_IS(MULT))      PARSE_TOKEN(MULT);
        else if(CUR_TOKEN_IS(DIV))  PARSE_TOKEN(DIV);
        else if(CUR_TOKEN_IS(MOD))  PARSE_TOKEN(MOD);
        PARSE(unaryexp, UnaryExp);
    }
    return true;
}

/**
 * AddExp -> MulExp { ('+' | '-') MulExp }
*/
using frontend::AddExp;
bool Parser::parseAddExp(AddExp* root){
    PARSE(muexp, MulExp);
    while(CUR_TOKEN_IS(PLUS) || CUR_TOKEN_IS(MINU)){
        if(CUR_TOKEN_IS(PLUS))      PARSE_TOKEN(PLUS);
        else if(CUR_TOKEN_IS(MINU)) PARSE_TOKEN(MINU);
        else return false;
        PARSE(muexp, MulExp);
    }
    return true;
}

/**
 * RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }
*/
using frontend::RelExp;
bool Parser::parseRelExp(RelExp* root){
    PARSE(addexp, AddExp);
    while(CUR_TOKEN_IS(LSS) || CUR_TOKEN_IS(GTR) || CUR_TOKEN_IS(LEQ) || CUR_TOKEN_IS(GEQ)){
        if(CUR_TOKEN_IS(LSS))       PARSE_TOKEN(LSS);
        else if(CUR_TOKEN_IS(GTR))  PARSE_TOKEN(GTR);
        else if(CUR_TOKEN_IS(LEQ))  PARSE_TOKEN(LEQ);
        else if(CUR_TOKEN_IS(GEQ))  PARSE_TOKEN(GEQ);
        else return false;
        PARSE(addexp, AddExp);
    }
    return true;
}

/**
 * EqExp -> RelExp { ('==' | '!=') RelExp }
*/
using frontend::EqExp;
bool Parser::parseEqExp(EqExp* root){
    PARSE(relexp, RelExp);
    while(CUR_TOKEN_IS(EQL) || CUR_TOKEN_IS(NEQ)){
        if(CUR_TOKEN_IS(EQL))       PARSE_TOKEN(EQL);
        else if(CUR_TOKEN_IS(NEQ))  PARSE_TOKEN(NEQ);
        else return false;
        PARSE(relexp, RelExp);
    }
    return true;
}

/**
 * LAndExp -> EqExp [ '&&' LAndExp ]
*/
using frontend::LAndExp;
bool Parser::parseLAndExp(LAndExp* root){
    PARSE(eqexp, EqExp);
    if(CUR_TOKEN_IS(AND)){
        PARSE_TOKEN(AND);
        PARSE(landexp, LAndExp);
    }
    return true;
}

/**
 * LOrExp -> LAndExp [ '||' LOrExp ]
*/
using frontend::LOrExp;
bool Parser::parseLOrExp(LOrExp* root){
    PARSE(landexp, LAndExp);
    if(CUR_TOKEN_IS(OR)){
        PARSE_TOKEN(OR);
        PARSE(lorexp, LOrExp)
    }
    return true;
}

/**
 * ConstExp -> AddExp
*/
using frontend::ConstExp;
bool Parser::parseConstExp(ConstExp* root){
    PARSE(addexp, AddExp);
    return true;
}

void Parser::log(AstNode* node){
#ifdef DEBUG_PARSER
        std::cout << "in parse" << toString(node->type) << ", cur_token_type::" << toString(token_stream[index].type) << ", token_val::" << token_stream[index].value << '\n';
#endif
}
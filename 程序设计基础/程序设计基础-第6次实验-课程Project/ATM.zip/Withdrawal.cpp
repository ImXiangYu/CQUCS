#include "ATM.h"

void withdrawal(const string& accountNumber) {
    User tmpUser;
    tmpUser.loadData(accountNumber + ".txt");

    int amount;
    cout << "Daily withdrawal limit for your account is: " << tmpUser.limit << endl;
    cout << "Enter withdrawal amount (must be a multiple of 100):";
    cin >> amount;

    if (amount <= 0 || amount % 100 != 0) {
        cout << "Invalid amount. Withdrawal amount must be a positive multiple of 100." << endl;
        withdrawal(accountNumber);
    } else if (amount > tmpUser.balance || amount > 5000 || amount > tmpUser.limit) {
        cout << "Insufficient funds or withdrawal limit exceeded." << endl;
        withdrawal(accountNumber);
    } else {
        tmpUser.balance -= amount;
        tmpUser.limit -= amount;
        
        cout << "Withdrawal successful. Remaining balance:" << tmpUser.balance << endl;
        tmpUser.saveData(accountNumber + ".txt");
        
        displayMenu();
        performOperation(accountNumber);
    }
}

from PIL import Image
def size_change(i):
    pic = Image.open(str(i)+".png")
    pic_new = pic.resize((60,60), Image.ANTIALIAS)
    pic_new.save("new/"+str(i)+".png")
for i in range(1,17):
    size_change(i)
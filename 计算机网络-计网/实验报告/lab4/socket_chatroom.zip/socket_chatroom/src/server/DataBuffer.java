package server;

import common.model.entity.User;
import common.model.entity.OnlineUserTableModel;
import common.model.entity.RegistedUserTableModel;

import java.awt.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentSkipListMap;


public class DataBuffer {
    public static ServerSocket serverSocket;    // 服务器Socket
    public static Map<Long, User> onlineUsersMap = new ConcurrentSkipListMap<Long, User>();   // 在线用户表
    public static Map<Long, ClientIOCache> onlineUserIOCacheMap = new ConcurrentSkipListMap<Long, ClientIOCache>();  // 在线用户IO表
    public static RegistedUserTableModel registedUserTableModel = new RegistedUserTableModel();    // 已注册用户TableModel
    public static OnlineUserTableModel onlineUserTableModel = new OnlineUserTableModel();    // 在线用户TableModel

    public static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();   // 显示器尺寸
    public static Properties configProp = new Properties();    // 服务器配置参数

    static {
        // 加载服务器配置文件
        try {
            configProp.load(new FileInputStream("serverconfig.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

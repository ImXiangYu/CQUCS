#include"front/semantic.h"
#include<iostream>
#include<cassert>
#include <numeric>
#include <cmath>
using ir::Instruction;
using ir::Function;
using ir::Operand;
using ir::Operator;
using ir::Program;
using frontend::Analyzer;
using frontend::NodeType;

//好用的debug宏
#define debug(name, val) std::cout << "[" << name << ": " << val << "]\n";
#define TODO assert(0 && "TODO");
#define Debug_ERROR(error, param) \
    std::cout << error << param << std::endl; \
    assert(0 && error);
//可以简化很多操作的宏
#define CompareEq(a, b, c, d) (a == b) ? c : d
#define afor(i, a, b, s) for(size_t i = a; i <= b; i += s)
#define CUR_NODE_IS(type1, index) root->children[index]->type == NodeType::type1
#define ISIntOrLiteral(type)   (type == Type::Int || type == Type::IntLiteral)
#define ISFloatOrLiteral(type) (type == Type::Float || type == Type::FloatLiteral)
#define ISLiteral(type) (type == Type::IntLiteral || type == Type::FloatLiteral)
//定义的一些常量
#define INTCONST "0"
#define FLOATCONST "0.0"
#define SCOPE_GLOBAL "$GlobalScope"
#define Function_GLOBAL "_GlobalFunction"
#define num2str std::to_string
#define str2int std::stoi
#define str2flt std::stof

//添加指令宏,真的是好东西
#define NewInst1(operand1, operand2, des, op) new Instruction(operand1, operand2, des, op)  //两个操作数都用
#define NewInst2(operand1, des, op) new Instruction(operand1, Operand(), des, op)           //只使用一个操作数

//获取某个树节点node下指定type节点的指针
#define GET_CHILD_PTR(node, type, index) \
    auto node = dynamic_cast<type*>(root->children[index]); \
    assert(node); 
//对某个树节点的node下指定type子节点进行分析
#define ANALYSIS(node, type, index) \
    auto node = dynamic_cast<type*>(root->children[index]); \
    assert(node); \
    analysis##type(node, insts);
//将from表达式的信息复制到to表达式的信息
#define COPY_EXP_NODE(from, to) \
    to->is_computable = from->is_computable; \
    to->v = from->v; \
    to->t = from->t;
//复制结点的值
#define COPY_TV(name, type, val) \
    name->t = type; \
    name->v = val;
//库函数
map<std::string,ir::Function*>* frontend::get_lib_funcs() {
    static map<std::string,ir::Function*> lib_funcs = {
        {"getint", new Function("getint", Type::Int)},
        {"getch", new Function("getch", Type::Int)},
        {"getfloat", new Function("getfloat", Type::Float)},
        {"getarray", new Function("getarray", {Operand("arr", Type::IntPtr)}, Type::Int)},
        {"getfarray", new Function("getfarray", {Operand("arr", Type::FloatPtr)}, Type::Int)},
        {"putint", new Function("putint", {Operand("i", Type::Int)}, Type::null)},
        {"putch", new Function("putch", {Operand("i", Type::Int)}, Type::null)},
        {"putfloat", new Function("putfloat", {Operand("f", Type::Float)}, Type::null)},
        {"putarray", new Function("putarray", {Operand("n", Type::Int), Operand("arr", Type::IntPtr)}, Type::null)},
        {"putfarray", new Function("putfarray", {Operand("n", Type::Int), Operand("arr", Type::FloatPtr)}, Type::null)},
    };
    return &lib_funcs;
}

/**
 * @brief 判断是否能转换为整型,注意异常不能中断
*/
bool isInteger(const std::string& str) {  
    try {  
        std::stoi(str);  
        return true;  
    } catch (const std::invalid_argument&) {  
        return false;  
    } catch (const std::out_of_range&) {  
        return false;  
    }  
}

/**
 * @brief 判断是否能转换为浮点型,注意异常不能中断
*/
bool isFloat(const std::string& str) {  
    try {  
        std::stod(str);  
        return true;  
    } catch (const std::invalid_argument&) {  
        return false;  
    } catch (const std::out_of_range&) {  
        // 对于浮点数，std::out_of_range不太可能出现，但为了完整性还是捕获了  
        return false;  
    }  
}

/**
 * @brief 计算数组的大小
*/
int cal_arr_size(vector<int>dimension) {
    int len = 1;
    for (int i: dimension) len *= i;
    return len; 
}

/**
 * @brief 判断数组元素是否全为数字
*/
bool isAllDigits(const std::string& str) {  
    for (char c : str) {  
        if (!std::isdigit(static_cast<unsigned char>(c))) {  
            return false; // 如果发现非数字字符，返回false  
        }  
    }  
    return true;         // 如果没有发现非数字字符，返回true  
} 

/**
 * @brief 判断是否为库函数
*/
bool isLibFunc(std::string name) {
    return frontend::get_lib_funcs()->find(name) != 
           frontend::get_lib_funcs()->end();
}
/**
 * @brief 获取整数运算类型, R型指令
*/
Operator get_operator(frontend::TokenType type) {
    switch(type) {
        case frontend::TokenType::MULT: 
            return Operator::mul;
        case frontend::TokenType::DIV: 
            return Operator::div;
        case frontend::TokenType::MOD:
            return Operator::mod;
        case frontend::TokenType::PLUS:
            return Operator::add;
        case frontend::TokenType::MINU:
            return Operator::sub;
        case frontend::TokenType::LSS:
            return Operator::lss;
        case frontend::TokenType::LEQ:
            return Operator::leq;
        case frontend::TokenType::GTR:
            return Operator::gtr;
        case frontend::TokenType::GEQ:
            return Operator::geq;
        case frontend::TokenType::EQL:
            return Operator::eq;
        case frontend::TokenType::NEQ:
            return Operator::neq;
        default:  { Debug_ERROR("[get_operator] unknown TokenType: ", frontend::toString(type)); }
    }
    return Operator::mul;
}

/**
 * @brief 获取浮点型R型指令(只做了部分)
*/
Operator get_operator_f(frontend::TokenType type) {
    switch(type) {
        case frontend::TokenType::MULT: 
            return Operator::fmul;
        case frontend::TokenType::DIV: 
            return Operator::fdiv;
        case frontend::TokenType::PLUS:
            return Operator::fadd;
        case frontend::TokenType::MINU:
            return Operator::fsub;
        case frontend::TokenType::LSS:
            return Operator::flss;
        default:  { Debug_ERROR("[get_operator] unknown TokenType: ", frontend::toString(type)); }
    }
    return Operator::fmul;
}

/**
* @brief 进入新作用域时, 向符号表中添加 ScopeInfo, 以name命名
*/
void frontend::SymbolTable::add_scope(std::string name) {
    map_str_ste table;
    ScopeInfo newScope(0, name, table);
    scope_stack.push_back(newScope);
}

/**
 * @brief 退出时弹栈
*/
void frontend::SymbolTable::exit_scope() {
    scope_stack.pop_back();
}

/**
 * @brief 获取当前作用域的名称
*/
string frontend::SymbolTable::get_curr_scope() {
    return scope_stack[scope_stack.size() - 1].name;
}

/**
 * @brief 重命名后的变量名, 采用作用域名 + 变量名的方式重命名
*/
string frontend::SymbolTable::get_scoped_name(string id) const {
    return scope_stack[scope_stack.size() - 1].name + "_" + id;
}

/**
 * @brief 输入一个变量名, 在符号表中寻找最近的同名变量, 返回 STE
*/
frontend::STE frontend::SymbolTable::get_ste(string id) const {
    //因为找最近的,所以需要逆向遍历
    for(auto scope = scope_stack.rbegin(); scope != scope_stack.rend(); ++scope){
        auto t = scope->table.find(id);
        if(t != scope->table.end()) return t->second;
    }
    Debug_ERROR("[frontend::STE frontend::SymbolTable::get_ste]: Couldn't find id: ", id)
}

void frontend::SymbolTable::add_scope_entry(string var_name, STE ste) {
    /**
     * A STE：
     *      ir::Operand operand；
     *      vector<int> dimension;
    */
    int index = scope_stack.size() - 1;
    scope_stack[index].table[var_name] = ste;
}

/**
 * @brief 输入一个变量名, 在符号表中寻找最近的同名变量, 
 *        返回对应的 Operand(注意，此 Operand 的 name 是重命名后的)
*/
Operand frontend::SymbolTable::get_operand(string id) const {
    return get_ste(id).operand;
}

/**
 * @brief 初始化, 加入全局作用域
*/
frontend::Analyzer::Analyzer(): tmp_cnt(0), symbol_table() {
    //全局变量使用_GlobalScope作用域进行存储。
    symbol_table.add_scope(SCOPE_GLOBAL);
}

/**
 * @brief 参考代码框架, 用于增加临时变量
*/
std::string Analyzer::get_tmp_var() {
    return "$tmp_" + std::to_string(tmp_cnt++);
}

/**
 * @brief 执行程序入口
*/
ir::Program frontend::Analyzer::get_ir_program(CompUnit* root) {
    Program program;
    //生成全局函数, 存放全局变量定义
    analysisCompUnit(root, program);    
    //获取全局变量
    get_global_vars(program);
    //获取所有函数
    get_functions(program);
    return program;
}

/**
 * @brief 获取全局变量
*/
void frontend::Analyzer::get_global_vars(Program& program) {
    int index = symbol_table.scope_stack.size() - 1;
     //程序中添加全局变量, 遍历_GlobalScope中的table
    auto global_table = symbol_table.scope_stack[index].table;
    for(auto& cur: global_table) {
        Operand op = cur.second.operand;               //获取操作数类型和名称
        vector<int> dimension = cur.second.dimension;  //获取是否为数组
        if(dimension.size()) {
            program.globalVal.push_back(ir::GlobalVal(op, cal_arr_size(dimension)));
            continue;
        }
        if(ISLiteral(op.type)) cur.second.operand.name = cur.first;
        program.globalVal.push_back(ir::GlobalVal(op));
    }
}

/**
 * @brief 获取所有函数
*/
void frontend::Analyzer::get_functions(Program& program) {
    auto callGlobalInst = new ir::CallInst(Operand(Function_GLOBAL, Type::null), Operand("$t0", Type::null));
    for(auto& func: symbol_table.functions) {
        if(func.first == "main") {
            func.second->InstVec.insert(func.second->InstVec.begin(),callGlobalInst);
        }
        program.functions.push_back(*func.second);
    }
}
/**
 * CompUnit -> (Decl | FuncDef) [CompUnit]
*/
void Analyzer::analysisCompUnit(CompUnit*root, Program& program) {
    //全局变量定义, 需要传入g_init_inst初始化
    if(CUR_NODE_IS(DECL, 0)) {
        GET_CHILD_PTR(decl, Decl, 0);
        analysisDecl(decl, g_init_inst);
    }
    //函数定义
    else {
        GET_CHILD_PTR(funcdef, FuncDef, 0);
        analysisFuncDef(funcdef);
    }
    if(root->children.size() > 1) {
        GET_CHILD_PTR(compunit, CompUnit, 1);
        analysisCompUnit(compunit, program);
    }
    //添加全局初始化指令
    Function globalFunc(Function_GLOBAL, Type::null);
    for(auto &inst: g_init_inst) {
        globalFunc.addInst(inst);
    }
    globalFunc.addInst(new Instruction(Operand(), Operand(), Operand(), Operator::_return));
    program.addFunction(globalFunc);
}

/**
 * Decl -> ConstDecl | VarDecl
 * ConstDecl: const
 * VarDecl:  int, float
*/
void Analyzer::analysisDecl(Decl* root, vector<Instruction*>& insts){
    if(CUR_NODE_IS(CONSTDECL, 0)) {
        ANALYSIS(constdecl, ConstDecl, 0);   //常量定义
    }
    else {
        ANALYSIS(vardecl, VarDecl, 0);       //变量定义
    }
}

/**
 * BType -> 'int' | 'float'
*/
ir::Type Analyzer::analysisBType(BType* root) {
    GET_CHILD_PTR(term, Term, 0);
    return CompareEq(term->token.type, TokenType::INTTK, Type::Int, Type::Float);
}

/**
 * ConstDecl -> 'const' BType ConstDef { ',' ConstDef } ';'
 * const int/float ..., ....;
*/
void Analyzer::analysisConstDecl(ConstDecl* root, vector<Instruction*>& insts) {
    //获取int/float类型
    GET_CHILD_PTR(btype, BType, 1);
    root->t = analysisBType(btype);
    latestType =root->t;
    for(size_t curr = 2; curr < root->children.size(); curr += 2) {
        GET_CHILD_PTR(constdef, ConstDef, curr);
        analysisConstDef(constdef, insts, root->t);
    }
    latestType = Type::null;
}

/**
 * ConstDef -> Ident { '[' ConstExp ']' } '=' ConstInitVal
 * ConstDef: string arr_name
 * a, b = 2, c[0] = 7, d[2*3][2] = 5
*/
void Analyzer::analysisConstDef(ConstDef* root, vector<Instruction*>& insts, Type tp) {
    GET_CHILD_PTR(ident, Term, 0);
    //变量的初始名称
    std::string init_arr_name = ident->token.value;
    //变量重命名后的名称
    root->arr_name = symbol_table.get_scoped_name(init_arr_name);
    /**
     * 因为[ ConstExp ]可能为多个循环, 因此考虑使用for或者while循环,
     * 使用dim记录数组维数, 如果有
     * 当遇到ConstExp时分析子结点ConstExp -> 计算数组大小存入dim
    */
    int curr = 2;            //记录当前进行的指针
    vector<int>dim;          //记录数组维数 + 大小
    Type varType = tp;       //变量的类型, 整数和浮点数立即数、整数和浮点数指针(数组)
    Instruction* tempInst;   //待添加的指令
    while(curr < root->children.size() && CUR_NODE_IS(CONSTEXP, curr)) {
        //将父节点的属性传递给子节点
        GET_CHILD_PTR(constexp, ConstExp, curr);
        COPY_TV(constexp, tp, root->arr_name);
        analysisConstExp(constexp, insts);
        //将其强制转化为整型
        dim.push_back(str2int(constexp->v));
        curr += 3;
    }
    int dimSize = cal_arr_size(dim);
    if(dim.size()) {
        //如果是数组, IntPtr || FloatPtr, 由tp决定
        varType = CompareEq(tp, Type::Int, Type::IntPtr, Type::FloatPtr);
        tempInst = NewInst2(
            Operand(std::to_string(dimSize), Type::IntLiteral),
            Operand(root->arr_name, varType),
            Operator::alloc
        );
        insts.push_back(tempInst);   //加入定义指令
    }
    else {
        //如是普通变量int a = 2; || float b = 1.5;
        varType = CompareEq(tp, Type::Int, Type::IntLiteral, Type::FloatLiteral);
        tempInst = NewInst2(
            Operand(CompareEq(tp, Type::Int, INTCONST, FLOATCONST), varType),
            Operand(root->arr_name, tp),
            CompareEq(tp, Type::Int, Operator::def, Operator::fdef)
        );
    }
    /**
     * 分析ConstInitVal
     *      string v;
            Type t;
    */
    GET_CHILD_PTR(constinitval, ConstInitVal, root->children.size() - 1);
    COPY_TV(constinitval, tp, root->arr_name);
    analysisConstInitVal(constinitval, insts);
    //做强制转换
    if(tp == Type::Int && constinitval->t == Type::FloatLiteral) {
        constinitval->v = num2str(str2int(constinitval->v));
    }
    else if(tp == Type::Float && constinitval->t == Type::IntLiteral) {
        constinitval->v = num2str(str2flt(constinitval->v));
    }
    //debug("NumberRoot->n: ", init_arr_name);
    //debug("NumberRoot->t: ", toString(varType));
    //debug("NumberRoot->v: ", constinitval->v);
    symbol_table.add_scope_entry(
            init_arr_name, 
            {Operand(constinitval->v, varType), dim}
    );
}

/**
 * ConstExp -> AddExp
 * ConstExp.is_computable: true
 * ConstExp.v
 * ConstExp.t
*/
void Analyzer::analysisConstExp(ConstExp* root, vector<Instruction*>& insts) {
    //ANALYSIS(addexp, AddExp, 0);
    //root->parent->type ==NodeType::CONSTINITVAL;
    GET_CHILD_PTR(addexp, AddExp, 0);
    COPY_EXP_NODE(root, addexp);
    analysisAddExp(addexp, insts);
    COPY_EXP_NODE(addexp, root);   //传递给父节点
}

/**
 * ConstInitVal -> ConstExp | '{' [ ConstInitVal { ',' ConstInitVal } ] '}'
 * ConstInitVal.v
 * ConstInitVal.t = Int | Float
 * {4, {1,2}, {3}}
*/
void Analyzer::analysisConstInitVal(ConstInitVal* root, vector<ir::Instruction*>& insts) {
    if(CUR_NODE_IS(CONSTEXP, 0)) {
        GET_CHILD_PTR(constexp, ConstExp, 0);
        COPY_TV(constexp, root->t, get_tmp_var());
        analysisConstExp(constexp, insts);
        COPY_TV(root, constexp->t, constexp->v);
        tmp_cnt--;
    }
    else {
        int curr = 1;
        int arr_index = 0;
        while(curr < root->children.size()-1 && CUR_NODE_IS(CONSTINITVAL, curr)) {
            GET_CHILD_PTR(constinitval, ConstInitVal, curr);
            COPY_TV(constinitval, root->t, get_tmp_var());
            analysisConstInitVal(constinitval, insts);
            Type arr_type = CompareEq(root->t, Type::Int, Type::IntPtr, Type::FloatPtr);
            Type val_type = CompareEq(root->t, Type::Int, Type::IntLiteral, Type::FloatLiteral);
            //store 3, arr, 2 => op1: arr, op2: index, des: val, opcode 
            insts.push_back(NewInst1(Operand(root->v, arr_type),
                                     Operand(num2str(arr_index++), Type::IntLiteral),
                                     Operand(constinitval->v, val_type),
                                     Operator::store));
            curr += 2;
            tmp_cnt--;        
        }
    }
}


/**
 * AddExp -> MulExp { ('+' | '-') MulExp }
 * AddExp.is_computable
 * AddExp.v
 * AddExp.t
*/
void Analyzer::analysisAddExp(AddExp* root, vector<ir::Instruction*>& insts) {
    // ANALYSIS(mulexp, MulExp, 0);
    // COPY_EXP_NODE(mulexp, root);
    GET_CHILD_PTR(mulexp, MulExp, 0);
    COPY_EXP_NODE(root, mulexp);
    analysisMulExp(mulexp, insts);
    COPY_EXP_NODE(mulexp, root);
    int curr = 2;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(mulexp, MulExp, curr);
        COPY_TV(mulexp, root->t, get_tmp_var());
        analysisMulExp(mulexp, insts);
        GET_CHILD_PTR(term, Term, curr - 1);
        string tmpVar = get_tmp_var();
        //考虑到浮点数的情况
        if(latestType == Type::Float && root->t == Type::IntLiteral && ISLiteral(mulexp->t)) {
            COPY_TV(root, Type::FloatLiteral, num2str(str2flt(root->v)));
        }
        if(root->v == INTCONST && mulexp->t == Type::Float) {
            auto tmp = get_tmp_var();
            insts.push_back(NewInst2(Operand(FLOATCONST, Type::Float),
                                     Operand(tmp, Type::Float),
                                     Operator::fdef));
            COPY_TV(root, Type::Float, tmp);
        }
        doArithmeticOperations(root, mulexp, term, tmpVar, insts);
        //debug("root->v1: ",root->v);
        //debug("root->t: ", toString(root->t));
        curr += 2;
        tmp_cnt--;
    }
}

template<typename T> 
std::string frontend::constLiteralComp(frontend::TokenType tk, Type type, T a, T b) {
    std::string res;
    switch (tk)
    {
    case frontend::TokenType::PLUS:
        res = num2str(a + b);
        break;
    case frontend::TokenType::MINU:
        res = num2str(a - b);
        break;
    case frontend::TokenType::MULT:
        res = num2str(a * b);
        break;
    case frontend::TokenType::DIV:
        res = num2str(a / b);
        break;
    default:
        Debug_ERROR("[Operand intLiteralComp] unexpected token type", "");
        break;
    }
    return res;
}

template<typename T1, typename T2>
void frontend::doArithmeticOperations(T1* root, T2* child, frontend::Term* term, 
                                      std::string tmpVar,  std::vector<ir::Instruction*>& insts) {
    //父子结点的类型一致  
    if(root->t == child->t) {
        //整数立即数计算
        if(root->t == Type::IntLiteral) {
            if(term->token.type == TokenType::MOD) {
                root->v = num2str(str2int(root->v) % str2int(child->v));
            }
            else {
                root->v = constLiteralComp(term->token.type, root->t,str2int(root->v), str2int(child->v));
            }
        }
        //浮点数立即数计算
        else if(root->t == Type::FloatLiteral) {
            if(term->token.type == TokenType::MOD) {
                root->v = num2str(std::fmod(str2flt(root->v), str2flt(child->v)));
            }
            else {
                root->v = constLiteralComp(term->token.type, root->t,str2flt(root->v), str2flt(child->v));
            }
        }
        //均为int || float型
        else {
            Operator op = CompareEq(root->t, Type::Int, Operator::mov, Operator::fmov);
            if(insts.back()->op == Operator::fmov && get_operator_f(term->token.type) == Operator::fadd) {
                child->v = insts.back()->op1.name;
                child->t = insts.back()->op1.type;
                insts.pop_back();
            }
            insts.push_back(NewInst1(Operand(root->v, root->t), 
                                     Operand(child->v, child->t), 
                                     Operand(root->v, root->t),
                                     CompareEq(op, Operator::mov, get_operator(term->token.type), 
                                                                  get_operator_f(term->token.type))));
        }
    }
    else {
        if(ISIntOrLiteral(root->t)) {
            //在int || intLiteral 情况下出现浮点型, 暂时不考虑浮点型
            if(child->t == Type::FloatLiteral) {
                //debug("TP:", str2flt(root->v));
                //debug("TP:", str2flt(child->v));
                root->v = constLiteralComp(term->token.type, root->t, str2flt(root->v),str2flt(child->v));
            }
            // a = a + 1
            else if(child->t == Type::IntLiteral) {
                Operator tmp_op = CompareEq(term->token.type, TokenType::PLUS, Operator::addi, 
                                  CompareEq(term->token.type, TokenType::MINU, Operator::subi,
                                           get_operator(term->token.type)));
                insts.push_back(NewInst1(Operand(root->v, root->t),
                                         Operand(child->v, child->t),
                                         Operand(root->v, root->t),
                                         tmp_op));
            }
            //第一个操作数为立即数
            else {
                insts.push_back(NewInst2(Operand(root->v, root->t),
                                         Operand(tmpVar, Type::Int),
                                         Operator::mov));
                insts.push_back(NewInst1(Operand(tmpVar, Type::Int),
                                         Operand(child->v, child->t),
                                         Operand(tmpVar, Type::Int),
                                         get_operator(term->token.type)));
                COPY_TV(root, Type::Int, tmpVar);
            }
        }
        else if(ISFloatOrLiteral(root->t)) {
            //在float || floatLiteral 情况下出现整型
            if(ISIntOrLiteral(child->t)) {
                if(root->t == Type::FloatLiteral && child->t == Type::IntLiteral){
                    child->v = num2str(str2flt(child->v));
                    child->t = Type::FloatLiteral;
                    root->v = constLiteralComp(term->token.type, root->t, str2flt(root->v),str2flt(child->v));
                }
            }
            else if(child->t == Type::FloatLiteral) {
                Operator tmp_op = CompareEq(term->token.type, TokenType::PLUS, Operator::addi, 
                                  CompareEq(term->token.type, TokenType::MINU, Operator::subi,
                                  get_operator_f(term->token.type)));
                insts.push_back(NewInst1(Operand(root->v, root->t),
                                         Operand(child->v, child->t),
                                         Operand(root->v, root->t),
                                         tmp_op));
            }
        }
        else {
            Debug_ERROR("[Analyzer::analysisMulExp] Unexpected Type root->t:", "");
        }
    }
}

 
/**
 * MulExp -> UnaryExp { ('*' | '/' | '%') UnaryExp }
 * value1 % (value2 * 10)
 * MulExp.is_computable
 * MulExp.v
 * MulExp.t
*/
void Analyzer::analysisMulExp(MulExp* root, vector<ir::Instruction*>& insts) {
    //分析第一个结点UnaryExp
    // ANALYSIS(unaryexp, UnaryExp, 0);
    // COPY_EXP_NODE(unaryexp, root);
    GET_CHILD_PTR(unaryexp, UnaryExp, 0);
    COPY_EXP_NODE(root, unaryexp);
    analysisUnaryExp(unaryexp, insts);
    COPY_EXP_NODE(unaryexp, root);
    // AstNode* pparent = root->parent->parent->parent;
    // if(pparent->type == NodeType::CONSTINITVAL) {
    //     //debug("YES2","YES2");
    //     auto node1 = dynamic_cast<ConstExp*>(root->parent->parent);
    //     root->t = CompareEq(node1->t, Type::Int, Type::IntLiteral, Type::FloatLiteral);
    //     //std::cout << toString(node1->t) << "\n";
    // }
    //循环遍历,是否有多个UnaryExp结点
    int curr = 2;
    while(curr < root->children.size()) {
        //暂时不考虑优化的问题, 使用一个临时变量存放子结点的值
        GET_CHILD_PTR(unaryexp, UnaryExp, curr);
        unaryexp->t = root->t;
        unaryexp->v = get_tmp_var();
        analysisUnaryExp(unaryexp, insts);
        //获取属于 '*' | '/' | '%'的具体值
        GET_CHILD_PTR(term, Term, curr - 1);
        //这里针对浮点数
        if(latestType == Type::Float && !(ISLiteral(root->t) && ISLiteral(unaryexp->t)) 
           && symbol_table.get_curr_scope() != SCOPE_GLOBAL) {
            if(root->t == Type::FloatLiteral) {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(root->v, root->t),
                                         Operand(tmpVar, Type::Float),
                                         Operator::fdef));
                COPY_TV(root, Type::Float, tmpVar);
            }
            else if(root->t == Type::Int) {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(root->v, root->t),
                                         Operand(tmpVar, Type::Float),
                                         Operator::cvt_i2f));
                COPY_TV(root, Type::Float, tmpVar);
            }
            if(unaryexp->t == Type::Int) {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(unaryexp->v, unaryexp->t),
                                         Operand(tmpVar, Type::Float),
                                         Operator::cvt_i2f));
                COPY_TV(unaryexp, Type::Float, tmpVar);
            }
            else if(unaryexp->t == Type::FloatLiteral) {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(unaryexp->v, unaryexp->t),
                                         Operand(tmpVar, Type::Float),
                                         Operator::fdef));
                COPY_TV(unaryexp, Type::Float, tmpVar);
            }
            else if(unaryexp->t == Type::IntLiteral) {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(num2str(str2flt(unaryexp->v)), Type::FloatLiteral),
                                         Operand(tmpVar, Type::Float),
                                         Operator::fdef));
                COPY_TV(unaryexp, Type::Float, tmpVar);
            }
        }
        
        if(symbol_table.get_curr_scope() != SCOPE_GLOBAL) {
            if(unaryexp->t == Type::FloatLiteral && root->t == Type::IntLiteral) {
                unaryexp->v = num2str(str2int(unaryexp->v));
                unaryexp->t = Type::IntLiteral;
            }
        }
        // debug("root->name: ", root->v);
        // debug("root->type: ", toString(root->t));
        // debug("unary->name: ", unaryexp->v);
        // debug("unary->type: ", toString(unaryexp->t));
        // debug("type: ", toString(term->token.type));
        // debug("", "");
        std::string tmpVar = get_tmp_var();
        doArithmeticOperations(root, unaryexp, term, tmpVar, insts);
        curr += 2;        
    }
}


/**
 * UnaryExp -> PrimaryExp | Ident '(' [FuncRParams] ')' | UnaryOp UnaryExp
 * UnaryExp.is_computable
 * UnaryExp.v
 * UnaryExp.t
 * 
 *  42                         // 常量是一个基本表达式，因此也是一元表达式 
    x                          // 变量引用是一个基本表达式 
    arr[i]                      // 数组元素访问是一个基本表达式
    printf("Hello, World!")     // 假设printf是一个已定义的函数 
    max(a, b)                    // 假设max是一个返回两个数中较大值的函数
    -x                          // 负号是一元操作符 
    !flag                       // 逻辑非是一元操作符 
    +value                      // 按位非是一元操作符
*/
void Analyzer::analysisUnaryExp(UnaryExp* root, vector<Instruction*>& insts) {
    /**
     * 基本表达式, 
     *----如常量42
     -----变量引用x, 
    */
    if(CUR_NODE_IS(PRIMARYEXP, 0)) {
        // ANALYSIS(primaryexp, PrimaryExp, 0);
        // COPY_EXP_NODE(primaryexp, root);
        GET_CHILD_PTR(primaryexp, PrimaryExp, 0);
        COPY_EXP_NODE(root, primaryexp);
        analysisPrimaryExp(primaryexp, insts);
        COPY_EXP_NODE(primaryexp, root);
    }
    /**
     * 函数调用, 需要考虑库函数的情况
     * Ident '(' [FuncRParams] ')'
     * 
     * printf("Hello, World!") 
     * max(a, b) 
    */
    else if(CUR_NODE_IS(TERMINAL, 0)) {
        Function* function;
        GET_CHILD_PTR(term, Term, 0);
        std::string funcName = term->token.value;
        function = CompareEq(isLibFunc(funcName), true, (*get_lib_funcs())[funcName], symbol_table.functions[funcName]);
        //返回类型, 用临时变量获取返回值
        COPY_TV(root, function->returnType, get_tmp_var()); 
        if(root->children.size() == 3) {
            insts.push_back(new ir::CallInst(Operand(funcName, Type::null), Operand(root->v, root->t)));
        }
        //如果有参数
        else {
            vector<Operand>newParams;
            vector<Operand>paramLists = function->ParameterList;
            afor(i, 0, paramLists.size()-1, 1) {
                newParams.push_back(Operand(get_tmp_var(), paramLists[i].type));
            }
            GET_CHILD_PTR(funcrparams, FuncRParams, 2);
            analysisFuncRParams(funcrparams, newParams, insts);
            insts.push_back(new ir::CallInst(Operand(funcName, Type::null), newParams, Operand(root->v, root->t)));
        }
        //解除int a = func()的def冗余操作
        if(insts.back()->op == Operator::def) {
            insts.pop_back();
        }
    }
     /**
     *   -x   x=1, 1.0
     *  !x    x=1, 1.0 ????
    */
    else {
        GET_CHILD_PTR(unaryop, UnaryOp, 0);
        TokenType targetType = analysisUnaryOp(unaryop, insts);
        GET_CHILD_PTR(unaryexp, UnaryExp, 1);
        COPY_EXP_NODE(root, unaryexp);
        analysisUnaryExp(unaryexp, insts);
        COPY_EXP_NODE(unaryexp, root);
        if(targetType == TokenType::NOT) {
            //如果取非,那么我不知道浮点数, 暂不考虑其他情况  FIXED
            if(root->t == Type::IntLiteral) {
                root->v = CompareEq(str2int(root->v), 0, "1", "0");
            }
            else if(root->t == Type::FloatLiteral) {
                root->v = (str2flt(root->v) < 1e-30) ? "1" : "0";
            }
            else {
                std::string tmpVar = get_tmp_var();
                insts.push_back(NewInst2(Operand(INTCONST, Type::IntLiteral),
                                         Operand(tmpVar, Type::Int),
                                         Operator::def));
                //debug("tt", toString(root->t));
                if(root->v == "0" || root->v == "1") {
                    std::string tmpVar2 = get_tmp_var();
                    insts.push_back(NewInst2(Operand(root->v, Type::IntLiteral),
                                             Operand(tmpVar2, Type::Int),
                                             Operator::def));
                    COPY_TV(root, Type::Int, tmpVar2);
                }
                insts.push_back(NewInst2(Operand(root->v, root->t),
                                         Operand(tmpVar, Type::Int),
                                         Operator::_not));
                root->v = tmpVar;
            }
            root->t = Type::Int;
        }
        else if(targetType == TokenType::MINU) {
            std::string tmpVar = get_tmp_var();
            if(root->t == Type::Int) {
                insts.push_back(NewInst1(Operand(INTCONST, Type::IntLiteral), Operand(root->v, root->t), Operand(tmpVar, root->t), Operator::sub));
                root->v = tmpVar;
            }
            else if(root->t == Type::Float) {
                insts.push_back(NewInst1(Operand(FLOATCONST, Type::FloatLiteral), Operand(root->v, root->t), Operand(tmpVar, root->t), Operator::fsub));
                root->v = tmpVar;
            }
            else if(ISLiteral(root->t)) {
                root->v = CompareEq(root->t, Type::IntLiteral, num2str(-str2int(root->v)), num2str(-str2flt(root->v)));
            }
            else { Debug_ERROR("[analysisUnaryExp]unknown Type: ", "else if(targetType == TokenType::MINU)"); }
        }
    }
}

/**
 * PrimaryExp -> '(' Exp ')' | LVal | Number √
 * PrimaryExp.is_computable
 * PrimaryExp.v
 * PrimaryExp.t
 * 
 * 
 * Number:  2, 2.5
 * Exp -> AddExp -> MulExp { ('+' | '-') MulExp }
 * 
*/
void Analyzer::analysisPrimaryExp(PrimaryExp* root, vector<ir::Instruction*>& insts) {
    if(CUR_NODE_IS(LVAL, 0)) {
        GET_CHILD_PTR(lval, LVal, 0);
        COPY_EXP_NODE(root, lval);
        analysisLVal(lval, insts, false);
        COPY_EXP_NODE(lval, root);
    }
    else if(CUR_NODE_IS(NUMBER, 0)) {
        GET_CHILD_PTR(number, Number, 0);
        COPY_EXP_NODE(root, number);
        analysisNumber(number, insts);
        COPY_EXP_NODE(number, root);
    }
    else {
        GET_CHILD_PTR(exp, Exp, 1);
        COPY_EXP_NODE(root, exp);
        analysisExp(exp, insts);
        COPY_EXP_NODE(exp, root);
    }
}

/**
 * FuncRParams -> Exp { ',' Exp }
*/
void Analyzer::analysisFuncRParams(FuncRParams* root, vector<ir::Operand>&params, vector<ir::Instruction *> & insts) {
    int i = 0, curr = 0;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(exp, Exp, curr);
        COPY_TV(exp, params[i].type, params[i].name);
        analysisExp(exp, insts);
        if(!isInteger(exp->v) && !isFloat(exp->v) && insts.back()->op == Operator::mov) {
            string tmpName = insts.back()->op1.name.substr(0, insts.back()->op1.name.find('_'));
            //函数传参是不需要额外的mov的
            if(tmpName == SCOPE_GLOBAL || (tmpName == symbol_table.get_curr_scope())) { 
                exp->v = insts.back()->op1.name;
                insts.pop_back();
            }
        }
        //如果传入参数是立即数, 进行强制转换
        if(ISLiteral(exp->t)) {
            if(params[i].type == Type::Int && exp->t == Type::FloatLiteral){
                exp->t = Type::IntLiteral;
                exp->v = num2str(str2int(exp->v));
            }
            else if(params[i].type == Type::Float && exp->t == Type::IntLiteral) {
                exp->t = Type::FloatLiteral;
                exp->v = num2str(str2flt(exp->v));
            }
        }
        else {
            //浮点型转化为整型
            if(params[i].type == Type::Int && exp->t == Type::Float) {
                auto tmpv = get_tmp_var();
                insts.push_back(NewInst2(Operand(exp->v, exp->t),
                                        Operand(tmpv, Type::Int),
                                        Operator::cvt_f2i));
                COPY_TV(exp, Type::Int, tmpv);
            }
            else if(params[i].type == Type::Float && exp->t == Type::Int) {
                auto tmpv = get_tmp_var();
                insts.push_back(NewInst2(Operand(exp->v, exp->t),
                                        Operand(tmpv, Type::Float),
                                        Operator::cvt_f2i));
                COPY_TV(exp, Type::Float, tmpv);
            }
        }
        params[i++] = {exp->v, exp->t};
        curr += 2;
    }
}
/**
 * UnaryOp -> '+' | '-' | '!'
*/
frontend::TokenType Analyzer::analysisUnaryOp(UnaryOp* root, vector<ir::Instruction*>& insts) {
    GET_CHILD_PTR(term, Term, 0);
    return term->token.type;
}

/**
 * Exp -> AddExp
*/
void Analyzer::analysisExp(Exp* root, vector<ir::Instruction*> & insts) {
    GET_CHILD_PTR(addexp, AddExp, 0);
    COPY_EXP_NODE(root, addexp);
    analysisAddExp(addexp, insts);
    COPY_EXP_NODE(addexp, root);
}

/**
 * LVal -> Ident {'[' Exp ']'}
        bool is_computable = false;
        string v;
        Type t;
        int i;  // array index, legal if t is IntPtr or FloatPtr
        a[][][]
*/

void Analyzer::analysisLVal(LVal* root, vector<ir::Instruction *> & insts, bool isAssign) {
    //获取数组名
    GET_CHILD_PTR(term, Term, 0);
    Operand arrayOperand = symbol_table.get_operand(term->token.value);
    if(root->children.size() == 1) { //没有下标i
        //如果是赋值语句, 即a = b， 此处的root是右值
        if(isAssign) insts.push_back(NewInst2(Operand(root->v, root->t), Operand(arrayOperand.name, arrayOperand.type),Operator::mov));
        else {
            COPY_TV(root, arrayOperand.type, arrayOperand.name);
            //debug("analysisLVal: root->v: ", root->v);
            //debug("analysisLVal: root->t: ", toString(root->t));
            if(ISLiteral(root->t)) {
                root->is_computable = true;
                return;
            }
            else if(root->t == Type::IntPtr || root->t == Type::FloatPtr) {
                root->is_computable = false;
                return;
            }
            else {
                root->v = get_tmp_var();
                Operator op = Operator::mov;
                if(ISFloatOrLiteral(root->t)) op = Operator::fmov;
                insts.push_back(NewInst2(Operand(arrayOperand.name, arrayOperand.type), Operand(root->v, root->t),op));
            }
        }
    }
    //如果是数组
    else {
        //获取所有的下标
        std::vector<Operand>idxs;
        int curr = 2;
        bool isAllLiteral = true;
        while(curr < root->children.size() && CUR_NODE_IS(EXP, curr)) {
            ANALYSIS(exp, Exp, curr);
            idxs.push_back(Operand(exp->v, exp->t));
            curr += 3;
            if(!isAllDigits(exp->v)) isAllLiteral = false;
        }
        Operand des = Operand(get_tmp_var(), Type::Int);
        auto varste = symbol_table.get_ste(term->token.value);
        //计算数组的大小:这里优化一下, 如果全是常量, 则直接进行计算
        int arrSize = 0;
        if(isAllLiteral) {
            for(int i = 0; i < idxs.size(); i++) {
                int mul_dim = std::accumulate(varste.dimension.begin() + i + 1, varste.dimension.end(), 1, std::multiplies<int>());
                arrSize += mul_dim * str2int(idxs[i].name);
            }
            des = {num2str(arrSize), Type::IntLiteral};
        }
        else {
            //如果是一维数组, 直接是其中的值不需要一步步计算
            if(idxs.size() == 1) des = idxs[0];
            else {
                 //初始化临时变量
                insts.push_back(NewInst2(Operand(INTCONST, Type::IntLiteral), des, Operator::def));
                for(int i = 0; i < idxs.size(); i++) {
                    int mul_dim = std::accumulate(varste.dimension.begin() + i + 1, varste.dimension.end(), 1, std::multiplies<int>());
                    string tmpV = get_tmp_var();
                    insts.push_back(NewInst1(idxs[i], Operand(num2str(mul_dim), Type::IntLiteral),
                                     Operand(tmpV, Type::Int), Operator::mul));
                    insts.push_back(NewInst1(des, Operand(tmpV, Type::Int), des, Operator::add));
                    tmp_cnt--;
                }
            }
        }
        //store
        if(isAssign) insts.push_back(NewInst1(arrayOperand, des, Operand(root->v, root->t), Operator::store));
        //load
        else {
            root->t = CompareEq(arrayOperand.type, Type::IntPtr, Type::Int, Type::Float);
            auto var = get_tmp_var();
            insts.push_back(NewInst1(arrayOperand, des, Operand(var, root->t), Operator::load));
            root->v = var;
        }
    }
}

/**
 * 这是一个整数或浮点数常量, 属性值需要向上传递, 属于终结符Term
 * Number -> IntConst | floatConst    205 |  103.5
 *      bool is_computable = true;
 *      string v;
        Type t;
*/
void Analyzer::analysisNumber(Number* root, vector<ir::Instruction *>& insts) {
    GET_CHILD_PTR(term, Term, 0);
    //debug("pre: NumberRoot->t: ", toString(root->t));
    root->t = CompareEq(term->token.type, TokenType::INTLTR, 
                        Type::IntLiteral, Type::FloatLiteral);
    // debug("pre: NumberRoot->v: ",root->v);
    auto s_type = term->token.type;
    auto val    = term->token.value;
    if(s_type == TokenType::INTLTR) {
        if(val.size() >= 2) {
            //16进制整数
            if(val.substr(0, 2) == "0x")      root->v = num2str(str2int(val, nullptr, 16));
            else if(val.substr(0, 2) == "0b") root->v = num2str(str2int(val, nullptr, 2));
            else if(val.substr(0, 1) == "0")  root->v = num2str(str2int(val, nullptr, 8));
            //这里是为了出现0000777这种情况, 但是在测试用例中并没有发现
            else root->v = num2str(str2int(val));
        }
        else root->v = num2str(str2int(val));
    }
    //浮点数
    else {
        //首先是.0开头的, 我采用的策略就是0.0填充
        if(val[0] == '.')                 root->v = "0" + val;
        //其次是2.结尾的, 采用2.0就这么粗暴
        else if(val[val.size()-1] == '.') root->v = val + "0";
        else                              root->v = val;
        //if(ISIntOrLiteral(root->t)) root->v = num2str(str2int(root->v));
    }
    // debug("after: NumberRoot->t: ", toString(root->t));
    // debug("after: NumberRoot->v: ",root->v);
}

/**
 * VarDecl -> BType VarDef { ',' VarDef } ';'
*/
void Analyzer::analysisVarDecl(VarDecl* root, vector<Instruction*>& insts) {
    //获取int/float类型
    GET_CHILD_PTR(btype, BType, 0);
    root->t = analysisBType(btype);
    latestType = root->t;
    GET_CHILD_PTR(vardef, VarDef, 1);
    analysisVarDef(vardef, insts, root->t);
    int curr = 3;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(vardef, VarDef, curr);
        analysisVarDef(vardef, insts, root->t);
        curr += 2;
    }
    latestType = Type::null;
}

/**
 * VarDef -> Ident { '[' ConstExp ']' } [ '=' InitVal ]
 * int a, b = 2, c[][] = 
 * std::string arr_name;
*/
void Analyzer::analysisVarDef(VarDef* root, vector<Instruction*>& insts, Type tp) {
    GET_CHILD_PTR(ident, Term, 0);
    //原始的变量命名
    std::string init_name = ident->token.value;
    //该作用域下的名字
    root->arr_name = symbol_table.get_scoped_name(init_name);
    /**
     * 因为[ ConstExp ]可能为多个循环, 因此考虑使用for或者while循环,
     * 使用dim记录数组维数, 如果有
     * 当遇到ConstExp时分析子结点ConstExp -> 计算数组大小存入dim
    */
    int curr = 2;            //记录当前进行的指针
    vector<int>dim;          //记录数组维数 + 大小
    Type varType = tp;       //变量的类型, 整数和浮点数立即数、整数和浮点数指针(数组)
    while(curr < root->children.size() && CUR_NODE_IS(CONSTEXP, curr)) {
        //将父节点的属性传递给子节点
        GET_CHILD_PTR(constexp, ConstExp, curr);
        COPY_TV(constexp, tp, root->arr_name);
        analysisConstExp(constexp, insts);
        //将其强制转化为
        dim.push_back(str2int(constexp->v));
        curr += 3;
    }
    if(dim.size()) {
        //如果是数组, IntPtr || FloatPtr, 由tp决定
        varType = CompareEq(tp, Type::Int, Type::IntPtr, Type::FloatPtr);
        Operand tmpDes = CompareEq(varType, Type::IntPtr, Operand(INTCONST, Type::IntLiteral), Operand(FLOATCONST, Type::FloatLiteral));
        insts.push_back(NewInst2(tmpDes, Operand("tmp0", tp), CompareEq(tp, Type::Int, Operator::def, Operator::fdef)));
        //对数组进行初始化
        if(symbol_table.get_curr_scope() != SCOPE_GLOBAL) {
            int dimSize = cal_arr_size(dim);
            insts.push_back(NewInst2(Operand(std::to_string(dimSize), Type::IntLiteral),
                                     Operand(root->arr_name, varType),
                                     Operator::alloc)); 
            for(int i = 0; i < dimSize; i++) {
            insts.push_back(NewInst1(Operand(root->arr_name, varType),
                                     Operand(num2str(i), Type::IntLiteral),
                                     tmpDes,
                                     Operator::store));
            }
        }
    }
    else {
        //如是普通变量int a = 2; || float b = 1.5;
        //如果是未初始化
        if(root->children.size() == 1){
            //手动初始化
            symbol_table.add_scope_entry(init_name, {Operand(root->arr_name, varType), dim});
            return;
        }
        Type tType = CompareEq(tp, Type::Int, Type::IntLiteral, Type::FloatLiteral);
        insts.push_back(NewInst2(Operand(CompareEq(tp, Type::Int, INTCONST, FLOATCONST), tType),
                                 Operand(root->arr_name, tp),
                                 CompareEq(tp, Type::Int, Operator::def, Operator::fdef)));
    }
    symbol_table.add_scope_entry(init_name, {Operand(root->arr_name, varType), dim});
    if(CUR_NODE_IS(INITVAL, root->children.size() - 1)) {
        GET_CHILD_PTR(initval, InitVal, root->children.size() - 1);
        COPY_TV(initval, varType, root->arr_name);
        analysisInitVal(initval, insts);
    }
    
}

/**
 * InitVal -> Exp | '{' [ InitVal { ',' InitVal } ] '}'
 * InitVal.is_computable
 * InitVal.v
 * InitVal.t
*/
void Analyzer::analysisInitVal(InitVal* root, vector<Instruction*>& insts) {
    if(CUR_NODE_IS(EXP, 0)) {
        GET_CHILD_PTR(exp, Exp, 0);
        COPY_TV(exp, root->t, get_tmp_var());
        analysisExp(exp, insts);
        //debug("5555", toString(root->t));
        //debug("666", toString(exp->t));
        //如果不是形如int a, float b未初始化
        if(exp->v != INTCONST && exp->v != FLOATCONST) {
            if(root->t == Type::Int) {
                //if exists int a = 2.6;  2.6 => 2
                if(exp->t == Type::FloatLiteral) {
                    exp->t = Type::IntLiteral;
                    exp->v = num2str((int)str2flt(exp->v));
                }
                //mov b, a
                insts.push_back(NewInst2(Operand(exp->v, exp->t),
                                         Operand(root->v, Type::Int),
                                         Operator::mov));
                if(exp->t == Type::IntLiteral) {
                    insts.pop_back();
                    insts.back()->op1.name = exp->v;
                }
            }
            else if(root->t == Type::Float) {
                //if exists float a = 2.5; 2.5 => 3
                if(exp->t == Type::IntLiteral) {
                    exp->t = Type::FloatLiteral;
                    exp->v = num2str((float)str2int(exp->v));
                }
                //mov b a
                insts.push_back(NewInst2(Operand(exp->v, exp->t),
                                         Operand(root->v, Type::Float),
                                         Operator::fmov));
                if(exp->t == Type::FloatLiteral) {
                    insts.pop_back();
                    insts.back()->op1.name = exp->v;
                }
            }
        }
        COPY_TV(root, exp->t, exp->v);
        tmp_cnt--;
    }
    else {
        int curr = 1;
        int arr_index = 0;
        while(curr < root->children.size() && CUR_NODE_IS(INITVAL, curr)) {
            GET_CHILD_PTR(initval, InitVal, curr);
            COPY_TV(initval, root->t, get_tmp_var());
            analysisInitVal(initval, insts);
            if(latestType == Type::Int && initval->t == Type::FloatLiteral) {
                initval->v = num2str(str2int(initval->v));
                initval->t = Type::IntLiteral;
            }
            else if(latestType == Type::Float && initval->t == Type::IntLiteral) {
                initval->v = num2str(str2flt(initval->v));
                initval->t = Type::FloatLiteral;
            }
            //store 3, arr, 2 => op1: arr, op2: index, des: val, opcode 
            insts.push_back(NewInst1(Operand(root->v, root->t),
                                     Operand(num2str(arr_index++), Type::IntLiteral),
                                     Operand(initval->v, initval->t),
                                     Operator::store));
            tmp_cnt--;
            curr += 2;
        }
    }
}

//--------------以下是函数定义------------------
/**
 * FuncDef -> FuncType Ident '(' [FuncFParams] ')' Block
 * 
 * eg: int/float/void myfunc(int a, int b[])
 * FuncDef.t
 * FuncDef.n
*/
void Analyzer::analysisFuncDef(FuncDef* root) {
    //获取函数类型
    GET_CHILD_PTR(functype, FuncType, 0);
    root->t = analysisFuncType(functype);
    //获取函数名称
    GET_CHILD_PTR(term, Term, 1);
    root->n = term->token.value;

    symbol_table.add_scope(root->n);
    //如果有函数参数[Debug]
    auto params = new vector<Operand>();
    if(CUR_NODE_IS(FUNCFPARAMS, 3)) {
        GET_CHILD_PTR(funcfparams, FuncFParams, 3);
        analysisFuncFParams(funcfparams, *params);
    }
    //增加函数到符号表中
    symbol_table.functions[root->n] = new Function(root->n, *params, root->t);
    //获取函数中的指令
    GET_CHILD_PTR(block, Block, root->children.size() - 1);
    analysisBlock(block, symbol_table.functions[root->n]->InstVec);

    if (symbol_table.functions[root->n]->InstVec.back()->op != Operator::_return) // 如果函数没有return语句
        symbol_table.functions[root->n]->InstVec.push_back(
            new Instruction(Operand(), Operand(), Operand(), Operator::_return));
    symbol_table.exit_scope();
}

/**
 * FuncType -> 'void' | 'int' | 'float'
 * return Type
*/
ir::Type Analyzer::analysisFuncType(FuncType* root) {
    GET_CHILD_PTR(term, Term, 0);
    TokenType tk = term->token.type;
    if(tk == TokenType::VOIDTK)         return Type::null;
    else if(tk == TokenType::INTTK)     return Type::Int;
    else if(tk == TokenType::FLOATTK)   return Type::Float;
    else {
        Debug_ERROR("[Analyzer::analysisFuncType] Unexpected FuncType: ", "");
    }
}

/**
 * 多个函数参数
 * FuncFParams -> FuncFParam { ',' FuncFParam }
 * int a, int b[][]
*/
void Analyzer::analysisFuncFParams(FuncFParams* root, vector<ir::Operand> &params) {
    int curr = 0;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(funcfparam, FuncFParam, curr);
        analysisFuncFParam(funcfparam, params);
        curr += 2;
    }
}

/**
 * 单个函数参数
 * FuncFParam -> BType Ident ['[' ']' { '[' Exp ']' }]
*/
void Analyzer::analysisFuncFParam(FuncFParam* root, vector<ir::Operand> &params) {
    GET_CHILD_PTR(btype, BType, 0);
    GET_CHILD_PTR(term, Term, 1);
    //获取参数类型
    Type paramType = analysisBType(btype);
    //获取参数原始名称
    string init_name = term->token.value;
    string scope_name = symbol_table.get_scoped_name(init_name);
    //记录数组大小
    vector<int>dim;
    const int INF = 0x3f3f3f3f;
    if(root->children.size() == 4) {  //一维数组
        paramType = CompareEq(paramType, Type::Int, Type::IntPtr, Type::FloatPtr);
        dim.push_back(INF);
    }
    else if(root->children.size() == 7) {  //二维数组
        dim.push_back(INF);
    }
    params.push_back(Operand(scope_name, paramType));
    symbol_table.add_scope_entry(
        init_name,
        {Operand(scope_name, paramType), dim}
    );
}

/**
 * 语句块: 可以嵌套, 那么就需要考虑作用域的问题
 * Block -> '{' { BlockItem } '}'
*/
void Analyzer::analysisBlock(Block* root, vector<ir::Instruction*>& insts) {
    for (size_t i = 1; i < root->children.size() - 1; i++) {
        ANALYSIS(blockitem, BlockItem, i);
    }
}

/**
 * 可以是变量声明, 函数声明, 语句声明:  前两者已经在前面实现
 * BlockItem -> Decl | Stmt
 * 
*/
void Analyzer::analysisBlockItem(BlockItem* root, vector<ir::Instruction*>& insts) {
    if(CUR_NODE_IS(DECL, 0)) {
        ANALYSIS(decl, Decl, 0);
    }
    else if(CUR_NODE_IS(STMT, 0)) {
        ANALYSIS(stmt, Stmt, 0);
    }
    else {
        Debug_ERROR("[Analyzer::analysisBlock] Unexpected NodeType:", "");
    }
}

/**
 * Stmt -> LVal '=' Exp ';'                       | 
 *         Block                                  | 
 *         'if' '(' Cond ')' Stmt [ 'else' Stmt ] | 
 *         'while' '(' Cond ')' Stmt              | 
 *         'break' ';'                            | 
 *         'continue' ';'                         |
 *         'return' [Exp] ';' | [Exp] ';'
*/
void Analyzer::analysisStmt(Stmt* root, vector<ir::Instruction*>& insts) {
    if(CUR_NODE_IS(LVAL, 0)) {
        //获取右值
        GET_CHILD_PTR(exp, Exp, 2);
        COPY_TV(exp, Type::null, get_tmp_var());
        analysisExp(exp, insts);
        //获取左边
        GET_CHILD_PTR(lval, LVal, 0);
        COPY_EXP_NODE(exp, lval);
        analysisLVal(lval, insts, true);
        tmp_cnt--;
    }
    else if(CUR_NODE_IS(BLOCK, 0)) {
        symbol_table.add_scope(symbol_table.get_curr_scope() + "_sub");
        ANALYSIS(block, Block, 0);
        symbol_table.exit_scope();
    }
    else if(CUR_NODE_IS(TERMINAL, 0)) {
        GET_CHILD_PTR(term, Term, 0);
        TokenType tk = term->token.type;
        if(tk == TokenType::IFTK)         doifStmt(root, insts);
        else if(tk == TokenType::WHILETK) dowhileStmt(root, insts);
        else if(tk == TokenType::BREAKTK)    insts.push_back(NewInst2(Operand("1", Type::IntLiteral), Operand(), Operator::__unuse__));
        else if(tk == TokenType::CONTINUETK) insts.push_back(NewInst2(Operand("2", Type::IntLiteral), Operand(), Operator::__unuse__));
        else if(tk == TokenType::RETURNTK) {
            if(symbol_table.functions.find(symbol_table.get_curr_scope()) != symbol_table.functions.end()) {
                latestType = symbol_table.functions[symbol_table.get_curr_scope()]->returnType;
            }
            if(root->children.size() == 1) insts.push_back(NewInst2(Operand(INTCONST, Type::null), Operand(), Operator::_return));
            //debug("1111111",toString(symbol_table.functions[symbol_table.get_curr_scope()]->returnType));
            else {
                GET_CHILD_PTR(exp, Exp, 1);
                COPY_TV(exp, Type::null, get_tmp_var());
                analysisExp(exp, insts);
                insts.push_back(NewInst2(Operand(exp->v, exp->t), Operand(), Operator::_return));
                tmp_cnt--;
            }
            latestType = Type::null;
        }
        // else { 这里不是bug我去, 对应空语句
        //     Debug_ERROR("[Analyzer::analysisStmt] Unexpected TokenType: ", frontend::toString(tk));
        // }
    }
    else if(CUR_NODE_IS(EXP, 0)) {
        GET_CHILD_PTR(exp, Exp, 0);
        COPY_TV(exp, Type::Int, get_tmp_var());
        analysisExp(exp, insts);
        tmp_cnt--;
    }
}

/**
 * @brief if cond
*/
void Analyzer::doifStmt(Stmt* root, vector<ir::Instruction *>& insts) {
    GET_CHILD_PTR(cond, Cond, 2);
    COPY_TV(cond, Type::null, get_tmp_var());
    analysisCond(cond, insts);
    //if cond go to [pc, 2]
    if(cond->t == Type::IntLiteral) {
        cond->v = (cond->v == INTCONST)?INTCONST:"1";
    }
    else if(cond->t == Type::FloatLiteral) {
        cond->v = (str2flt(cond->v) < 1e-30) ? INTCONST:"1";
    }
    insts.push_back(NewInst2(Operand(cond->v, cond->t), Operand("2", Type::IntLiteral), Operator::_goto));
    //存储true或者false的指令
    vector<Instruction*>trueCondInsts, falseCondInsts;
    GET_CHILD_PTR(trueStmt, Stmt, 4);
    analysisStmt(trueStmt, trueCondInsts);
    string addr = "";
    if(root->children.size() == 7) {
        GET_CHILD_PTR(falseStmt, Stmt, 6);
        analysisStmt(falseStmt, falseCondInsts);
        addr = num2str(falseCondInsts.size() + 1);
        trueCondInsts.push_back(NewInst2(Operand(), Operand(addr, Type::IntLiteral),Operator::_goto));
    }
    addr = num2str(trueCondInsts.size() + 1);
    insts.push_back(NewInst2(Operand(), Operand(addr, Type::IntLiteral), Operator::_goto));
    insts.insert(insts.end(), trueCondInsts.begin(), trueCondInsts.end());
    insts.insert(insts.end(), falseCondInsts.begin(), falseCondInsts.end());
    tmp_cnt--;
}

/**
 * @brief while cond
*/
void Analyzer::dowhileStmt(Stmt* root, vector<ir::Instruction *>& insts) {
    GET_CHILD_PTR(cond, Cond, 2);
    COPY_TV(cond, Type::null, get_tmp_var());
    vector<Instruction*>condInsts, whileInsts;
    analysisCond(cond, condInsts);
    insts.insert(insts.end(), condInsts.begin(), condInsts.end());
    insts.push_back(NewInst2(Operand(cond->v, cond->t),Operand("2", Type::IntLiteral),Operator::_goto));
    GET_CHILD_PTR(stmt, Stmt, 4);
    analysisStmt(stmt, whileInsts);
    string addr = num2str(-int(whileInsts.size() + 2 + condInsts.size()));
    whileInsts.push_back(NewInst2(Operand(), Operand(addr, Type::IntLiteral), Operator::_goto));
    // 跳转到while_stmt后面
    addr = num2str(whileInsts.size() + 1);
    insts.push_back(NewInst2(Operand(), Operand(addr, Type::IntLiteral), Operator::_goto));

    afor(i, 0, whileInsts.size()-1, 1) {
        if(whileInsts[i]->op == Operator::__unuse__) {
            string targetAddr = "";
            if(whileInsts[i]->op1.name == "1") {
                targetAddr = num2str(int(whileInsts.size()) - i);
                whileInsts[i] = NewInst2(Operand(), Operand(targetAddr, Type::IntLiteral), Operator::_goto);
            }
            else if(whileInsts[i]->op1.name == "2") {
                targetAddr = num2str(-int(i + 2 + condInsts.size()));
                whileInsts[i] = NewInst2(Operand(), Operand(targetAddr, Type::IntLiteral), Operator::_goto);
            }     
        }
    }
    insts.insert(insts.end(), whileInsts.begin(), whileInsts.end());
    tmp_cnt--;
}
/**
 * Cond -> LOrExp
 * 
*/
void Analyzer::analysisCond(Cond* root, vector<ir::Instruction*>& insts) {
    // ANALYSIS(lorexp, LOrExp, 0);
    // COPY_EXP_NODE(lorexp, root);
    GET_CHILD_PTR(lorexp, LOrExp, 0);
    COPY_EXP_NODE(root, lorexp);
    analysisLOrExp(lorexp, insts);
    COPY_EXP_NODE(lorexp, root);
}

/**
 * LOrExp -> LAndExp [ '||' LOrExp ]
 * LOrExp.is_computable
 * LOrExp.v
 * LOrExp.t
*/
void Analyzer::analysisLOrExp(LOrExp* root, vector<ir::Instruction*>& insts) {
    // ANALYSIS(landexp, LAndExp, 0);
    // COPY_EXP_NODE(landexp, root);
    GET_CHILD_PTR(landexp, LAndExp, 0);
    COPY_EXP_NODE(root, landexp);
    analysisLAndExp(landexp, insts);
    COPY_EXP_NODE(landexp, root);

    int curr = 2;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(lorexp, LOrExp, curr);
        vector<Instruction*>childInsts;
        COPY_TV(lorexp, Type::Int, get_tmp_var());
        analysisLOrExp(lorexp, childInsts);
        if(lorexp->t == Type::IntLiteral && root->t == Type::IntLiteral) {
            root->v = num2str(str2int(root->v) || str2int(lorexp->v));
        }
        else if(root->t == Type::IntLiteral && lorexp->t == Type::FloatLiteral) {
            if(str2int(root->v) || (str2flt(lorexp->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else if(root->t == Type::FloatLiteral && lorexp->t == Type::IntLiteral) {
            if(str2int(lorexp->v) || (str2flt(root->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else if(root->t == Type::FloatLiteral && lorexp->t == Type::FloatLiteral) {
            if((str2flt(lorexp->v) > 1e-30) || (str2flt(root->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else {
            childInsts.push_back(NewInst1(Operand(root->v, root->t),
                                          Operand(lorexp->v, lorexp->t),
                                          Operand(root->v, Type::Int),
                                          Operator::_or));
            insts.push_back(NewInst2(Operand(root->v, root->t), Operand(num2str(childInsts.size() + 1), Type::IntLiteral), Operator::_goto));
            insts.insert(insts.end(), childInsts.begin(), childInsts.end());
        }
        tmp_cnt--;
        curr += 2;
    }
}

/**
 * LAndExp -> EqExp [ '&&' LAndExp ]
 * LAndExp.is_computable
 * LAndExp.v
 * LAndExp.t
*/
void Analyzer::analysisLAndExp(LAndExp* root, vector<ir::Instruction*>& insts) {
    // ANALYSIS(eqexp, EqExp, 0);
    // COPY_EXP_NODE(eqexp, root);
    GET_CHILD_PTR(eqexp, EqExp, 0);
    COPY_EXP_NODE(root, eqexp);
    analysisEqExp(eqexp, insts);
    COPY_EXP_NODE(eqexp, root);
    int curr = 2;
    while(curr < root->children.size()) {
        GET_CHILD_PTR(landexp, LAndExp, curr);
        vector<Instruction*>childInsts;
        COPY_TV(landexp, Type::Int, get_tmp_var());
        analysisLAndExp(landexp, childInsts);
        if(landexp->t == Type::IntLiteral && root->t == Type::IntLiteral) {
            root->v = num2str(str2int(root->v) && str2int(landexp->v));
        }
        else if(root->t == Type::IntLiteral && landexp->t == Type::FloatLiteral) {
            if(str2int(root->v) && (str2flt(landexp->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else if(root->t == Type::FloatLiteral && landexp->t == Type::IntLiteral) {
            if(str2int(landexp->v) && (str2flt(root->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else if(root->t == Type::FloatLiteral && landexp->t == Type::FloatLiteral) {
            if((str2flt(landexp->v) > 1e-30) && (str2flt(root->v) > 1e-30)) {
                root->v = "1";
            }
            else root->v = "0";
        }
        else {
            childInsts.push_back(NewInst1(Operand(root->v, root->t),
                                          Operand(landexp->v, landexp->t),
                                          Operand(root->v, Type::Int),
                                          Operator::_and));
            //对第一个操作数取反存放入t1
            Operand t1 = Operand(get_tmp_var(), Type::Int);
            insts.push_back(NewInst2(Operand(root->v, root->t), t1, Operator::_not));
            string addr = num2str(childInsts.size() + 1);
            insts.push_back(NewInst2(t1, Operand(addr, Type::IntLiteral), Operator::_goto));
            insts.insert(insts.end(), childInsts.begin(), childInsts.end());
        }
        tmp_cnt -= 2;
        curr += 2;
    }
}

/**
 * 做立即数逻辑运算
*/
int doLogicComp(int a, int b, frontend::TokenType tk) {
    switch (tk)
    {
        case frontend::TokenType::AND:
            return a && b;
        case frontend::TokenType::OR:
            return a || b;
        case frontend::TokenType::EQL:
            return a == b;
        case frontend::TokenType::NEQ:
            return a != b;
        case frontend::TokenType::LSS:
            return a < b;
        case frontend::TokenType::GTR:
            return a > b;
        case frontend::TokenType::LEQ:
            return a <= b;
        case frontend::TokenType::GEQ:
            return a >= b;
        default:    break;
    }
    return 0;
}
/**
 * EqExp -> RelExp { ('==' | '!=') RelExp }
 * EqExp.is_computable
 * EqExp.v
 * EqExp.t
*/
void Analyzer::analysisEqExp(EqExp* root, vector<ir::Instruction*>& insts) {
    // ANALYSIS(relexp, RelExp, 0);
    // COPY_EXP_NODE(relexp, root);
    GET_CHILD_PTR(relexp, RelExp, 0);
    COPY_EXP_NODE(root, relexp);
    analysisRelExp(relexp, insts);
    COPY_EXP_NODE(relexp, root);
    int curr = 2;
    while(curr < root->children.size()) {
        ANALYSIS(relexp, RelExp, curr);
        GET_CHILD_PTR(term, Term, curr-1);
        if(ISLiteral(root->t) && ISLiteral(relexp->t)) {
            if(relexp->t == Type::IntLiteral && root->t == Type::IntLiteral) {
                root->v = num2str(doLogicComp(str2int(root->v), str2int(relexp->v), term->token.type));
            }
            else {
                if(str2flt(root->v) - str2flt(root->v) < 1e-30) {
                    root->v = CompareEq(term->token.type, TokenType::EQL, "1", "0");
                }
                else {
                    root->v = CompareEq(term->token.type, TokenType::EQL, "0", "1");
                }
                root->t = Type::IntLiteral;
            }
        }
        else {
            Operand desVar = Operand(get_tmp_var(), Type::Int);
            insts.push_back(NewInst1(Operand(root->v, root->t),
                                     Operand(relexp->v, relexp->t),
                                     desVar,
                                     get_operator(term->token.type)));
            COPY_TV(root, desVar.type, desVar.name);
        }
        curr += 2;
    }
}

/**
 * RelExp -> AddExp { ('<' | '>' | '<=' | '>=') AddExp }
 * RelExp.is_computable
 * RelExp.v
 * RelExp.t
*/
void Analyzer::analysisRelExp(RelExp* root, vector<ir::Instruction*>& insts) {
    GET_CHILD_PTR(addexp, AddExp, 0);
    COPY_EXP_NODE(root, addexp);
    analysisAddExp(addexp, insts);
    COPY_EXP_NODE(addexp, root);
    int curr = 2;
    while(curr < root->children.size()) {
        ANALYSIS(addexp, AddExp, curr);
        GET_CHILD_PTR(term, Term, curr-1);
        if(addexp->t == Type::IntLiteral && root->t == Type::IntLiteral) {
            root->v = num2str(doLogicComp(str2int(root->v), str2int(addexp->v), term->token.type));
        }
        else {
            Operand desVar = Operand(get_tmp_var(), Type::Int);
            if((addexp->t == Type::IntLiteral || addexp->t == Type::FloatLiteral) && root->t == Type::Float){
                desVar.type = Type::Float;
                insts.push_back(NewInst1(Operand(root->v, root->t),
                                         Operand(num2str(str2flt(addexp->v)), Type::FloatLiteral),
                                         desVar,
                                         get_operator_f(term->token.type)));
            }
            else {
                insts.push_back(NewInst1(Operand(root->v, root->t),
                                         Operand(addexp->v, addexp->t),
                                         desVar,
                                         get_operator(term->token.type)));
            }
            COPY_TV(root, desVar.type, desVar.name);
        }
        curr += 2;
    }
}

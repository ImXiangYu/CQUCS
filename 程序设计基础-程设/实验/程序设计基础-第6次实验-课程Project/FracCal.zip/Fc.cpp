#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include "Fc.h"
using namespace std;
string state;
int count1;
void Run()
{
    cout << "请选择功能(键入1或2或3进行选择)" << endl;
    cout << "1.分数计算" << endl;
    cout << "2.分数排序" << endl;
    cout << "3.退出程序" << endl;
    int n;
    cin >> n;
    if (n == 1)
    {
        state = "分数计算";
        system("cls");
        Fc_show();
        Fc_calculation();
    }
    if (n == 2)
    {
        state = "分数排序";
        system("cls");
        sortshow();
        sort();
    }
    if (n == 3)
    {
        cout << "感谢使用" << endl;
        exit(0);
    }
}
Fraction::Fraction() : numer(0), deno(1) {}             //无参构造函数
Fraction::Fraction(int n, int d) : numer(n), deno(d) {} //带参构造函数
Fraction::Fraction(const Fraction &f)                   //复制构造函数
{
    numer = f.numer;
    deno = f.deno;
}
void Fraction::setFraction(int n, int d) //设置分数的分子和分母
{
    numer = n;
    deno = d;
}
int Fraction::getNumer() //获取分数的分子
{
    return numer;
}
int Fraction::getDeno() //获取分数的分母
{
    return deno;
}
void Fraction::RdcFrc() //当前分数约分
{
    if (deno == 0 && state == "分数计算") //排除分母为0的情况
    {
        wrong();
        Fc_calculation();
    }
    if (numer == 0)
        deno = 1;
    if (numer < 0)
    {
        numer = -numer;
        deno = -deno;
    }
    int cf = gcd(abs(numer), abs(deno));
    if (cf != 0)
    {
        numer /= cf;
        deno /= cf;
    }
}
Fraction operator+(const Fraction &frac1, const Fraction &frac2) //重载+运算符
{
    Fraction t;
    t.numer = frac1.numer * frac2.deno + frac1.deno * frac2.numer;
    t.deno = frac1.deno * frac2.deno;
    t.RdcFrc();
    return t;
}
Fraction operator-(const Fraction &frac1, const Fraction &frac2) //重载-运算符
{
    Fraction t;
    t.numer = frac1.numer * frac2.deno - frac1.deno * frac2.numer;
    t.deno = frac1.deno * frac2.deno;
    t.RdcFrc();
    return t;
}
Fraction operator*(const Fraction &frac1, const Fraction &frac2) //重载*运算符
{
    Fraction t;
    t.numer = frac1.numer * frac2.numer;
    t.deno = frac1.deno * frac2.deno;
    t.RdcFrc();
    return t;
}
Fraction operator/(const Fraction &frac1, const Fraction &frac2) //重载/运算符
{
    Fraction t;
    t.numer = frac1.numer * frac2.deno;
    t.deno = frac1.deno * frac2.numer;
    t.RdcFrc();
    return t;
}
bool operator==(Fraction frac1, Fraction frac2) //重载==运算符
{
    Fraction t1;
    Fraction t2;
    t1 = frac1;
    t2 = frac2;
    t1.RdcFrc();
    t2.RdcFrc();
    if (t1.deno == t2.deno && t1.numer == t2.numer)
        return true;
    else
        return false;
}
bool operator>(const Fraction &frac1, const Fraction &frac2) //重载>运算符
{
    if (frac1.numer * frac2.deno - frac1.deno * frac2.numer > 0)
        return true;
    else
        return false;
}
bool operator<(const Fraction &frac1, const Fraction &frac2) //重载<运算符
{
    if (frac1.numer * frac2.deno - frac1.deno * frac2.numer < 0)
        return true;
    else
        return false;
}
ostream &operator<<(ostream &out, const Fraction &frac) //重载<<运算符
{
    out << frac.numer << "/" << frac.deno;
    return out;
}
istream &operator>>(istream &in, Fraction &frac) //重载>>运算符
{
    char c;
    in >> frac.numer >> c >> frac.deno; //输入分数
    return in;
}
int gcd(int numer, int deno) //辗转相除法求最大公因数
{
    return deno == 0 ? numer : gcd(deno, numer % deno);
}
void wrong() //输入错误提示
{
    cout << "---" << endl;
    cout << "分数算式输入错误!" << endl;
    Fc_show();
}
void sort() //排序界面
{
    while (1)
    {
        vector<Fraction> vec;
        Fraction f3;
        char sign;
        while (1)
        {
            cin >> f3 >> sign;
            while (cin.fail() || (sign != ',' && sign != '>' && sign != '<'))
            {
                cin.clear();
                if (cin.peek() == '#')
                {
                    getchar();
                    system("cls");
                    Run();
                }
                sortwrong();
                cin.ignore(INT_MAX, '\n');
                sort();
            }
            f3.judge();
            vec.push_back(f3);
            if (sign == '>' || sign == '<')
                break;
        }
        if (count1 != 0)
        {
            sortwrong();
            count1 = 0;
            sort();
        }
        sortFraction(vec, sign);
        for (int i = 0; i < vec.size(); i++)
        {
            if (i == 0)
            {
                cout << "---" << endl;
                cout << "排序后结果: " << vec[i];
            }
            else
                cout << " " << vec[i];
        }
        cout << endl;
        sortshow();
    }
}
void sortFraction(vector<Fraction> &vec, char sign) //对数组内内容进行排序
{

    if (sign == '>')
    {
        sort(vec.begin(), vec.end(), greater<>());
    }
    else
    {
        sort(vec.begin(), vec.end(), less<>());
    }
}
void Fc_show() //分数计算界面显示
{
    cout << "---" << endl;
    cout << "请输入分式计算式(如 1/2+1/3 回车),输入#号返回上一层目录" << endl;
}
void sortshow() //排序界面输出
{
    cout << "---" << endl;
    cout << "请输入一组分数,用逗号隔开" << endl;
    cout << "如需由小到大排列用符号<结尾,由大到小排列用符号>结尾" << endl;
    cout << "(如1/2,1/4,3/5<回车),输入#号键返回上一层目录" << endl;
}
void Fc_calculation() //进行计算
{
    while (1)
    {
        char sign;
        Fraction f1;
        Fraction f2;
        cin >> f1 >> sign >> f2;
        while (cin.fail())
        {
            cin.clear();
            if (cin.peek() == '#')
            {
                getchar();
                system("cls");
                Run();
            }
            cin.ignore(INT_MAX, '\n');
            wrong();
            Fc_calculation();
        }
        Fraction result;
        if (sign == '+')
        {
            result = f1 + f2;
        }
        else if (sign == '-')
        {
            result = f1 - f2;
        }
        else if (sign == '*')
        {
            result = f1 * f2;
        }
        else if (sign == '/')
        {
            result = f1 / f2;
        }
        if (result.getDeno() == result.getNumer())
            cout << "=1" << endl;
        else if (result.getNumer() == 0)
            cout << "=0" << endl;
        else if (result.getDeno() == 1)
            cout << "=" << result.getNumer() << endl;
        else if (result.getNumer() > 0 && result.getDeno() == -1)
            cout << "=" << -result.getNumer() << endl;
        else if (result.getNumer() < 0 && result.getDeno() == 1)
            cout << "=" << result.getNumer() << endl;
        else
            cout << "=" << result << endl;
        Fc_show();
    }
}
void sortwrong() //排序页面输入错误提示
{
    cout << "---" << endl;
    cout << "输入错误!" << endl;
    sortshow();
}
void Fraction::judge() //判断排序过程中是否出现有分数分母为0的情况
{
    if (deno == 0 && state == "分数排序")
    {
        count1++;
    }
}
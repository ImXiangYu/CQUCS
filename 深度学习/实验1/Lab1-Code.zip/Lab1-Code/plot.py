# plot.py
# 绘制需要的图像
import matplotlib.pyplot as plt

def plot_lr_results(lr_list, val_acc_list, test_acc_list):
    plt.figure(figsize=(8,5))
    plt.plot(lr_list, val_acc_list, marker="o", label="Val Accuracy")
    plt.plot(lr_list, test_acc_list, marker="s", label="Test Accuracy")
    plt.xscale("log")
    plt.xlabel("Learning Rate")
    plt.ylabel("Accuracy")
    plt.legend()
    plt.title("Accuracy vs Learning Rate")
    plt.grid(True)
    plt.show()

def visualize_conv1(model):
    import matplotlib.pyplot as plt
    w = model.model.features[0].weight.data.cpu()
    fig, axes = plt.subplots(8, 8, figsize=(10, 10))
    for i, ax in enumerate(axes.flat):
        ax.imshow(w[i][0], cmap='gray')
        ax.axis("off")
    plt.show()
    # 输出信息，图表已显示
    print("\nVisualization completed.")

#include "ATM.h"

void changePassword(const string& accountNumber) {
    User tmpUser;
    tmpUser.loadData(accountNumber + ".txt");
    string newPassword, confirmNewPassword;

    cout << "Enter new password:";
    cin >> newPassword;
    while (!isNumber(newPassword) || newPassword.length() != 6) {
        cout << "Invalid password. Try again." << endl;
        cin >> newPassword;
    }

    cout << "Confirm new password:";
    cin >> confirmNewPassword;

    if (newPassword == confirmNewPassword && newPassword.length() == 6) {
        tmpUser.password = newPassword;
        cout << "Password changed successfully." << endl;
        tmpUser.saveData(accountNumber + ".txt");
        displayMenu();
        performOperation(accountNumber);
    } else {
        cout << "Invalid password or passwords do not match. Password change canceled." << endl;
        displayMenu();
        performOperation(accountNumber);
    }
}

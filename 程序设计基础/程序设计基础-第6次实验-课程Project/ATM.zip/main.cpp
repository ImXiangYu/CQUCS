#include "ATM.h"

int main() {
    welcomeMessage();
    return 0;
}
